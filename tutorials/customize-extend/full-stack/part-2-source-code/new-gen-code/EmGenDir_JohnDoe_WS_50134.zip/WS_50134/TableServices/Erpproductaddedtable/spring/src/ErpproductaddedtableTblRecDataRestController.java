package emrest.spring; 
 
import java.util.*; 
 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.http.HttpStatus; 
import org.springframework.http.ResponseEntity; 
import org.springframework.web.bind.annotation.CrossOrigin; 
import org.springframework.web.bind.annotation.DeleteMapping; 
import org.springframework.web.bind.annotation.GetMapping; 
import org.springframework.web.bind.annotation.PathVariable; 
import org.springframework.web.bind.annotation.PostMapping; 
import org.springframework.web.bind.annotation.PutMapping; 
import org.springframework.web.bind.annotation.RequestBody; 
import org.springframework.web.bind.annotation.RequestMapping; 
import org.springframework.web.bind.annotation.RequestParam; 
import org.springframework.web.bind.annotation.RestController; 
import org.springframework.transaction.annotation.Transactional; 
import org.springframework.format.annotation.DateTimeFormat; 
 
//Data Mesh API 
/*  
import org.springframework.web.reactive.function.client.WebClient; 
import org.springframework.http.HttpHeaders; 
import org.springframework.http.MediaType; 
import reactor.core.publisher.Mono; 
import org.springframework.core.ParameterizedTypeReference; 
*/  
 
//Pagination and Sorting 
import org.springframework.data.domain.Page; 
import org.springframework.data.domain.PageRequest; 
import org.springframework.data.domain.Pageable; 
import org.springframework.data.domain.Sort; 
 
import com.querydsl.core.types.dsl.BooleanExpression; 
 
import emrest.spring.ErpproductaddedtableTblRec; 
import emrest.spring.ErpproductaddedtableTblRecRepository; 
 
@CrossOrigin  
@RestController 
@RequestMapping("/emdbrest")  
public class ErpproductaddedtableTblRecDataRestController { 
 
	@Autowired 
	ErpproductaddedtableTblRecRepository ErpproductaddedtableTblRec1Repository; 
 
// -------------------- ViewAll ------------------------- 
 
@GetMapping("erp_product_added_table/ViewAll")  
public ResponseEntity<List<ErpproductaddedtableTblRec>> ErpproductaddedtableTblRecViewAll(@RequestParam(defaultValue = "0") int pageNo)  
	throws Exception 
	{   
	try { 
	List<ErpproductaddedtableTblRec> ErpproductaddedtableTblRecList = new ArrayList<ErpproductaddedtableTblRec>(); 
 
		//System.out.println("PageNo = "+pageNo); 
		if (pageNo == -1) { 
		ErpproductaddedtableTblRec1Repository.findAll().forEach(ErpproductaddedtableTblRecList::add); 
		} else { 
			//int pageNo = 0; 
			int pageSize = 10; 
			Pageable myPageParam =  PageRequest.of(pageNo, pageSize); 
			//Pageable myPageParam =  PageRequest.of(pageNo, pageSize, Sort.by("columnOne").descending().and(Sort.by("columnTwo"))); 
		ErpproductaddedtableTblRec1Repository.findAll(myPageParam).forEach(ErpproductaddedtableTblRecList::add); 
		} 
		//ErpproductaddedtableTblRec1Repository.findByColumnName(columnVal).forEach(ErpproductaddedtableTblRecList::add); 
 
	if (ErpproductaddedtableTblRecList.isEmpty()) { 
		return new ResponseEntity<>(HttpStatus.NO_CONTENT); 
	} 
 
	return new ResponseEntity<>(ErpproductaddedtableTblRecList, HttpStatus.OK); 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
 
// -------------------- SelectWhere ------------------------- 
 
@GetMapping("erp_product_added_table/SelectWhere")  
public ResponseEntity<List<ErpproductaddedtableTblRec>> ErpproductaddedtableTblRecSelectWhere(@RequestParam String searchBy, @RequestParam(defaultValue = "") String sortBy, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size) 
		throws Exception 
	{ 
	List<ErpproductaddedtableTblRec> ErpproductaddedtableTblRecList = new ArrayList<ErpproductaddedtableTblRec>(); 
	try { 
 
		System.out.println("search param = "+searchBy); 
		System.out.println("sort by = "+sortBy); 
 
		Pageable myPageParam; 
 
		if (page >= 0) { 
			myPageParam = PageRequest.of(page, size); 
			Sort mySort; 
			if (sortBy != null) { 
				if (sortBy.trim().length() > 0) { 
					EmSortBuilder sortBuild = new EmSortBuilder(sortBy); 
					if (sortBuild.gotSort) { 
						mySort = sortBuild.mySort; 
						myPageParam = PageRequest.of(page, size, mySort); 
					} 
				} 
			} 
			//myPageParam = PageRequest.of(page, size, Sort.by("columnOne").descending().and(Sort.by("columnTwo"))); 
			//Pls note: If using Sort, All the data is sorted first (matching Filter) and then page+size picked up 
		} else { // -1 fetchAll 
			myPageParam = Pageable.unpaged(); //Sort not possible then, use hack below if needed 
			//myPageParam = PageRequest.of(0, 999999999, Sort.by("columnOne").descending().and(Sort.by("columnTwo"))); 
		} 
 
		ErpproductaddedtableTblRecPredicatesBuilder builder = new ErpproductaddedtableTblRecPredicatesBuilder(searchBy); 
		BooleanExpression queryExpr = builder.build(); 
 
		ErpproductaddedtableTblRec1Repository.findAll(queryExpr, myPageParam).forEach(ErpproductaddedtableTblRecList::add); 
 
		//ErpproductaddedtableTblRec1Repository.findByColumnName(columnVal).forEach(ErpproductaddedtableTblRecList::add); 
 
		// if (ErpproductaddedtableTblRecList.isEmpty()) { 
		// } 
 
	if (ErpproductaddedtableTblRecList.isEmpty()) { 
		return new ResponseEntity<>(HttpStatus.NO_CONTENT); 
	} 
 
	return new ResponseEntity<>(ErpproductaddedtableTblRecList, HttpStatus.OK); 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
 
 // Data Mesh Sample Code: Combine / Fetch the data from other REST sources 
 
/* 
 	 Code-Help [CH] : Enable DataMesh Sample by steps below - 
 	 				  1-Uncomment Imports Required For Data Mesh  
 	 				  2-Uncomment Function Below  
*/ 
 
/* 
// -------------------- DataMesh ------------------------- 
 
@GetMapping("erp_product_added_table/DataMesh")  
public ResponseEntity<List<ErpproductaddedtableTblRec>> ErpproductaddedtableTblRecDataMesh()  
	throws Exception 
	{   
	try { 
	List<ErpproductaddedtableTblRec> ErpproductaddedtableTblRecList = new ArrayList<ErpproductaddedtableTblRec>(); 
 
		ErpproductaddedtableTblRec1Repository.findAll().forEach(ErpproductaddedtableTblRecList::add); 
 
				System.out.println("Data Mesh Source #1 Record Count: "+ErpproductaddedtableTblRecList.size()); 
 
				// ---- Combine Data With ---------------------------------------------------- 
				// Get data from REST API call (sample shows getting data from same table ViewAll API call) 
				//---------------------------------------------------------------------------- 
				String get_data_rest_url = "http://127.0.0.1:9080/emdbrest/erp_product_added_table/ViewAll?pageNo=-1"; //-1 == Unpaginated 
				WebClient webClientRest = WebClient.builder().baseUrl(get_data_rest_url) 
		        .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build(); 
 
				Mono<List<ErpproductaddedtableTblRec>> responseRest = 
				webClientRest.get() 
		        .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).retrieve() 
				.bodyToMono(new ParameterizedTypeReference<List<ErpproductaddedtableTblRec>>() {}); 
 
				List<ErpproductaddedtableTblRec> getMeshRestListErpproductaddedtableTblRec = responseRest.block(); 
 
				System.out.println("Data Mesh Source #2 Record Count: "+getMeshRestListErpproductaddedtableTblRec.size()); 
 
				getMeshRestListErpproductaddedtableTblRec.forEach(ErpproductaddedtableTblRecList::add); 
				//---------------------------------------------------------------------------- 
 
	if (ErpproductaddedtableTblRecList.isEmpty()) { 
		return new ResponseEntity<>(HttpStatus.NO_CONTENT); 
	} 
 
	return new ResponseEntity<>(ErpproductaddedtableTblRecList, HttpStatus.OK); 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
*/ 
 
 
/* 
// -------------------- FindByColumnName ------------------------- 
 
@GetMapping("erp_product_added_table/FindByColumnName")  
public ResponseEntity<List<ErpproductaddedtableTblRec>> ErpproductaddedtableTblRecFindByColumnName(@RequestParam String columnName)  
	throws Exception 
	{   
	try { 
	List<ErpproductaddedtableTblRec> ErpproductaddedtableTblRecList = new ArrayList<ErpproductaddedtableTblRec>(); 
 
		ErpproductaddedtableTblRec1Repository.findByColumnName(columnName).forEach(ErpproductaddedtableTblRecList::add); 
		//ErpproductaddedtableTblRec1Repository.findAll().forEach(ErpproductaddedtableTblRecList::add); 
 
	if (ErpproductaddedtableTblRecList.isEmpty()) { 
		return new ResponseEntity<>(HttpStatus.NO_CONTENT); 
	} 
 
	return new ResponseEntity<>(ErpproductaddedtableTblRecList, HttpStatus.OK); 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
 
*/ 
 
// -------------------- Query ------------------------- 
 
@GetMapping("erp_product_added_table/Query")  
public ResponseEntity<List<ErpproductaddedtableTblRec>> ErpproductaddedtableTblRecQuery(@RequestParam long productId)  
	throws Exception 
	{   
	try { 
	List<ErpproductaddedtableTblRec> ErpproductaddedtableTblRecList = new ArrayList<ErpproductaddedtableTblRec>(); 
 
		//ErpproductaddedtableTblRec1Repository.findAll().forEach(ErpproductaddedtableTblRecList::add); 
		ErpproductaddedtableTblRec1Repository.findByProductId(productId).forEach(ErpproductaddedtableTblRecList::add); 
 
	if (ErpproductaddedtableTblRecList.isEmpty()) { 
		return new ResponseEntity<>(HttpStatus.NO_CONTENT); 
	} 
 
	return new ResponseEntity<>(ErpproductaddedtableTblRecList, HttpStatus.OK); 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
  
// -------------------- Create ------------------------- 
 
@PostMapping("erp_product_added_table/Create")  
@Transactional 
public ResponseEntity<ErpproductaddedtableTblRec> ErpproductaddedtableTblRecCreate(@RequestBody ErpproductaddedtableTblRec ErpproductaddedtableTblRec1)  
	throws Exception 
	{   
	try { 
	ErpproductaddedtableTblRec _ErpproductaddedtableTblRec = ErpproductaddedtableTblRec1Repository 
			.save(ErpproductaddedtableTblRec1); 
 
			//If using @GeneratedValue for key, e.g. GenerationType.IDENTITY mysql auto_increment on table column, To get back Db Generated Id value, Use Below 
			//.savesaveAndFlush(ErpproductaddedtableTblRec1); 
 
	return new ResponseEntity<>(_ErpproductaddedtableTblRec, HttpStatus.CREATED); 
 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
 
// -------------------- Update ------------------------- 
 
@PutMapping("erp_product_added_table/Update")  
@Transactional 
public ResponseEntity<ErpproductaddedtableTblRec> ErpproductaddedtableTblRecUpdate(@RequestParam long productId, @RequestBody ErpproductaddedtableTblRec ErpproductaddedtableTblRec1)  
	throws Exception 
	{   
	try { 
 
		List<ErpproductaddedtableTblRec> ErpproductaddedtableTblRecRec1 = ErpproductaddedtableTblRec1Repository.findByProductId(productId); 
 
		if (ErpproductaddedtableTblRecRec1.isEmpty()) {  
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);  
		}  
 
		ErpproductaddedtableTblRec ErpproductaddedtableTblRecRec1First = ErpproductaddedtableTblRecRec1.get(0); 
		ErpproductaddedtableTblRec _ErpproductaddedtableTblRec = ErpproductaddedtableTblRec1Repository  
						.save(ErpproductaddedtableTblRec1);  
		return new ResponseEntity<>(_ErpproductaddedtableTblRec, HttpStatus.OK);  
 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
 
// -------------------- Delete ------------------------- 
 
@DeleteMapping("erp_product_added_table/Delete")  
@Transactional 
public ResponseEntity<Long> ErpproductaddedtableTblRecDelete(@RequestParam long productId)  
	throws Exception 
	{   
	try { 
 
	Long delCount = ErpproductaddedtableTblRec1Repository 
			.deleteByProductId(productId); 
			//.deleteAll(); 
	return new ResponseEntity<>(delCount, HttpStatus.OK); 
 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
 
} 
 
