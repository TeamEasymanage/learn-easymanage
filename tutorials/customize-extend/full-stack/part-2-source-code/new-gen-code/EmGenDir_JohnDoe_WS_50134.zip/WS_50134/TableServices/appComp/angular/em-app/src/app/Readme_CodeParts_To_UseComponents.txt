------------------------------------------------------------------ 
Em App Angular base setup project to use along with this generated angular app code: 
 
Download and setup from repository https://github.com/TeamEasymanage/em-app-angular 
Readme: https://github.com/TeamEasymanage/em-app-angular/blob/main/README.md 
 
Then Follow below steps to copy changes/files into that project 
 
------------------------------------------------------------------ 
ADD Following 2 parts to file em-app\src\app\app.module.ts : 
1) Imports 
 
import { ErpCustomerForm_5003832_C } from './ErpCustomer-form-5003832/ErpCustomer-form-5003832.component'; 
import { ErpCustomerDataTable_5003832_C } from './ErpCustomer-data-table-5003832/ErpCustomer-data-table-5003832.component'; 
import { ErpInventoryForm_5003834_C } from './ErpInventory-form-5003834/ErpInventory-form-5003834.component'; 
import { ErpInventoryDataTable_5003834_C } from './ErpInventory-data-table-5003834/ErpInventory-data-table-5003834.component'; 
import { ErpProductForm_5003836_C } from './ErpProduct-form-5003836/ErpProduct-form-5003836.component'; 
import { ErpProductDataTable_5003836_C } from './ErpProduct-data-table-5003836/ErpProduct-data-table-5003836.component'; 
import { ErpProductAddedTableForm_5003838_C } from './ErpProductAddedTable-form-5003838/ErpProductAddedTable-form-5003838.component'; 
import { ErpProductAddedTableDataTable_5003838_C } from './ErpProductAddedTable-data-table-5003838/ErpProductAddedTable-data-table-5003838.component'; 
import { ErpSalesInquiryForm_5003840_C } from './ErpSalesInquiry-form-5003840/ErpSalesInquiry-form-5003840.component'; 
import { ErpSalesInquiryDataTable_5003840_C } from './ErpSalesInquiry-data-table-5003840/ErpSalesInquiry-data-table-5003840.component'; 
import { ErpInventorySumVwForm_5003842_C } from './ErpInventorySumVw-form-5003842/ErpInventorySumVw-form-5003842.component'; 
import { ErpInventorySumVwDataTable_5003842_C } from './ErpInventorySumVw-data-table-5003842/ErpInventorySumVw-data-table-5003842.component'; 
import { ErpInventoryVwForm_5003844_C } from './ErpInventoryVw-form-5003844/ErpInventoryVw-form-5003844.component'; 
import { ErpInventoryVwDataTable_5003844_C } from './ErpInventoryVw-data-table-5003844/ErpInventoryVw-data-table-5003844.component'; 
 
2) @NgModule({   declarations: [ AppComponent, 
 
		ErpCustomerForm_5003832_C, 
		ErpCustomerDataTable_5003832_C, 
		ErpInventoryForm_5003834_C, 
		ErpInventoryDataTable_5003834_C, 
		ErpProductForm_5003836_C, 
		ErpProductDataTable_5003836_C, 
		ErpProductAddedTableForm_5003838_C, 
		ErpProductAddedTableDataTable_5003838_C, 
		ErpSalesInquiryForm_5003840_C, 
		ErpSalesInquiryDataTable_5003840_C, 
		ErpInventorySumVwForm_5003842_C, 
		ErpInventorySumVwDataTable_5003842_C, 
		ErpInventoryVwForm_5003844_C, 
		ErpInventoryVwDataTable_5003844_C, 
 
------------------------------------------------------------------ 
ADD Following 2 parts to file em-app\src\app\app-routing.module.ts : 
1) Imports 
 
import { ErpCustomerForm_5003832_C } from './ErpCustomer-form-5003832/ErpCustomer-form-5003832.component'; 
import { ErpCustomerDataTable_5003832_C } from './ErpCustomer-data-table-5003832/ErpCustomer-data-table-5003832.component'; 
import { ErpInventoryForm_5003834_C } from './ErpInventory-form-5003834/ErpInventory-form-5003834.component'; 
import { ErpInventoryDataTable_5003834_C } from './ErpInventory-data-table-5003834/ErpInventory-data-table-5003834.component'; 
import { ErpProductForm_5003836_C } from './ErpProduct-form-5003836/ErpProduct-form-5003836.component'; 
import { ErpProductDataTable_5003836_C } from './ErpProduct-data-table-5003836/ErpProduct-data-table-5003836.component'; 
import { ErpProductAddedTableForm_5003838_C } from './ErpProductAddedTable-form-5003838/ErpProductAddedTable-form-5003838.component'; 
import { ErpProductAddedTableDataTable_5003838_C } from './ErpProductAddedTable-data-table-5003838/ErpProductAddedTable-data-table-5003838.component'; 
import { ErpSalesInquiryForm_5003840_C } from './ErpSalesInquiry-form-5003840/ErpSalesInquiry-form-5003840.component'; 
import { ErpSalesInquiryDataTable_5003840_C } from './ErpSalesInquiry-data-table-5003840/ErpSalesInquiry-data-table-5003840.component'; 
import { ErpInventorySumVwForm_5003842_C } from './ErpInventorySumVw-form-5003842/ErpInventorySumVw-form-5003842.component'; 
import { ErpInventorySumVwDataTable_5003842_C } from './ErpInventorySumVw-data-table-5003842/ErpInventorySumVw-data-table-5003842.component'; 
import { ErpInventoryVwForm_5003844_C } from './ErpInventoryVw-form-5003844/ErpInventoryVw-form-5003844.component'; 
import { ErpInventoryVwDataTable_5003844_C } from './ErpInventoryVw-data-table-5003844/ErpInventoryVw-data-table-5003844.component'; 
 
2) const routes: Routes = [ 
 
	{ path: 'ErpCustomerForm_5003832_C', component: ErpCustomerForm_5003832_C },  
	{ path: 'ErpCustomerDataTable_5003832_C', component: ErpCustomerDataTable_5003832_C },  
	{ path: 'ErpInventoryForm_5003834_C', component: ErpInventoryForm_5003834_C },  
	{ path: 'ErpInventoryDataTable_5003834_C', component: ErpInventoryDataTable_5003834_C },  
	{ path: 'ErpProductForm_5003836_C', component: ErpProductForm_5003836_C },  
	{ path: 'ErpProductDataTable_5003836_C', component: ErpProductDataTable_5003836_C },  
	{ path: 'ErpProductAddedTableForm_5003838_C', component: ErpProductAddedTableForm_5003838_C },  
	{ path: 'ErpProductAddedTableDataTable_5003838_C', component: ErpProductAddedTableDataTable_5003838_C },  
	{ path: 'ErpSalesInquiryForm_5003840_C', component: ErpSalesInquiryForm_5003840_C },  
	{ path: 'ErpSalesInquiryDataTable_5003840_C', component: ErpSalesInquiryDataTable_5003840_C },  
	{ path: 'ErpInventorySumVwForm_5003842_C', component: ErpInventorySumVwForm_5003842_C },  
	{ path: 'ErpInventorySumVwDataTable_5003842_C', component: ErpInventorySumVwDataTable_5003842_C },  
	{ path: 'ErpInventoryVwForm_5003844_C', component: ErpInventoryVwForm_5003844_C },  
	{ path: 'ErpInventoryVwDataTable_5003844_C', component: ErpInventoryVwDataTable_5003844_C },  
 
------------------------------------------------------------------ 
ADD Following 1 parts to file em-app\src\app\em-nav\em-nav.component.html : 
1) SideNav Menu Links 
 
		<a mat-list-item href="/ErpCustomerForm_5003832_C">ErpCustomerForm_5003832</a> 
		<a mat-list-item href="/ErpCustomerDataTable_5003832_C">ErpCustomerDataTable_5003832</a> 
		<a mat-list-item href="/ErpInventoryForm_5003834_C">ErpInventoryForm_5003834</a> 
		<a mat-list-item href="/ErpInventoryDataTable_5003834_C">ErpInventoryDataTable_5003834</a> 
		<a mat-list-item href="/ErpProductForm_5003836_C">ErpProductForm_5003836</a> 
		<a mat-list-item href="/ErpProductDataTable_5003836_C">ErpProductDataTable_5003836</a> 
		<a mat-list-item href="/ErpProductAddedTableForm_5003838_C">ErpProductAddedTableForm_5003838</a> 
		<a mat-list-item href="/ErpProductAddedTableDataTable_5003838_C">ErpProductAddedTableDataTable_5003838</a> 
		<a mat-list-item href="/ErpSalesInquiryForm_5003840_C">ErpSalesInquiryForm_5003840</a> 
		<a mat-list-item href="/ErpSalesInquiryDataTable_5003840_C">ErpSalesInquiryDataTable_5003840</a> 
		<a mat-list-item href="/ErpInventorySumVwForm_5003842_C">ErpInventorySumVwForm_5003842</a> 
		<a mat-list-item href="/ErpInventorySumVwDataTable_5003842_C">ErpInventorySumVwDataTable_5003842</a> 
		<a mat-list-item href="/ErpInventoryVwForm_5003844_C">ErpInventoryVwForm_5003844</a> 
		<a mat-list-item href="/ErpInventoryVwDataTable_5003844_C">ErpInventoryVwDataTable_5003844</a> 
 
------------------------------------------------------------------ 
COPY All the generated component dirs from here (current dir) to dir: em-app\src\app\ : 
 
