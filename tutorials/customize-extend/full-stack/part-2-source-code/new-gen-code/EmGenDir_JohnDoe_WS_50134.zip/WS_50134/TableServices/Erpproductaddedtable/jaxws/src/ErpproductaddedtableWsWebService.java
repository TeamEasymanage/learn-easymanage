package ErpproductaddedtableWs.service;  
  
import java.lang.*; 
import java.util.*; 
import java.io.*; 
import javax.jws.WebMethod; 
import javax.jws.WebService; 
import javax.xml.bind.*; 
import javax.xml.bind.annotation.XmlType; 
import javax.xml.datatype.*; 
 
import ErpproductaddedtableWs.jaxb.*; 
 
import em.*; 
import emb.*; 
import emapi.*; 
 
@WebService(name="ErpproductaddedtableWsSvc",serviceName="ErpproductaddedtableWsService",portName="ErpproductaddedtableWsPort",targetNamespace="http://emws50.ErpproductaddedtableWs/jaxws") 
public class ErpproductaddedtableWsWebService { 
	private String message = new String("ErpproductaddedtableWs (jaxws): "); 
 
 
	//EM Name + Mode + Qry Opt : ErpproductaddedtableformDisplayAll 
 
	@WebMethod() 
	public  ErpproductaddedtableForm ErpproductaddedtableformDisplayAll()  
	throws Exception 
	{  
		ErpproductaddedtableForm wsForm1 = new ErpproductaddedtableForm(); 
 
		/********* Available for WP Scr only, not table 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,0,0,0,0,"ErpproductaddedtableForm","Erpproductaddedtable"); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		ErpproductaddedtableWs wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm1 = (ErpproductaddedtableForm) wsVar.getErpproductaddedtableForm();  
		*** Available for WP Scr only, not table  *****/
		return wsForm1; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproductaddedtable tbl1 = wsForm1.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs1 = tbl1.getErpproductaddedtableRecords(); 
		int tblrecs1_Count = tblrecs1.getErpproductaddedtableRec().size(); 
		System.out.println("Count Erpproductaddedtable Records = "+tblrecs1_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs1_Count > 0 ) { 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec1 = tblrecs1.getErpproductaddedtableRec().get(0); 
		ErpproductaddedtableFlds tblflds1 = tblrec1.getErpproductaddedtableFlds(); 
 		//Now Get ANY Fields/Columns as tblflds1.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		ErpproductaddedtableForm wsForm1 = new ErpproductaddedtableForm(); 
		Erpproductaddedtable tbl1 = new Erpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs1 = new ErpproductaddedtableRecords(); 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec1 = new ErpproductaddedtableRecords.ErpproductaddedtableRec(); 
		ErpproductaddedtableFlds tblflds1 = new ErpproductaddedtableFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getProductid();  
		//tblflds1.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds1.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductname();  
		//tblflds1.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds1.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductcategory();  
		//tblflds1.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds1.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getPrimarysupplier();  
		//tblflds1.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds1.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductdesc();  
		//tblflds1.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds1.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds1.getProductpicture();  
		//tblflds1.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds1.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductaddedcolumn();  
		//tblflds1.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds1.getProductaddedcolumn() ); 
 
		} // if (tblrecs1_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec1.setErpproductaddedtableFlds(tblflds1); 
		tblrecs1.getErpproductaddedtableRec().add(tblrec1); 
		tbl1.setErpproductaddedtableRecords(tblrecs1); 
		wsForm1.setErpproductaddedtable(tbl1); 
		return wsForm1; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
 
      private ErpproductaddedtableWs createJavaObjFromXmlStr(String p_xml_str) { 
	  ErpproductaddedtableWs wsVar = new ErpproductaddedtableWs();  
        try {  
            JAXBContext jc = JAXBContext.newInstance( "ErpproductaddedtableWs.jaxb" );  
            Unmarshaller u = jc.createUnmarshaller();  
            JAXBElement<?> wsElement = (JAXBElement<?>)u.unmarshal( new  
					StringReader( p_xml_str ) );  
 		//System.out.println("JAXBElement Name / Declared Type : "+ wsElement.getName() +" / "+ wsElement.getDeclaredType() );   
		wsVar = (ErpproductaddedtableWs) wsElement.getValue();  
  
        } catch( JAXBException je ) {  
            je.printStackTrace();  
        }  
	  return wsVar; 
     }  
 
      private String addRootXml(String p_str) {      
		String add_xml_str =  
		"<?xml version=\"1.0\" ?> "+"\n"+   
		"<ws1:ErpproductaddedtableWs xmlns:ws1=\"http://emws50.ErpproductaddedtableWs/jaxb/ErpproductaddedtableWs\" >   "+"\n"+ 
		p_str + 
		"</ws1:ErpproductaddedtableWs>   "+"\n"; 
 		return add_xml_str; 
      } 
 
 
 
} 
