package emrest.spring;  
  
//EM params for project  
//"yyyy-MM-dd HH:mm";  
  
public class EmParam {  
  
    public static final String emParamDateFmt = "yyyy-MM-dd";  
    public static final String emParamTimeFmt = "HH:mm";  
    public static final String emParamLocale = "en_US";  
 
} 
