 
import { Component } from '@angular/core'; 
import { FormBuilder, Validators } from '@angular/forms'; 
import { EmService } from '../em-service/em-service'; 
 
@Component({ 
  selector: 'app-ErpProductAddedTable-form-5003838', 
  templateUrl: './ErpProductAddedTable-form-5003838.html', 
  styleUrls: ['./ErpProductAddedTable-form-5003838.css'] 
}) 
export class ErpProductAddedTableForm_5003838_C { 
  ErpProductAddedTableForm_5003838_CForm = this.fb.group({ 
		productId : [null, Validators.required], /* long */ 
		productName : [null ], /* String */ 
		productCategory : [null ], /* String */ 
		primarySupplier : [null ], /* String */ 
		productDesc : [null ], /* String */ 
		productPicture : [null ], /* byte[] */ 
		productAddedColumn : [null ], /* String */ 
 
				/* [null, Validators.compose([ 
						Validators.required, 
						Validators.pattern('^[0-9]+$') 
						Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$') 
							]) ]  */ 
 }); 
 
  constructor(private fb: FormBuilder, private emService : EmService) {} 
 
  onSubmit(): void { 
	this.emService.POSTRecord( 
			JSON.stringify(this.ErpProductAddedTableForm_5003838_CForm.value), 
			"/erp_product_added_table/Create") 
		.subscribe(response => { 
				//console.log(response) 
		        console.log("api post call ok"); 
		  		alert('Added!');  
		}); 
 
  } 
} 
 
