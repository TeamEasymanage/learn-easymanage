// ------------------------------------------------------- 
// EM Parameters 
  
String emParamDateFmt = "yyyy-MM-dd";  
String emParamTimeFmt = "HH:mm";  
  
String emParamLocale = "en_US"; 
  
