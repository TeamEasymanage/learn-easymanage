Following Tables and Pages are processed : 
 
		----------------------------------- 
		Table      : erp_customer 
		Page       : ErpCustomer 
		Components : Data Table, Input Form, Edit, Delete, DropDown, Search, Graph 
  
		----------------------------------- 
		Table      : erp_inventory 
		Page       : ErpInventory 
		Components : Data Table, Input Form, Edit, Delete, DropDown, Search, Graph 
  
		----------------------------------- 
		Table      : erp_product 
		Page       : ErpProduct 
		Components : Data Table, Input Form, Edit, Delete, DropDown, Search, Graph 
  
		----------------------------------- 
		Table      : erp_product_added_table 
		Page       : ErpProductAddedTable 
		Components : Data Table, Input Form, Edit, Delete, DropDown, Search, Graph 
  
		----------------------------------- 
		Table      : erp_sales_inquiry 
		Page       : ErpSalesInquiry 
		Components : Data Table, Input Form, Edit, Delete, DropDown, Search, Graph 
  
		----------------------------------- 
		Table      : erp_inventory_sum_vw 
		Page       : ErpInventorySumVw 
		Components : Data Table, Input Form, Edit, Delete, DropDown, Search, Graph 
  
		----------------------------------- 
		Table      : erp_inventory_vw 
		Page       : ErpInventoryVw 
		Components : Data Table, Input Form, Edit, Delete, DropDown, Search, Graph 
  
 
