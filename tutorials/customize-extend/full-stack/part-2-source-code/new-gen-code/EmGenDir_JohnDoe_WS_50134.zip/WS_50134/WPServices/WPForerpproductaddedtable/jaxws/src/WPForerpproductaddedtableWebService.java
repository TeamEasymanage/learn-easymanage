package WPForerpproductaddedtable.service;  
  
import java.lang.*; 
import java.util.*; 
import java.io.*; 
import javax.jws.WebMethod; 
import javax.jws.WebService; 
import javax.xml.bind.*; 
import javax.xml.bind.annotation.XmlType; 
import javax.xml.datatype.*; 
 
import WPForerpproductaddedtable.jaxb.*; 
 
import em.*; 
import emb.*; 
import emapi.*; 
 
@WebService(name="WPForerpproductaddedtableSvc",serviceName="WPForerpproductaddedtableService",portName="WPForerpproductaddedtablePort",targetNamespace="http://emws50.WPForerpproductaddedtable/jaxws") 
public class WPForerpproductaddedtableWebService { 
	private String message = new String("WPForerpproductaddedtable (jaxws): "); 
 
 
	//EM Name + Mode + Qry Opt : ListallErpProductAddedTableDisplayAll 
 
	@WebMethod() 
	public  ListAllerpproductaddedtable ListallErpProductAddedTableDisplayAll()  
	throws Exception 
	{  
		ListAllerpproductaddedtable wsForm1 = new ListAllerpproductaddedtable(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007108,0,0,"ListAllerpproductaddedtable","Erpproductaddedtable"); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpproductaddedtable wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm1 = (ListAllerpproductaddedtable) wsVar.getListAllerpproductaddedtable();  
		return wsForm1; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproductaddedtable tbl1 = wsForm1.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs1 = tbl1.getErpproductaddedtableRecords(); 
		int tblrecs1_Count = tblrecs1.getErpproductaddedtableRec().size(); 
		System.out.println("Count Erpproductaddedtable Records = "+tblrecs1_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs1_Count > 0 ) { 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec1 = tblrecs1.getErpproductaddedtableRec().get(0); 
		ErpproductaddedtableFlds tblflds1 = tblrec1.getErpproductaddedtableFlds(); 
 		//Now Get ANY Fields/Columns as tblflds1.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		ListAllerpproductaddedtable wsForm1 = new ListAllerpproductaddedtable(); 
		Erpproductaddedtable tbl1 = new Erpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs1 = new ErpproductaddedtableRecords(); 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec1 = new ErpproductaddedtableRecords.ErpproductaddedtableRec(); 
		ErpproductaddedtableFlds tblflds1 = new ErpproductaddedtableFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getProductid();  
		//tblflds1.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds1.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductname();  
		//tblflds1.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds1.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductcategory();  
		//tblflds1.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds1.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getPrimarysupplier();  
		//tblflds1.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds1.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductdesc();  
		//tblflds1.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds1.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds1.getProductpicture();  
		//tblflds1.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds1.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductaddedcolumn();  
		//tblflds1.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds1.getProductaddedcolumn() ); 
 
		} // if (tblrecs1_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec1.setErpproductaddedtableFlds(tblflds1); 
		tblrecs1.getErpproductaddedtableRec().add(tblrec1); 
		tbl1.setErpproductaddedtableRecords(tblrecs1); 
		wsForm1.setErpproductaddedtable(tbl1); 
		return wsForm1; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
		//**** FILE / STREAM : GET / PUT FUNCTIONS  
			  
		@WebMethod()  
		public FileObj ListallErpProductAddedTableDisplayAllgetstreamproductpicture(String p_recno)    
		throws Exception   
		{    
			  
			FileObj fd = new FileObj();  
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007108,0,0,"ListAllerpproductaddedtable","Erpproductaddedtable"); 
			wpr.setDisRecNo(p_recno);   
			String[] tbl_ln_arr = { "S","","erp_product_added_table","product_picture","" }; 
			byte[] fdata = wpr.procWpReqGetFile(5003838,5010959,tbl_ln_arr);   
			String[] finfo = wpr.getFileInfo();  
			fd.setFileName(finfo[0]);  
			fd.setPath(finfo[1]); 
			fd.setContentType(finfo[2]); 
			if(finfo[3].trim().length() > 0) { 
			fd.setContentSize(Integer.valueOf(finfo[3]).intValue()); 
			} 
			fd.setNameSize(finfo[4]); 
			fd.setContentLink(finfo[5]); 
			fd.setFileData(fdata); 
			//System.out.println(finfo); 
			return fd; 
		} 
	 
		@WebMethod()  
		public String ListallErpProductAddedTableDisplayAllputstreamproductpicture(String p_recno, FileObj fo )   
		throws Exception  
		{   
	 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007108,0,0,"ListAllerpproductaddedtable","Erpproductaddedtable"); 
			wpr.setDisRecNo(p_recno);  
			String[] tbl_ln_arr = { "S","","erp_product_added_table","product_picture","" }; 
			String put_stat = wpr.procWpReqPutFile(5003838,5010959,tbl_ln_arr,  
						fo.getFileData(), 
						fo.getContentSize(), 
						fo.getFileName(), 
						fo.getContentType(), 
						fo.getPath()); 
			return put_stat; 
	      } 
	 
 
	//EM Name + Mode + Qry Opt : QueryErpProductAddedTableDisplayInputQuery 
 
	@WebMethod() 
	public  Queryerpproductaddedtable QueryErpProductAddedTableDisplayInputQuery( String[][] p_qryln, String[] p_qryarr)  
	throws Exception 
	{  
 
 
 
// Add Debug block to see what was passed 
/* 
System.out.println("------------"); 
for(int i=0;i<p_qryln[0].length;i++){ 
System.out.println(i+") "+p_qryln[0][i]); 
} 
for(int i=0;i<p_qryln[1].length;i++){ 
System.out.println(i+") "+p_qryln[1][i]); 
} 
System.out.println("------------"); 
for(int i=0;i<p_qryarr.length;i++){ 
System.out.println(i+") "+p_qryarr[i]); 
} 
*/ 
 
		Queryerpproductaddedtable wsForm2 = new Queryerpproductaddedtable(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007109,0,0,"Queryerpproductaddedtable","Erpproductaddedtable"); 
		wpr.setInputQry(p_qryln, p_qryarr); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpproductaddedtable wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm2 = (Queryerpproductaddedtable) wsVar.getQueryerpproductaddedtable();  
		return wsForm2; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproductaddedtable tbl2 = wsForm2.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs2 = tbl2.getErpproductaddedtableRecords(); 
		int tblrecs2_Count = tblrecs2.getErpproductaddedtableRec().size(); 
		System.out.println("Count Erpproductaddedtable Records = "+tblrecs2_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs2_Count > 0 ) { 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec2 = tblrecs2.getErpproductaddedtableRec().get(0); 
		ErpproductaddedtableFlds tblflds2 = tblrec2.getErpproductaddedtableFlds(); 
 		//Now Get ANY Fields/Columns as tblflds2.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		Queryerpproductaddedtable wsForm2 = new Queryerpproductaddedtable(); 
		Erpproductaddedtable tbl2 = new Erpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs2 = new ErpproductaddedtableRecords(); 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec2 = new ErpproductaddedtableRecords.ErpproductaddedtableRec(); 
		ErpproductaddedtableFlds tblflds2 = new ErpproductaddedtableFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getProductid();  
		//tblflds2.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds2.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductname();  
		//tblflds2.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds2.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductcategory();  
		//tblflds2.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds2.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getPrimarysupplier();  
		//tblflds2.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds2.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductdesc();  
		//tblflds2.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds2.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds2.getProductpicture();  
		//tblflds2.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds2.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductaddedcolumn();  
		//tblflds2.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds2.getProductaddedcolumn() ); 
 
		} // if (tblrecs2_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec2.setErpproductaddedtableFlds(tblflds2); 
		tblrecs2.getErpproductaddedtableRec().add(tblrec2); 
		tbl2.setErpproductaddedtableRecords(tblrecs2); 
		wsForm2.setErpproductaddedtable(tbl2); 
		return wsForm2; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
		//**** FILE / STREAM : GET / PUT FUNCTIONS  
			  
		@WebMethod()  
		public FileObj QueryErpProductAddedTableDisplayInputQuerygetstreamproductpicture(String p_recno)    
		throws Exception   
		{    
			  
			FileObj fd = new FileObj();  
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007109,0,0,"Queryerpproductaddedtable","Erpproductaddedtable"); 
			wpr.setDisRecNo(p_recno);   
			String[] tbl_ln_arr = { "S","","erp_product_added_table","product_picture","" }; 
			byte[] fdata = wpr.procWpReqGetFile(5003838,5010959,tbl_ln_arr);   
			String[] finfo = wpr.getFileInfo();  
			fd.setFileName(finfo[0]);  
			fd.setPath(finfo[1]); 
			fd.setContentType(finfo[2]); 
			if(finfo[3].trim().length() > 0) { 
			fd.setContentSize(Integer.valueOf(finfo[3]).intValue()); 
			} 
			fd.setNameSize(finfo[4]); 
			fd.setContentLink(finfo[5]); 
			fd.setFileData(fdata); 
			//System.out.println(finfo); 
			return fd; 
		} 
	 
		@WebMethod()  
		public String QueryErpProductAddedTableDisplayInputQueryputstreamproductpicture(String p_recno, FileObj fo )   
		throws Exception  
		{   
	 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007109,0,0,"Queryerpproductaddedtable","Erpproductaddedtable"); 
			wpr.setDisRecNo(p_recno);  
			String[] tbl_ln_arr = { "S","","erp_product_added_table","product_picture","" }; 
			String put_stat = wpr.procWpReqPutFile(5003838,5010959,tbl_ln_arr,  
						fo.getFileData(), 
						fo.getContentSize(), 
						fo.getFileName(), 
						fo.getContentType(), 
						fo.getPath()); 
			return put_stat; 
	      } 
	 
 
	//EM Name + Mode + Qry Opt : AddToErpProductAddedTableInput 
 
	@WebMethod() 
public  WpInfo AddToErpProductAddedTableInput( String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_AddToErpProductAddedTableInput(p_fldvalarr); 
	} 
 
public WpInfo sub_AddToErpProductAddedTableInput(String[][] p_fldvalarr)  
	throws Exception 
	{  
		AddToerpproductaddedtable wsForm3 = new AddToerpproductaddedtable(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007110,0,0,"AddToerpproductaddedtable","Erpproductaddedtable"); 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp3 = new WpInfo(); 
		wp3.setWpStatus(1); 
		wp3.setWpMessage(wpr.wpex_xml_str); 
		return wp3; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproductaddedtable tbl3 = wsForm3.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs3 = tbl3.getErpproductaddedtableRecords(); 
		int tblrecs3_Count = tblrecs3.getErpproductaddedtableRec().size(); 
		System.out.println("Count Erpproductaddedtable Records = "+tblrecs3_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs3_Count > 0 ) { 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec3 = tblrecs3.getErpproductaddedtableRec().get(0); 
		ErpproductaddedtableFlds tblflds3 = tblrec3.getErpproductaddedtableFlds(); 
 		//Now Get ANY Fields/Columns as tblflds3.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		AddToerpproductaddedtable wsForm3 = new AddToerpproductaddedtable(); 
		Erpproductaddedtable tbl3 = new Erpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs3 = new ErpproductaddedtableRecords(); 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec3 = new ErpproductaddedtableRecords.ErpproductaddedtableRec(); 
		ErpproductaddedtableFlds tblflds3 = new ErpproductaddedtableFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds3.getProductid();  
		//tblflds3.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds3.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductname();  
		//tblflds3.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds3.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductcategory();  
		//tblflds3.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds3.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getPrimarysupplier();  
		//tblflds3.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds3.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductdesc();  
		//tblflds3.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds3.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds3.getProductpicture();  
		//tblflds3.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds3.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductaddedcolumn();  
		//tblflds3.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds3.getProductaddedcolumn() ); 
 
		} // if (tblrecs3_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec3.setErpproductaddedtableFlds(tblflds3); 
		tblrecs3.getErpproductaddedtableRec().add(tblrec3); 
		tbl3.setErpproductaddedtableRecords(tblrecs3); 
		wsForm3.setErpproductaddedtable(tbl3); 
		return wsForm3; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
	//EM Name + Mode + Qry Opt : EditRecordErpProductAddedTableEditRecordNo 
 
	@WebMethod() 
public  WpInfo EditRecordErpProductAddedTableEditRecordNo( String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_EditRecordErpProductAddedTableEditRecordNo(p_fldvalarr); 
	} 
 
public WpInfo sub_EditRecordErpProductAddedTableEditRecordNo(String[][] p_fldvalarr)  
	throws Exception 
	{  
		EditRecorderpproductaddedtable wsForm4 = new EditRecorderpproductaddedtable(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007111,0,0,"EditRecorderpproductaddedtable","Erpproductaddedtable"); 
 
		//Check if {"EDITRECNO","10109"} element present then set it 
		if ((p_fldvalarr[0][0] != null) && (p_fldvalarr[0][0].equals("EDITRECNO"))) { 
			String v_recno = "" + p_fldvalarr[0][1]; 
			wpr.setEdtRecNo(v_recno); //If set invalid, Says Rec Added/Updated, but actually nothing happens 
		} 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp4 = new WpInfo(); 
		wp4.setWpStatus(1); 
		wp4.setWpMessage(wpr.wpex_xml_str); 
		return wp4; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproductaddedtable tbl4 = wsForm4.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs4 = tbl4.getErpproductaddedtableRecords(); 
		int tblrecs4_Count = tblrecs4.getErpproductaddedtableRec().size(); 
		System.out.println("Count Erpproductaddedtable Records = "+tblrecs4_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs4_Count > 0 ) { 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec4 = tblrecs4.getErpproductaddedtableRec().get(0); 
		ErpproductaddedtableFlds tblflds4 = tblrec4.getErpproductaddedtableFlds(); 
 		//Now Get ANY Fields/Columns as tblflds4.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		EditRecorderpproductaddedtable wsForm4 = new EditRecorderpproductaddedtable(); 
		Erpproductaddedtable tbl4 = new Erpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs4 = new ErpproductaddedtableRecords(); 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec4 = new ErpproductaddedtableRecords.ErpproductaddedtableRec(); 
		ErpproductaddedtableFlds tblflds4 = new ErpproductaddedtableFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds4.getProductid();  
		//tblflds4.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds4.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductname();  
		//tblflds4.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds4.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductcategory();  
		//tblflds4.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds4.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getPrimarysupplier();  
		//tblflds4.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds4.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductdesc();  
		//tblflds4.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds4.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds4.getProductpicture();  
		//tblflds4.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds4.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductaddedcolumn();  
		//tblflds4.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds4.getProductaddedcolumn() ); 
 
		} // if (tblrecs4_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec4.setErpproductaddedtableFlds(tblflds4); 
		tblrecs4.getErpproductaddedtableRec().add(tblrec4); 
		tbl4.setErpproductaddedtableRecords(tblrecs4); 
		wsForm4.setErpproductaddedtable(tbl4); 
		return wsForm4; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
 
      private WPForerpproductaddedtable createJavaObjFromXmlStr(String p_xml_str) { 
	  WPForerpproductaddedtable wsVar = new WPForerpproductaddedtable();  
        try {  
            JAXBContext jc = JAXBContext.newInstance( "WPForerpproductaddedtable.jaxb" );  
            Unmarshaller u = jc.createUnmarshaller();  
            JAXBElement<?> wsElement = (JAXBElement<?>)u.unmarshal( new  
					StringReader( p_xml_str ) );  
 		//System.out.println("JAXBElement Name / Declared Type : "+ wsElement.getName() +" / "+ wsElement.getDeclaredType() );   
		wsVar = (WPForerpproductaddedtable) wsElement.getValue();  
  
        } catch( JAXBException je ) {  
            je.printStackTrace();  
        }  
	  return wsVar; 
     }  
 
      private String addRootXml(String p_str) {      
		String add_xml_str =  
		"<?xml version=\"1.0\" ?> "+"\n"+   
		"<ws1:WPForerpproductaddedtable xmlns:ws1=\"http://emws50.WPForerpproductaddedtable/jaxb/WPForerpproductaddedtable\" >   "+"\n"+ 
		p_str + 
		"</ws1:WPForerpproductaddedtable>   "+"\n"; 
 		return add_xml_str; 
      } 
 
 
 
} 
