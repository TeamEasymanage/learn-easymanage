package WPForerpcustomerClient;  
  
import java.lang.*; 
import java.util.*; 
import javax.xml.datatype.*; 
import javax.xml.ws.WebServiceRef; 
 
import WPForerpcustomer.service.*; 
 
public class WPForerpcustomerClientWs { 
	@WebServiceRef (wsdlLocation="http://localhost:8080/WPForerpcustomerService/WPForerpcustomerService?wsdl")  
	static WPForerpcustomerService service; 
 
	public static void main(String[] args) { 
		try { 
			WPForerpcustomerClientWs client = new WPForerpcustomerClientWs(); 
			client.doTest(args); 
		     } catch(java.lang.Exception e) { 
				e.printStackTrace(); 
		    } 
	} 
     
	public void doTest(String[] args) { 
		try { 
		System.out.println("Retrieving the port from the following service: WPForerpcustomer ");  
		WPForerpcustomerSvc port = service.getWPForerpcustomerPort(); 
		System.out.println("Invoking the methods on the port."); 
		 
		//Process args 
		//if (args.length > 0) { 
		//    var1 = args[0]; 
		//} else { 
		//    var1 = ""; 
		//} 
 
		ObjectFactory ob1 = new ObjectFactory(); 
 
 
		System.out.println("Calling ListallErpCustomerDisplayAll(): [i.e. ListallErpCustomerDisplayAll] "); 
		ListAllerpcustomer wsForm1 = port.ListallErpCustomerDisplayAll(); 
		Erpcustomer tbl1 = wsForm1.getErpcustomer(); 
		ErpcustomerRecords tblrecs1 = tbl1.getErpcustomerRecords(); 
		List<ErpcustomerRecords.ErpcustomerRec> tblreclist1 = tblrecs1.getErpcustomerRec(); 
		ListIterator iter1 = tblreclist1.listIterator(); 
		System.out.println("ListAllerpcustomer : Erpcustomer : Records : "); 
		String StoreRecNo = ""; 
		while( iter1.hasNext()) { 
			ErpcustomerRecords.ErpcustomerRec tblrec1 = (ErpcustomerRecords.ErpcustomerRec) iter1.next(); 
			ErpcustomerFlds tblflds1 = (ErpcustomerFlds) tblrec1.getErpcustomerFlds(); 
 
 
		/******* TO Use Following, Uncomment this *** 
 
		//CustomerId : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getCustomerId();  
		//tblflds1.setCustomerId(); //ABCD_string 
		System.out.println("	CustomerId : " + tblflds1.getCustomerId() ); 
		//Name : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getName();  
		//tblflds1.setName(); //ABCD_string 
		System.out.println("	Name : " + tblflds1.getName() ); 
		//Phone : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getPhone();  
		//tblflds1.setPhone(); //ABCD_string 
		System.out.println("	Phone : " + tblflds1.getPhone() ); 
		//MobilePhone : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getMobilePhone();  
		//tblflds1.setMobilePhone(); //ABCD_string 
		System.out.println("	MobilePhone : " + tblflds1.getMobilePhone() ); 
		//Pict : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds1.getPict();  
		//tblflds1.setPict(); //base64Binary_DATA 
		System.out.println("	Pict : " + tblflds1.getPict() ); 
		//Email : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getEmail();  
		//tblflds1.setEmail(); //ABCD_string 
		System.out.println("	Email : " + tblflds1.getEmail() ); 
		//WebSite : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getWebSite();  
		//tblflds1.setWebSite(); //ABCD_string 
		System.out.println("	WebSite : " + tblflds1.getWebSite() ); 
		//Address : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getAddress();  
		//tblflds1.setAddress(); //ABCD_string 
		System.out.println("	Address : " + tblflds1.getAddress() ); 
		//DateOfInquiry : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds1.getDateOfInquiry();  
		//tblflds1.setDateOfInquiry(); //2006-06-01-05:30 
		System.out.println("	DateOfInquiry : " + tblflds1.getDateOfInquiry() ); 
		//RequestedQty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getRequestedQty();  
		//tblflds1.setRequestedQty(); //1234 
		System.out.println("	RequestedQty : " + tblflds1.getRequestedQty() ); 
		//ReqQuoteAmt : Java Data Type [float], XML Schema Type [float]  
		//tblflds1.getReqQuoteAmt();  
		//tblflds1.setReqQuoteAmt(); //1234.56 
		System.out.println("	ReqQuoteAmt : " + tblflds1.getReqQuoteAmt() ); 
		//MeetingPrefTime : Java Data Type [Calendar], XML Schema Type [time]  
		//tblflds1.getMeetingPrefTime();  
		//tblflds1.setMeetingPrefTime(); //14:10:00-05:30 
		System.out.println("	MeetingPrefTime : " + tblflds1.getMeetingPrefTime() ); 
		//Created : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds1.getCreated();  
		//tblflds1.setCreated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Created : " + tblflds1.getCreated() ); 
		//Updated : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds1.getUpdated();  
		//tblflds1.setUpdated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Updated : " + tblflds1.getUpdated() ); 
 
		******* TO Use Above, Uncomment this ***/ 
 
		RecInfo ri1 = tblrec1.getRecInfo(); 
		System.out.println("RecInfo : "+ri1.getSrlNo()+" , "+ri1.getRecNo()); 
 
 		//Note down 1st record no in StoreRecNo 
		if (ri1.getSrlNo() == 1 ) { StoreRecNo = ""+ri1.getRecNo(); } 
 
		} //while 
 
		WpInfo wi1 = wsForm1.getWpInfo(); 
		System.out.println("WpInfo : "+wi1.getWpStatus()+" , "+wi1.getWpRecords()); 
 
		System.out.println("Calling ListallErpCustomerDisplayAllgetstreampict():  ");  
 		if (StoreRecNo != null && StoreRecNo.trim().length() > 0 ) { 
		FileObj fo1_5 = port.ListallErpCustomerDisplayAllgetstreampict(StoreRecNo); //Record No  
 
		System.out.println("File Info: \n " +  					
		"FileName    : " + fo1_5.getFileName() + "\n" + 		
		"Path        : " + fo1_5.getPath() + "\n" +		
		"ContentType : " + fo1_5.getContentType() + "\n" +	 
		"ContentSize : " + fo1_5.getContentSize() + "\n" 	 
				); 									 
		System.out.println("File Content: "); 
		byte[] fdata1_5 = fo1_5.getFileData(); 
		if (fdata1_5.length > 0) {  
			System.out.println("Size: " + fdata1_5.length); 
		} else { 
			System.out.println("Received No File Content!"); 
		} 
 
		System.out.println("Calling ListallErpCustomerDisplayAllputstreampict():  "); 
 
		byte[] filedata1_5 = fdata1_5; 
		FileObj fs1_5 = ob1.createFileObj();  
		fs1_5.setFileName(fo1_5.getFileName()); //name.txt 
		fs1_5.setPath(fo1_5.getPath()); 
		fs1_5.setContentType(fo1_5.getContentType()); //text/html 
		fs1_5.setContentSize(filedata1_5.length); 
		fs1_5.setFileData(filedata1_5); 
 
		System.out.println(" //Provide correct Record No (in place of 10002) to put file obj and uncomment below line in code "); 
		System.out.println("String fput_stat1_5 = port.ListallErpCustomerDisplayAllputstreampict(\"10002\", fs1_5);  "); 
		//String fput_stat1_5 = port.ListallErpCustomerDisplayAllputstreampict("10002", fs1_5); //Record No, FileObj 
  
		//System.out.println("Put File: " + fput_stat1_5 ); 
		} else { 
			System.out.println("No Record Found to fetch File!"); 
		} 
 
 
		//Begin - Define Query Param Array for WP Scr No.: 2 
		String[][] qry2_ln = {   
		{ "Yes","","5010926:CHAR:Customer_Id","Like","","%" }  
		//Remove Comments, Use query lines below, up to max query lines allowed...	 
		//,{ "Yes","AND","5010927:CHAR:Name","Like","","%" }  
		//,{ "Yes","AND","5010928:CHAR:Phone","Like","","%" }  
		//,{ "Yes","AND","5010929:CHAR:Mobile_Phone","Like","","%" }  
		//,{ "Yes","AND","5010930:STREAM:Pict","Like","","%" }  
		//,{ "Yes","AND","5010931:CHAR:Email","Like","","%" }  
		//,{ "Yes","AND","5010932:CHAR:WebSite","Like","","%" }  
		//,{ "Yes","AND","5010933:TEXT:Address","Like","","%" }  
		//,{ "Yes","AND","5010934:DATE:DateOfInquiry","Like","","%" }  
		//,{ "Yes","AND","5010935:NUMBER:RequestedQty","Like","","%" }  
		//,{ "Yes","AND","5010936:FLOAT:ReqQuoteAmt","Like","","%" }  
		//,{ "Yes","AND","5010937:TIME:MeetingPrefTime","Like","","%" }  
		//,{ "Yes","AND","5010938:DATETIME:Created","Like","","%" }  
		//,{ "Yes","AND","5010939:DATETIME:Updated","Like","","%" }  
				};  
		 
		List<StringArray> p_qryln2 = new ArrayList<StringArray>(); 
		for (int j=0;j<qry2_ln.length;j++) {  
			StringArray qry2_aln = new StringArray(); 
		  for (int i=0;i<qry2_ln[j].length;i++) {  
			qry2_aln.getItem().add(qry2_ln[j][i]); 
		  } 
			p_qryln2.add(qry2_aln); 
		} 
		 
		List<String> p_qryatt2 = new ArrayList<String>(); 
		String[] qry2_att1 =    
		{ "","","","0","", "0","","","","","","" }   
		//{ "5010926:CHAR:Customer_Id","desc","200","0","%", "0","","","Yes","500","4","desc" }   
				;   
		for (int i=0;i<qry2_att1.length;i++) {  
			p_qryatt2.add(qry2_att1[i]);  
		} 
 
		System.out.println("Calling QueryErpCustomerDisplayInputQuery(): [i.e. QueryErpCustomerDisplayInputQuery] "); 
 
		Queryerpcustomer wsForm2 = port.QueryErpCustomerDisplayInputQuery(p_qryln2, p_qryatt2); 
		Erpcustomer tbl2 = wsForm2.getErpcustomer(); 
		ErpcustomerRecords tblrecs2 = tbl2.getErpcustomerRecords(); 
		List<ErpcustomerRecords.ErpcustomerRec> tblreclist2 = tblrecs2.getErpcustomerRec(); 
		ListIterator iter2 = tblreclist2.listIterator(); 
		System.out.println("Queryerpcustomer : Erpcustomer : Records : "); 
		String StoreRecNo = ""; 
		while( iter2.hasNext()) { 
			ErpcustomerRecords.ErpcustomerRec tblrec2 = (ErpcustomerRecords.ErpcustomerRec) iter2.next(); 
			ErpcustomerFlds tblflds2 = (ErpcustomerFlds) tblrec2.getErpcustomerFlds(); 
 
 
		/******* TO Use Following, Uncomment this *** 
 
		//CustomerId : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getCustomerId();  
		//tblflds2.setCustomerId(); //ABCD_string 
		System.out.println("	CustomerId : " + tblflds2.getCustomerId() ); 
		//Name : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getName();  
		//tblflds2.setName(); //ABCD_string 
		System.out.println("	Name : " + tblflds2.getName() ); 
		//Phone : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getPhone();  
		//tblflds2.setPhone(); //ABCD_string 
		System.out.println("	Phone : " + tblflds2.getPhone() ); 
		//MobilePhone : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getMobilePhone();  
		//tblflds2.setMobilePhone(); //ABCD_string 
		System.out.println("	MobilePhone : " + tblflds2.getMobilePhone() ); 
		//Pict : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds2.getPict();  
		//tblflds2.setPict(); //base64Binary_DATA 
		System.out.println("	Pict : " + tblflds2.getPict() ); 
		//Email : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getEmail();  
		//tblflds2.setEmail(); //ABCD_string 
		System.out.println("	Email : " + tblflds2.getEmail() ); 
		//WebSite : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getWebSite();  
		//tblflds2.setWebSite(); //ABCD_string 
		System.out.println("	WebSite : " + tblflds2.getWebSite() ); 
		//Address : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getAddress();  
		//tblflds2.setAddress(); //ABCD_string 
		System.out.println("	Address : " + tblflds2.getAddress() ); 
		//DateOfInquiry : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds2.getDateOfInquiry();  
		//tblflds2.setDateOfInquiry(); //2006-06-01-05:30 
		System.out.println("	DateOfInquiry : " + tblflds2.getDateOfInquiry() ); 
		//RequestedQty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getRequestedQty();  
		//tblflds2.setRequestedQty(); //1234 
		System.out.println("	RequestedQty : " + tblflds2.getRequestedQty() ); 
		//ReqQuoteAmt : Java Data Type [float], XML Schema Type [float]  
		//tblflds2.getReqQuoteAmt();  
		//tblflds2.setReqQuoteAmt(); //1234.56 
		System.out.println("	ReqQuoteAmt : " + tblflds2.getReqQuoteAmt() ); 
		//MeetingPrefTime : Java Data Type [Calendar], XML Schema Type [time]  
		//tblflds2.getMeetingPrefTime();  
		//tblflds2.setMeetingPrefTime(); //14:10:00-05:30 
		System.out.println("	MeetingPrefTime : " + tblflds2.getMeetingPrefTime() ); 
		//Created : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds2.getCreated();  
		//tblflds2.setCreated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Created : " + tblflds2.getCreated() ); 
		//Updated : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds2.getUpdated();  
		//tblflds2.setUpdated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Updated : " + tblflds2.getUpdated() ); 
 
		******* TO Use Above, Uncomment this ***/ 
 
		RecInfo ri2 = tblrec2.getRecInfo(); 
		System.out.println("RecInfo : "+ri2.getSrlNo()+" , "+ri2.getRecNo()); 
 
 		//Note down 1st record no in StoreRecNo 
		if (ri2.getSrlNo() == 1 ) { StoreRecNo = ""+ri2.getRecNo(); } 
 
		} //while 
 
		WpInfo wi2 = wsForm2.getWpInfo(); 
		System.out.println("WpInfo : "+wi2.getWpStatus()+" , "+wi2.getWpRecords()); 
 
		System.out.println("Calling QueryErpCustomerDisplayInputQuerygetstreampict():  ");  
 		if (StoreRecNo != null && StoreRecNo.trim().length() > 0 ) { 
		FileObj fo2_5 = port.QueryErpCustomerDisplayInputQuerygetstreampict(StoreRecNo); //Record No  
 
		System.out.println("File Info: \n " +  					
		"FileName    : " + fo2_5.getFileName() + "\n" + 		
		"Path        : " + fo2_5.getPath() + "\n" +		
		"ContentType : " + fo2_5.getContentType() + "\n" +	 
		"ContentSize : " + fo2_5.getContentSize() + "\n" 	 
				); 									 
		System.out.println("File Content: "); 
		byte[] fdata2_5 = fo2_5.getFileData(); 
		if (fdata2_5.length > 0) {  
			System.out.println("Size: " + fdata2_5.length); 
		} else { 
			System.out.println("Received No File Content!"); 
		} 
 
		System.out.println("Calling QueryErpCustomerDisplayInputQueryputstreampict():  "); 
 
		byte[] filedata2_5 = fdata2_5; 
		FileObj fs2_5 = ob1.createFileObj();  
		fs2_5.setFileName(fo2_5.getFileName()); //name.txt 
		fs2_5.setPath(fo2_5.getPath()); 
		fs2_5.setContentType(fo2_5.getContentType()); //text/html 
		fs2_5.setContentSize(filedata2_5.length); 
		fs2_5.setFileData(filedata2_5); 
 
		System.out.println(" //Provide correct Record No (in place of 10002) to put file obj and uncomment below line in code "); 
		System.out.println("String fput_stat2_5 = port.QueryErpCustomerDisplayInputQueryputstreampict(\"10002\", fs2_5);  "); 
		//String fput_stat2_5 = port.QueryErpCustomerDisplayInputQueryputstreampict("10002", fs2_5); //Record No, FileObj 
  
		//System.out.println("Put File: " + fput_stat2_5 ); 
		} else { 
			System.out.println("No Record Found to fetch File!"); 
		} 
 
 
		//Begin - Define Input Edit Record Array for WP Scr No.: 3 
 
		Date dt3 = new Date(); 
		String ctr3 = dt3.toString(); 
 
		//If using Edit Record No and wish to supply the record no then: 
		//	it should be the first pair in recarr, e.g. {"EDITRECNO","10109"} 
		//	Or the record no entered on WP Screen will be used. 
 
		String[][] p_fldvalarr3 = {  
						//{"EDITRECNO","10114"}, 
		{"F5010926","ABCD_string" }  //[CHAR]Value 
		,{"F5010927","ABCD_string" }  //[CHAR]Value 
		,{"F5010928","ABCD_string" }  //[CHAR]Value 
		,{"F5010929","ABCD_string" }  //[CHAR]Value 
		,{"F5010930","" }  //[STREAM]Value 
		,{"F5010931","ABCD_string" }  //[CHAR]Value 
		,{"F5010932","ABCD_string" }  //[CHAR]Value 
		,{"F5010933","ABCD_string" }  //[TEXT]Value 
		,{"F5010934","today" }  //[DATE]Value 
		,{"F5010935","1234" }  //[NUMBER]Value 
		,{"F5010936","1234.56" }  //[FLOAT]Value 
		,{"F5010937","now" }  //[TIME]Value 
		,{"F5010938","now" }  //[DATETIME]Value 
		,{"F5010939","now" }  //[DATETIME]Value 
					}; 
 
		List<StringArray> p_inprec3 = new ArrayList<StringArray>(); 
 
		for (int i=0;i<p_fldvalarr3.length;i++) { 
			StringArray t_arr3 = new StringArray(); 
			t_arr3.getItem().add(p_fldvalarr3[i][0]); 
			t_arr3.getItem().add(p_fldvalarr3[i][1]); 
			p_inprec3.add(t_arr3); 
		} 
 
 
		System.out.println("Calling AddToErpCustomerInput(): [i.e. AddToErpCustomerInput] "); 
 
		WpInfo wp3 = port.AddToErpCustomerInput(p_inprec3); 
 
		/******* TO Use Following, Uncomment this *** 
 
 
		******* TO Use Above, Uncomment this ***/ 
 
		System.out.println("WpInfo : Status : "+wp3.getWpStatus()); 
		System.out.println("WpInfo : Message : "+wp3.getWpMessage()+" , Error : "+wp3.getWpError()); 
 
 
		//Begin - Define Input Edit Record Array for WP Scr No.: 4 
 
		Date dt4 = new Date(); 
		String ctr4 = dt4.toString(); 
 
		//If using Edit Record No and wish to supply the record no then: 
		//	it should be the first pair in recarr, e.g. {"EDITRECNO","10109"} 
		//	Or the record no entered on WP Screen will be used. 
 
		String[][] p_fldvalarr4 = {  
						//{"EDITRECNO","10114"}, 
		{"F5010926","ABCD_string" }  //[CHAR]Value 
		,{"F5010927","ABCD_string" }  //[CHAR]Value 
		,{"F5010928","ABCD_string" }  //[CHAR]Value 
		,{"F5010929","ABCD_string" }  //[CHAR]Value 
		,{"F5010930","" }  //[STREAM]Value 
		,{"F5010931","ABCD_string" }  //[CHAR]Value 
		,{"F5010932","ABCD_string" }  //[CHAR]Value 
		,{"F5010933","ABCD_string" }  //[TEXT]Value 
		,{"F5010934","today" }  //[DATE]Value 
		,{"F5010935","1234" }  //[NUMBER]Value 
		,{"F5010936","1234.56" }  //[FLOAT]Value 
		,{"F5010937","now" }  //[TIME]Value 
		,{"F5010938","now" }  //[DATETIME]Value 
		,{"F5010939","now" }  //[DATETIME]Value 
					}; 
 
		List<StringArray> p_inprec4 = new ArrayList<StringArray>(); 
 
		for (int i=0;i<p_fldvalarr4.length;i++) { 
			StringArray t_arr4 = new StringArray(); 
			t_arr4.getItem().add(p_fldvalarr4[i][0]); 
			t_arr4.getItem().add(p_fldvalarr4[i][1]); 
			p_inprec4.add(t_arr4); 
		} 
 
 
		System.out.println("Calling EditRecordErpCustomerEditRecordNo(): [i.e. EditRecordErpCustomerEditRecordNo] "); 
 
		WpInfo wp4 = port.EditRecordErpCustomerEditRecordNo(p_inprec4); 
 
		/******* TO Use Following, Uncomment this *** 
 
 
		******* TO Use Above, Uncomment this ***/ 
 
		System.out.println("WpInfo : Status : "+wp4.getWpStatus()); 
		System.out.println("WpInfo : Message : "+wp4.getWpMessage()+" , Error : "+wp4.getWpError()); 
 
 
 
		} catch(java.lang.Exception e) { 
			e.printStackTrace(); 
		} 
	} 
} 
