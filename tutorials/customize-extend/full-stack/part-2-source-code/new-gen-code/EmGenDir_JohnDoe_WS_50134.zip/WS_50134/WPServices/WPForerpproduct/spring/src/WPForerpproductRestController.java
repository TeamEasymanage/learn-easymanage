package emrest.spring;  
  
import java.lang.*; 
import java.util.*; 
import java.text.*; 
import java.math.*; 
import java.io.*; 
import org.springframework.stereotype.Controller; 
import org.springframework.web.bind.annotation.*; 
import javax.xml.bind.*; 
import javax.xml.bind.annotation.XmlType; 
import javax.xml.datatype.*; 
import org.springframework.core.io.Resource; 
import org.springframework.core.io.ByteArrayResource; 
import org.springframework.core.io.UrlResource; 
import org.springframework.http.*; 
import org.springframework.web.multipart.MultipartFile; 
import org.springframework.beans.factory.annotation.Value; 
 
import WPForerpproduct.jaxb.*; 
 
import em.*; 
import emb.*; 
import emapi.*; 
 
@CrossOrigin  
@RestController 
@RequestMapping("/emrest/JohnDoe/WPForerpproduct") 
public class WPForerpproductRestController {  
	private String message = new String("WPForerpproduct (Spring): "); 
 
// ------------------------------------------------------------------------------ 
// ---------- Begin: Declarations and lib function for XML Date to java date to fldval string conversion 
// --- Note: Please set values for below as per EM User Profile : Date , Time Input Formats (but in java SimpleDateFormat format) ----  
@Value( "${emDateFmt:MM/d/yyyy}" ) 
private String emDateFmt; 
@Value( "${emTimeFmt:hh:mm:ss aa}" ) 
private String emTimeFmt; 
 
private String emConvXmlCalendarToStr(Calendar dateTime, String dttyp) { 
	String retDate = ""; 
	String dtfmt = emDateFmt; //default is DATE 
	if (dttyp.equals("DATETIME")) { 
		dtfmt = emDateFmt+" "+emTimeFmt; 
	} else if (dttyp.equals("TIME")) { 
		dtfmt = emTimeFmt; 
	} 
 
    try { 
	SimpleDateFormat toEmStrFmt = new SimpleDateFormat(dtfmt); 
	toEmStrFmt.setCalendar(dateTime); 
	retDate = toEmStrFmt.format(dateTime.getTime()); 
	} catch (Exception e) { 
      //e.printStackTrace(); 
   } 
	//System.out.println("Out Str = "+retDate); 
	return retDate; 
} 
//-------- Used by Spring Input Edit methods with json param 
private String[][]	emAddEditRecNoTo_fldvalarr(String RecNo, String[][] p_fldvalarr) { 
Vector<String[]> vec1 = new Vector<String[]>(); 
	vec1.add(new String[] { "EDITRECNO", RecNo } ); 
for (int i=0;i<p_fldvalarr.length;i++) { 
	vec1.add(p_fldvalarr[i]); 
} 
 
return vec1.toArray(new String[vec1.size()][2]); 
} 
private String toEmStr(String inputStr) { 
if (inputStr == null) { return ""; } 
return inputStr; 
} 
private String toEmStrInt(BigInteger inputVal) {  
if (inputVal == null) { return ""; }  
return inputVal.toString();  
}  
private String toEmStrFlt(Float inputVal) {  
if (inputVal == null) { return ""; }  
return Float.toString(inputVal); 
} 
 
// ---------- End: Declarations and lib function for XML Date to java date to fldval string conversion 
// ------------------------------------------------------------------------------ 
 
 
  
	// This is ADD-ON REST CALL available for Delete Record along with : EditRecordNo WebProject Mode 
  
@DeleteMapping("EditRecordErpProductDelRecNo")  
public @ResponseBody WpInfo EditRecordErpProductDelRecNo(@RequestParam String RecNo)  
	throws Exception 
	{  
		EditRecorderpproduct wsForm4 = new EditRecorderpproduct(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007107,0,0,"EditRecorderpproduct","Erpproduct"); 
 
		wpr.setDelRecNo(RecNo); //Setting this bypasses EditRecNo but process DeleteRecordNo in WsEmWpExec 
		wpr.procWpReq(); 
		WpInfo wp4 = new WpInfo(); 
		wp4.setWpStatus(1); 
		wp4.setWpMessage(wpr.wpex_xml_str); 
		return wp4; 
	}  
	  
 
private String[][] convErpproductFldsJsonToArr4(ErpproductFlds inpRec) { 
	//ErpproductFlds tblflds3 = new ErpproductFlds(); 
	Vector<String[]> flds1 = new Vector<String[]>();  
		flds1.add (new String[] { "F5010947" , toEmStrInt(inpRec.getProductid()) }) ;  //Productid  [NUMBER]Value 
		flds1.add (new String[] { "F5010948" , toEmStr(inpRec.getProductname()) }) ;  //Productname  [CHAR]Value 
		flds1.add (new String[] { "F5010949" , toEmStr(inpRec.getProductcategory()) }) ;  //Productcategory  [CHAR]Value 
		flds1.add (new String[] { "F5010950" , toEmStr(inpRec.getPrimarysupplier()) }) ;  //Primarysupplier  [CHAR]Value 
		flds1.add (new String[] { "F5010951" , toEmStr(inpRec.getProductdesc()) }) ;  //Productdesc  [TEXT]Value 
		//Note: (Use File Get/Put Functions For): "F5010952" - Productpicture  [STREAM]Value 
		flds1.add (new String[] { "F5010953" , toEmStr(inpRec.getProductaddedcolumn()) }) ;  //Productaddedcolumn  [CHAR]Value 

 
	return flds1.toArray(new String[flds1.size()][2]); 
		 
} 
  
 
  
@PostMapping("EditRecordErpProductEditRecordNo_json")  
public @ResponseBody WpInfo EditRecordErpProductEditRecordNo_json(@RequestParam String RecNo, @RequestBody ErpproductFlds inpRec)   
	throws Exception 
	{   
 
	String[][] p_fldvalarr = convErpproductFldsJsonToArr4(inpRec); 
	p_fldvalarr = emAddEditRecNoTo_fldvalarr(RecNo, p_fldvalarr);   
	return sub_EditRecordErpProductEditRecordNo(p_fldvalarr); 
 
} 
 
 
 
private String[][] convErpproductFldsJsonToArr3(ErpproductFlds inpRec) { 
	//ErpproductFlds tblflds3 = new ErpproductFlds(); 
	Vector<String[]> flds1 = new Vector<String[]>();  
		flds1.add (new String[] { "F5010947" , toEmStrInt(inpRec.getProductid()) }) ;  //Productid  [NUMBER]Value 
		flds1.add (new String[] { "F5010948" , toEmStr(inpRec.getProductname()) }) ;  //Productname  [CHAR]Value 
		flds1.add (new String[] { "F5010949" , toEmStr(inpRec.getProductcategory()) }) ;  //Productcategory  [CHAR]Value 
		flds1.add (new String[] { "F5010950" , toEmStr(inpRec.getPrimarysupplier()) }) ;  //Primarysupplier  [CHAR]Value 
		flds1.add (new String[] { "F5010951" , toEmStr(inpRec.getProductdesc()) }) ;  //Productdesc  [TEXT]Value 
		//Note: (Use File Get/Put Functions For): "F5010952" - Productpicture  [STREAM]Value 
		flds1.add (new String[] { "F5010953" , toEmStr(inpRec.getProductaddedcolumn()) }) ;  //Productaddedcolumn  [CHAR]Value 

 
	return flds1.toArray(new String[flds1.size()][2]); 
		 
} 
  
 
  
@PostMapping("AddToErpProductInput_json")  
public @ResponseBody WpInfo AddToErpProductInput_json(@RequestBody ErpproductFlds inpRec)   
	throws Exception 
	{   
 
	String[][] p_fldvalarr = convErpproductFldsJsonToArr3(inpRec); 
	return sub_AddToErpProductInput(p_fldvalarr); 
 
} 
 
 
 
 
 
 
 
 
 
	//EM Name + Mode + Qry Opt : ListallErpProductDisplayAll 
 
@GetMapping("ListallErpProductDisplayAll")  
	public @ResponseBody ListAllerpproduct ListallErpProductDisplayAll()  
	throws Exception 
	{  
		ListAllerpproduct wsForm1 = new ListAllerpproduct(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007104,0,0,"ListAllerpproduct","Erpproduct"); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpproduct wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm1 = (ListAllerpproduct) wsVar.getListAllerpproduct();  
		return wsForm1; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproduct tbl1 = wsForm1.getErpproduct(); 
		ErpproductRecords tblrecs1 = tbl1.getErpproductRecords(); 
		int tblrecs1_Count = tblrecs1.getErpproductRec().size(); 
		System.out.println("Count Erpproduct Records = "+tblrecs1_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs1_Count > 0 ) { 
		ErpproductRecords.ErpproductRec tblrec1 = tblrecs1.getErpproductRec().get(0); 
		ErpproductFlds tblflds1 = tblrec1.getErpproductFlds(); 
 		//Now Get ANY Fields/Columns as tblflds1.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		ListAllerpproduct wsForm1 = new ListAllerpproduct(); 
		Erpproduct tbl1 = new Erpproduct(); 
		ErpproductRecords tblrecs1 = new ErpproductRecords(); 
		ErpproductRecords.ErpproductRec tblrec1 = new ErpproductRecords.ErpproductRec(); 
		ErpproductFlds tblflds1 = new ErpproductFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getProductid();  
		//tblflds1.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds1.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductname();  
		//tblflds1.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds1.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductcategory();  
		//tblflds1.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds1.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getPrimarysupplier();  
		//tblflds1.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds1.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductdesc();  
		//tblflds1.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds1.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds1.getProductpicture();  
		//tblflds1.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds1.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductaddedcolumn();  
		//tblflds1.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds1.getProductaddedcolumn() ); 
 
		} // if (tblrecs1_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec1.setErpproductFlds(tblflds1); 
		tblrecs1.getErpproductRec().add(tblrec1); 
		tbl1.setErpproductRecords(tblrecs1); 
		wsForm1.setErpproduct(tbl1); 
		return wsForm1; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
		//**** Spring REST Wrapper : FILE / STREAM : GET / PUT FUNCTIONS  
			  
	@GetMapping("ListallErpProductDisplayAllgetstreamproductpicturerest") 
	public ResponseEntity<Resource> ListallErpProductDisplayAllgetstreamproductpicturerest(@RequestParam String p_recno)  
	throws Exception 
	{ 
		//default resource if FILE null 
		byte[] arr1 = "0".getBytes(); 
		Resource resource = new ByteArrayResource(arr1, "No File"); 
		 
		p_recno= p_recno.replaceAll("\"",""); 
		System.out.println("-----------------------------------------------------"); 
		System.out.println("p_recno = "+p_recno); 
		FileObj fd = new FileObj(); 
		 
		fd = ListallErpProductDisplayAllgetstreamproductpicture(p_recno); 
		 
		String p_filename = fd.getFileName();   
		String isFileorWebUrl = fd.getContentLink();  
		int fSize = fd.getContentSize();  
		String webURL = fd.getPath();  
		if (isFileorWebUrl == null ) { isFileorWebUrl = ""; } 
		isFileorWebUrl = isFileorWebUrl.trim(); 
		 
		String contentType = fd.getContentType(); 
		//default content type if no type 
		if((contentType == null)||(contentType.trim().length() < 1)) { 
			contentType = "application/octet-stream"; 
		} 
		 
		System.out.println("isFileorWebUrl = "+isFileorWebUrl); 
		System.out.println("p_filename = "+p_filename); 
		System.out.println("webURL = "+webURL); 
		System.out.println("contentType = "+contentType); 
		System.out.println("fSize = "+fSize); 
		System.out.println("-----------------------------------------------------"); 
		 
		String dn_filename = ""; 
		// Load file as Resource 
		if (isFileorWebUrl.equals("C")) { 
			dn_filename = webURL; 
			//byte[] arr2 = webURL.getBytes(); 
			//resource = new ByteArrayResource(arr2, "Web URL File"); 
			resource = new UrlResource(webURL); 
		} else { //not C 
			if (fSize > 0) { 
			dn_filename = p_filename; 
			resource = new ByteArrayResource(fd.getFileData()); 
			} else { 
			dn_filename = "File_Not_Found.txt"; 
			} 
		} 
		return ResponseEntity.ok() 
		    .contentType(MediaType.parseMediaType(contentType)) 
		    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + dn_filename + "\"") 
		    .body(resource); 
	} 
	 
	 
	//Note: PUT FILE of type Web URL Linking- not supported via web services 
	//		Following function supports uploading of FILE 
	 
	@PostMapping("ListallErpProductDisplayAllputstreamproductpicturerest") 
	public String ListallErpProductDisplayAllputstreamproductpicturerest( 
				@RequestParam String p_recno, 
				@RequestParam MultipartFile file)  
	throws Exception 
	{ 
		int p_size = Integer.valueOf(""+file.getSize()).intValue(); 
		String p_filename = file.getOriginalFilename(); 
		 
		p_recno= p_recno.replaceAll("\"",""); 
		 
		System.out.println("-----------------------------------------------------"); 
		System.out.println("p_recno = "+p_recno); 
		System.out.println("p_filename = "+p_filename); 
		System.out.println("p_size = "+p_size); 
		System.out.println("-----------------------------------------------------"); 
		 
		FileObj fd = new FileObj();   
		fd.setFileName(p_filename);   
		//fd.setPath(finfo[1]);  
		fd.setContentType(file.getContentType());  
		fd.setContentSize(p_size);  
		fd.setNameSize(p_filename +" "+p_size+" Bytes");  
		fd.setContentLink("");  
		fd.setFileData(file.getBytes());  
		 
		return ListallErpProductDisplayAllputstreamproductpicture(p_recno, fd); 
	} 
	 
		//**** FILE / STREAM : GET / PUT FUNCTIONS  
			  
		  
		public FileObj ListallErpProductDisplayAllgetstreamproductpicture(String p_recno)    
		throws Exception   
		{    
			  
			FileObj fd = new FileObj();  
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007104,0,0,"ListAllerpproduct","Erpproduct"); 
			wpr.setDisRecNo(p_recno);   
			String[] tbl_ln_arr = { "S","","erp_product","product_picture","" }; 
			byte[] fdata = wpr.procWpReqGetFile(5003836,5010952,tbl_ln_arr);   
			String[] finfo = wpr.getFileInfo();  
			fd.setFileName(finfo[0]);  
			fd.setPath(finfo[1]); 
			fd.setContentType(finfo[2]); 
			if(finfo[3].trim().length() > 0) { 
			fd.setContentSize(Integer.valueOf(finfo[3]).intValue()); 
			} 
			fd.setNameSize(finfo[4]); 
			fd.setContentLink(finfo[5]); 
			fd.setFileData(fdata); 
			//System.out.println(finfo); 
			return fd; 
		} 
	 
		  
		public String ListallErpProductDisplayAllputstreamproductpicture(String p_recno, FileObj fo )   
		throws Exception  
		{   
	 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007104,0,0,"ListAllerpproduct","Erpproduct"); 
			wpr.setDisRecNo(p_recno);  
			String[] tbl_ln_arr = { "S","","erp_product","product_picture","" }; 
			String put_stat = wpr.procWpReqPutFile(5003836,5010952,tbl_ln_arr,  
						fo.getFileData(), 
						fo.getContentSize(), 
						fo.getFileName(), 
						fo.getContentType(), 
						fo.getPath()); 
			return put_stat; 
	      } 
	 
 
	//EM Name + Mode + Qry Opt : QueryErpProductDisplayInputQuery 
 
@PostMapping("QueryErpProductDisplayInputQuery")  
	public @ResponseBody Queryerpproduct QueryErpProductDisplayInputQuery(@RequestBody EmQueryParam emq)  
	throws Exception 
	{  
 
String[][] p_qryln = emq.getQueryLine(); String[] p_qryarr = emq.getQueryArray(); 
 
// Add Debug block to see what was passed 
/* 
System.out.println("------------"); 
for(int i=0;i<p_qryln[0].length;i++){ 
System.out.println(i+") "+p_qryln[0][i]); 
} 
for(int i=0;i<p_qryln[1].length;i++){ 
System.out.println(i+") "+p_qryln[1][i]); 
} 
System.out.println("------------"); 
for(int i=0;i<p_qryarr.length;i++){ 
System.out.println(i+") "+p_qryarr[i]); 
} 
*/ 
 
		Queryerpproduct wsForm2 = new Queryerpproduct(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007105,0,0,"Queryerpproduct","Erpproduct"); 
		wpr.setInputQry(p_qryln, p_qryarr); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpproduct wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm2 = (Queryerpproduct) wsVar.getQueryerpproduct();  
		return wsForm2; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproduct tbl2 = wsForm2.getErpproduct(); 
		ErpproductRecords tblrecs2 = tbl2.getErpproductRecords(); 
		int tblrecs2_Count = tblrecs2.getErpproductRec().size(); 
		System.out.println("Count Erpproduct Records = "+tblrecs2_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs2_Count > 0 ) { 
		ErpproductRecords.ErpproductRec tblrec2 = tblrecs2.getErpproductRec().get(0); 
		ErpproductFlds tblflds2 = tblrec2.getErpproductFlds(); 
 		//Now Get ANY Fields/Columns as tblflds2.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		Queryerpproduct wsForm2 = new Queryerpproduct(); 
		Erpproduct tbl2 = new Erpproduct(); 
		ErpproductRecords tblrecs2 = new ErpproductRecords(); 
		ErpproductRecords.ErpproductRec tblrec2 = new ErpproductRecords.ErpproductRec(); 
		ErpproductFlds tblflds2 = new ErpproductFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getProductid();  
		//tblflds2.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds2.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductname();  
		//tblflds2.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds2.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductcategory();  
		//tblflds2.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds2.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getPrimarysupplier();  
		//tblflds2.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds2.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductdesc();  
		//tblflds2.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds2.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds2.getProductpicture();  
		//tblflds2.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds2.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductaddedcolumn();  
		//tblflds2.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds2.getProductaddedcolumn() ); 
 
		} // if (tblrecs2_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec2.setErpproductFlds(tblflds2); 
		tblrecs2.getErpproductRec().add(tblrec2); 
		tbl2.setErpproductRecords(tblrecs2); 
		wsForm2.setErpproduct(tbl2); 
		return wsForm2; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
		//**** Spring REST Wrapper : FILE / STREAM : GET / PUT FUNCTIONS  
			  
	@GetMapping("QueryErpProductDisplayInputQuerygetstreamproductpicturerest") 
	public ResponseEntity<Resource> QueryErpProductDisplayInputQuerygetstreamproductpicturerest(@RequestParam String p_recno)  
	throws Exception 
	{ 
		//default resource if FILE null 
		byte[] arr1 = "0".getBytes(); 
		Resource resource = new ByteArrayResource(arr1, "No File"); 
		 
		p_recno= p_recno.replaceAll("\"",""); 
		System.out.println("-----------------------------------------------------"); 
		System.out.println("p_recno = "+p_recno); 
		FileObj fd = new FileObj(); 
		 
		fd = QueryErpProductDisplayInputQuerygetstreamproductpicture(p_recno); 
		 
		String p_filename = fd.getFileName();   
		String isFileorWebUrl = fd.getContentLink();  
		int fSize = fd.getContentSize();  
		String webURL = fd.getPath();  
		if (isFileorWebUrl == null ) { isFileorWebUrl = ""; } 
		isFileorWebUrl = isFileorWebUrl.trim(); 
		 
		String contentType = fd.getContentType(); 
		//default content type if no type 
		if((contentType == null)||(contentType.trim().length() < 1)) { 
			contentType = "application/octet-stream"; 
		} 
		 
		System.out.println("isFileorWebUrl = "+isFileorWebUrl); 
		System.out.println("p_filename = "+p_filename); 
		System.out.println("webURL = "+webURL); 
		System.out.println("contentType = "+contentType); 
		System.out.println("fSize = "+fSize); 
		System.out.println("-----------------------------------------------------"); 
		 
		String dn_filename = ""; 
		// Load file as Resource 
		if (isFileorWebUrl.equals("C")) { 
			dn_filename = webURL; 
			//byte[] arr2 = webURL.getBytes(); 
			//resource = new ByteArrayResource(arr2, "Web URL File"); 
			resource = new UrlResource(webURL); 
		} else { //not C 
			if (fSize > 0) { 
			dn_filename = p_filename; 
			resource = new ByteArrayResource(fd.getFileData()); 
			} else { 
			dn_filename = "File_Not_Found.txt"; 
			} 
		} 
		return ResponseEntity.ok() 
		    .contentType(MediaType.parseMediaType(contentType)) 
		    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + dn_filename + "\"") 
		    .body(resource); 
	} 
	 
	 
	//Note: PUT FILE of type Web URL Linking- not supported via web services 
	//		Following function supports uploading of FILE 
	 
	@PostMapping("QueryErpProductDisplayInputQueryputstreamproductpicturerest") 
	public String QueryErpProductDisplayInputQueryputstreamproductpicturerest( 
				@RequestParam String p_recno, 
				@RequestParam MultipartFile file)  
	throws Exception 
	{ 
		int p_size = Integer.valueOf(""+file.getSize()).intValue(); 
		String p_filename = file.getOriginalFilename(); 
		 
		p_recno= p_recno.replaceAll("\"",""); 
		 
		System.out.println("-----------------------------------------------------"); 
		System.out.println("p_recno = "+p_recno); 
		System.out.println("p_filename = "+p_filename); 
		System.out.println("p_size = "+p_size); 
		System.out.println("-----------------------------------------------------"); 
		 
		FileObj fd = new FileObj();   
		fd.setFileName(p_filename);   
		//fd.setPath(finfo[1]);  
		fd.setContentType(file.getContentType());  
		fd.setContentSize(p_size);  
		fd.setNameSize(p_filename +" "+p_size+" Bytes");  
		fd.setContentLink("");  
		fd.setFileData(file.getBytes());  
		 
		return QueryErpProductDisplayInputQueryputstreamproductpicture(p_recno, fd); 
	} 
	 
		//**** FILE / STREAM : GET / PUT FUNCTIONS  
			  
		  
		public FileObj QueryErpProductDisplayInputQuerygetstreamproductpicture(String p_recno)    
		throws Exception   
		{    
			  
			FileObj fd = new FileObj();  
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007105,0,0,"Queryerpproduct","Erpproduct"); 
			wpr.setDisRecNo(p_recno);   
			String[] tbl_ln_arr = { "S","","erp_product","product_picture","" }; 
			byte[] fdata = wpr.procWpReqGetFile(5003836,5010952,tbl_ln_arr);   
			String[] finfo = wpr.getFileInfo();  
			fd.setFileName(finfo[0]);  
			fd.setPath(finfo[1]); 
			fd.setContentType(finfo[2]); 
			if(finfo[3].trim().length() > 0) { 
			fd.setContentSize(Integer.valueOf(finfo[3]).intValue()); 
			} 
			fd.setNameSize(finfo[4]); 
			fd.setContentLink(finfo[5]); 
			fd.setFileData(fdata); 
			//System.out.println(finfo); 
			return fd; 
		} 
	 
		  
		public String QueryErpProductDisplayInputQueryputstreamproductpicture(String p_recno, FileObj fo )   
		throws Exception  
		{   
	 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007105,0,0,"Queryerpproduct","Erpproduct"); 
			wpr.setDisRecNo(p_recno);  
			String[] tbl_ln_arr = { "S","","erp_product","product_picture","" }; 
			String put_stat = wpr.procWpReqPutFile(5003836,5010952,tbl_ln_arr,  
						fo.getFileData(), 
						fo.getContentSize(), 
						fo.getFileName(), 
						fo.getContentType(), 
						fo.getPath()); 
			return put_stat; 
	      } 
	 
 
	//EM Name + Mode + Qry Opt : AddToErpProductInput 
 
@PostMapping("AddToErpProductInput")  
public @ResponseBody WpInfo AddToErpProductInput(@RequestBody String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_AddToErpProductInput(p_fldvalarr); 
	} 
 
public WpInfo sub_AddToErpProductInput(String[][] p_fldvalarr)  
	throws Exception 
	{  
		AddToerpproduct wsForm3 = new AddToerpproduct(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007106,0,0,"AddToerpproduct","Erpproduct"); 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp3 = new WpInfo(); 
		wp3.setWpStatus(1); 
		wp3.setWpMessage(wpr.wpex_xml_str); 
		return wp3; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproduct tbl3 = wsForm3.getErpproduct(); 
		ErpproductRecords tblrecs3 = tbl3.getErpproductRecords(); 
		int tblrecs3_Count = tblrecs3.getErpproductRec().size(); 
		System.out.println("Count Erpproduct Records = "+tblrecs3_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs3_Count > 0 ) { 
		ErpproductRecords.ErpproductRec tblrec3 = tblrecs3.getErpproductRec().get(0); 
		ErpproductFlds tblflds3 = tblrec3.getErpproductFlds(); 
 		//Now Get ANY Fields/Columns as tblflds3.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		AddToerpproduct wsForm3 = new AddToerpproduct(); 
		Erpproduct tbl3 = new Erpproduct(); 
		ErpproductRecords tblrecs3 = new ErpproductRecords(); 
		ErpproductRecords.ErpproductRec tblrec3 = new ErpproductRecords.ErpproductRec(); 
		ErpproductFlds tblflds3 = new ErpproductFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds3.getProductid();  
		//tblflds3.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds3.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductname();  
		//tblflds3.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds3.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductcategory();  
		//tblflds3.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds3.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getPrimarysupplier();  
		//tblflds3.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds3.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductdesc();  
		//tblflds3.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds3.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds3.getProductpicture();  
		//tblflds3.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds3.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductaddedcolumn();  
		//tblflds3.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds3.getProductaddedcolumn() ); 
 
		} // if (tblrecs3_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec3.setErpproductFlds(tblflds3); 
		tblrecs3.getErpproductRec().add(tblrec3); 
		tbl3.setErpproductRecords(tblrecs3); 
		wsForm3.setErpproduct(tbl3); 
		return wsForm3; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
	//EM Name + Mode + Qry Opt : EditRecordErpProductEditRecordNo 
 
@PutMapping("EditRecordErpProductEditRecordNo")  
public @ResponseBody WpInfo EditRecordErpProductEditRecordNo(@RequestBody String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_EditRecordErpProductEditRecordNo(p_fldvalarr); 
	} 
 
public WpInfo sub_EditRecordErpProductEditRecordNo(String[][] p_fldvalarr)  
	throws Exception 
	{  
		EditRecorderpproduct wsForm4 = new EditRecorderpproduct(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007107,0,0,"EditRecorderpproduct","Erpproduct"); 
 
		//Check if {"EDITRECNO","10109"} element present then set it 
		if ((p_fldvalarr[0][0] != null) && (p_fldvalarr[0][0].equals("EDITRECNO"))) { 
			String v_recno = "" + p_fldvalarr[0][1]; 
			wpr.setEdtRecNo(v_recno); //If set invalid, Says Rec Added/Updated, but actually nothing happens 
		} 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp4 = new WpInfo(); 
		wp4.setWpStatus(1); 
		wp4.setWpMessage(wpr.wpex_xml_str); 
		return wp4; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproduct tbl4 = wsForm4.getErpproduct(); 
		ErpproductRecords tblrecs4 = tbl4.getErpproductRecords(); 
		int tblrecs4_Count = tblrecs4.getErpproductRec().size(); 
		System.out.println("Count Erpproduct Records = "+tblrecs4_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs4_Count > 0 ) { 
		ErpproductRecords.ErpproductRec tblrec4 = tblrecs4.getErpproductRec().get(0); 
		ErpproductFlds tblflds4 = tblrec4.getErpproductFlds(); 
 		//Now Get ANY Fields/Columns as tblflds4.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		EditRecorderpproduct wsForm4 = new EditRecorderpproduct(); 
		Erpproduct tbl4 = new Erpproduct(); 
		ErpproductRecords tblrecs4 = new ErpproductRecords(); 
		ErpproductRecords.ErpproductRec tblrec4 = new ErpproductRecords.ErpproductRec(); 
		ErpproductFlds tblflds4 = new ErpproductFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds4.getProductid();  
		//tblflds4.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds4.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductname();  
		//tblflds4.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds4.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductcategory();  
		//tblflds4.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds4.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getPrimarysupplier();  
		//tblflds4.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds4.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductdesc();  
		//tblflds4.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds4.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds4.getProductpicture();  
		//tblflds4.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds4.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductaddedcolumn();  
		//tblflds4.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds4.getProductaddedcolumn() ); 
 
		} // if (tblrecs4_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec4.setErpproductFlds(tblflds4); 
		tblrecs4.getErpproductRec().add(tblrec4); 
		tbl4.setErpproductRecords(tblrecs4); 
		wsForm4.setErpproduct(tbl4); 
		return wsForm4; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
 
      private WPForerpproduct createJavaObjFromXmlStr(String p_xml_str) { 
	  WPForerpproduct wsVar = new WPForerpproduct();  
        try {  
            JAXBContext jc = JAXBContext.newInstance( "WPForerpproduct.jaxb" );  
            Unmarshaller u = jc.createUnmarshaller();  
            JAXBElement<?> wsElement = (JAXBElement<?>)u.unmarshal( new  
					StringReader( p_xml_str ) );  
 		//System.out.println("JAXBElement Name / Declared Type : "+ wsElement.getName() +" / "+ wsElement.getDeclaredType() );   
		wsVar = (WPForerpproduct) wsElement.getValue();  
  
        } catch( JAXBException je ) {  
            je.printStackTrace();  
        }  
	  return wsVar; 
     }  
 
      private String addRootXml(String p_str) {      
		String add_xml_str =  
		"<?xml version=\"1.0\" ?> "+"\n"+   
		"<ws1:WPForerpproduct xmlns:ws1=\"http://emws50.WPForerpproduct/jaxb/WPForerpproduct\" >   "+"\n"+ 
		p_str + 
		"</ws1:WPForerpproduct>   "+"\n"; 
 		return add_xml_str; 
      } 
 
 
 
} 
