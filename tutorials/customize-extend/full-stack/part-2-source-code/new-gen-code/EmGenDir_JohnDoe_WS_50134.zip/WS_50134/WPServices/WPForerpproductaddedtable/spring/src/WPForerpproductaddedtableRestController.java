package emrest.spring;  
  
import java.lang.*; 
import java.util.*; 
import java.text.*; 
import java.math.*; 
import java.io.*; 
import org.springframework.stereotype.Controller; 
import org.springframework.web.bind.annotation.*; 
import javax.xml.bind.*; 
import javax.xml.bind.annotation.XmlType; 
import javax.xml.datatype.*; 
import org.springframework.core.io.Resource; 
import org.springframework.core.io.ByteArrayResource; 
import org.springframework.core.io.UrlResource; 
import org.springframework.http.*; 
import org.springframework.web.multipart.MultipartFile; 
import org.springframework.beans.factory.annotation.Value; 
 
import WPForerpproductaddedtable.jaxb.*; 
 
import em.*; 
import emb.*; 
import emapi.*; 
 
@CrossOrigin  
@RestController 
@RequestMapping("/emrest/JohnDoe/WPForerpproductaddedtable") 
public class WPForerpproductaddedtableRestController {  
	private String message = new String("WPForerpproductaddedtable (Spring): "); 
 
// ------------------------------------------------------------------------------ 
// ---------- Begin: Declarations and lib function for XML Date to java date to fldval string conversion 
// --- Note: Please set values for below as per EM User Profile : Date , Time Input Formats (but in java SimpleDateFormat format) ----  
@Value( "${emDateFmt:MM/d/yyyy}" ) 
private String emDateFmt; 
@Value( "${emTimeFmt:hh:mm:ss aa}" ) 
private String emTimeFmt; 
 
private String emConvXmlCalendarToStr(Calendar dateTime, String dttyp) { 
	String retDate = ""; 
	String dtfmt = emDateFmt; //default is DATE 
	if (dttyp.equals("DATETIME")) { 
		dtfmt = emDateFmt+" "+emTimeFmt; 
	} else if (dttyp.equals("TIME")) { 
		dtfmt = emTimeFmt; 
	} 
 
    try { 
	SimpleDateFormat toEmStrFmt = new SimpleDateFormat(dtfmt); 
	toEmStrFmt.setCalendar(dateTime); 
	retDate = toEmStrFmt.format(dateTime.getTime()); 
	} catch (Exception e) { 
      //e.printStackTrace(); 
   } 
	//System.out.println("Out Str = "+retDate); 
	return retDate; 
} 
//-------- Used by Spring Input Edit methods with json param 
private String[][]	emAddEditRecNoTo_fldvalarr(String RecNo, String[][] p_fldvalarr) { 
Vector<String[]> vec1 = new Vector<String[]>(); 
	vec1.add(new String[] { "EDITRECNO", RecNo } ); 
for (int i=0;i<p_fldvalarr.length;i++) { 
	vec1.add(p_fldvalarr[i]); 
} 
 
return vec1.toArray(new String[vec1.size()][2]); 
} 
private String toEmStr(String inputStr) { 
if (inputStr == null) { return ""; } 
return inputStr; 
} 
private String toEmStrInt(BigInteger inputVal) {  
if (inputVal == null) { return ""; }  
return inputVal.toString();  
}  
private String toEmStrFlt(Float inputVal) {  
if (inputVal == null) { return ""; }  
return Float.toString(inputVal); 
} 
 
// ---------- End: Declarations and lib function for XML Date to java date to fldval string conversion 
// ------------------------------------------------------------------------------ 
 
 
  
	// This is ADD-ON REST CALL available for Delete Record along with : EditRecordNo WebProject Mode 
  
@DeleteMapping("EditRecordErpProductAddedTableDelRecNo")  
public @ResponseBody WpInfo EditRecordErpProductAddedTableDelRecNo(@RequestParam String RecNo)  
	throws Exception 
	{  
		EditRecorderpproductaddedtable wsForm4 = new EditRecorderpproductaddedtable(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007111,0,0,"EditRecorderpproductaddedtable","Erpproductaddedtable"); 
 
		wpr.setDelRecNo(RecNo); //Setting this bypasses EditRecNo but process DeleteRecordNo in WsEmWpExec 
		wpr.procWpReq(); 
		WpInfo wp4 = new WpInfo(); 
		wp4.setWpStatus(1); 
		wp4.setWpMessage(wpr.wpex_xml_str); 
		return wp4; 
	}  
	  
 
private String[][] convErpproductaddedtableFldsJsonToArr4(ErpproductaddedtableFlds inpRec) { 
	//ErpproductaddedtableFlds tblflds3 = new ErpproductaddedtableFlds(); 
	Vector<String[]> flds1 = new Vector<String[]>();  
		flds1.add (new String[] { "F5010954" , toEmStrInt(inpRec.getProductid()) }) ;  //Productid  [NUMBER]Value 
		flds1.add (new String[] { "F5010955" , toEmStr(inpRec.getProductname()) }) ;  //Productname  [CHAR]Value 
		flds1.add (new String[] { "F5010956" , toEmStr(inpRec.getProductcategory()) }) ;  //Productcategory  [CHAR]Value 
		flds1.add (new String[] { "F5010957" , toEmStr(inpRec.getPrimarysupplier()) }) ;  //Primarysupplier  [CHAR]Value 
		flds1.add (new String[] { "F5010958" , toEmStr(inpRec.getProductdesc()) }) ;  //Productdesc  [TEXT]Value 
		//Note: (Use File Get/Put Functions For): "F5010959" - Productpicture  [STREAM]Value 
		flds1.add (new String[] { "F5010960" , toEmStr(inpRec.getProductaddedcolumn()) }) ;  //Productaddedcolumn  [CHAR]Value 

 
	return flds1.toArray(new String[flds1.size()][2]); 
		 
} 
  
 
  
@PostMapping("EditRecordErpProductAddedTableEditRecordNo_json")  
public @ResponseBody WpInfo EditRecordErpProductAddedTableEditRecordNo_json(@RequestParam String RecNo, @RequestBody ErpproductaddedtableFlds inpRec)   
	throws Exception 
	{   
 
	String[][] p_fldvalarr = convErpproductaddedtableFldsJsonToArr4(inpRec); 
	p_fldvalarr = emAddEditRecNoTo_fldvalarr(RecNo, p_fldvalarr);   
	return sub_EditRecordErpProductAddedTableEditRecordNo(p_fldvalarr); 
 
} 
 
 
 
private String[][] convErpproductaddedtableFldsJsonToArr3(ErpproductaddedtableFlds inpRec) { 
	//ErpproductaddedtableFlds tblflds3 = new ErpproductaddedtableFlds(); 
	Vector<String[]> flds1 = new Vector<String[]>();  
		flds1.add (new String[] { "F5010954" , toEmStrInt(inpRec.getProductid()) }) ;  //Productid  [NUMBER]Value 
		flds1.add (new String[] { "F5010955" , toEmStr(inpRec.getProductname()) }) ;  //Productname  [CHAR]Value 
		flds1.add (new String[] { "F5010956" , toEmStr(inpRec.getProductcategory()) }) ;  //Productcategory  [CHAR]Value 
		flds1.add (new String[] { "F5010957" , toEmStr(inpRec.getPrimarysupplier()) }) ;  //Primarysupplier  [CHAR]Value 
		flds1.add (new String[] { "F5010958" , toEmStr(inpRec.getProductdesc()) }) ;  //Productdesc  [TEXT]Value 
		//Note: (Use File Get/Put Functions For): "F5010959" - Productpicture  [STREAM]Value 
		flds1.add (new String[] { "F5010960" , toEmStr(inpRec.getProductaddedcolumn()) }) ;  //Productaddedcolumn  [CHAR]Value 

 
	return flds1.toArray(new String[flds1.size()][2]); 
		 
} 
  
 
  
@PostMapping("AddToErpProductAddedTableInput_json")  
public @ResponseBody WpInfo AddToErpProductAddedTableInput_json(@RequestBody ErpproductaddedtableFlds inpRec)   
	throws Exception 
	{   
 
	String[][] p_fldvalarr = convErpproductaddedtableFldsJsonToArr3(inpRec); 
	return sub_AddToErpProductAddedTableInput(p_fldvalarr); 
 
} 
 
 
 
 
 
 
 
 
 
	//EM Name + Mode + Qry Opt : ListallErpProductAddedTableDisplayAll 
 
@GetMapping("ListallErpProductAddedTableDisplayAll")  
	public @ResponseBody ListAllerpproductaddedtable ListallErpProductAddedTableDisplayAll()  
	throws Exception 
	{  
		ListAllerpproductaddedtable wsForm1 = new ListAllerpproductaddedtable(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007108,0,0,"ListAllerpproductaddedtable","Erpproductaddedtable"); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpproductaddedtable wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm1 = (ListAllerpproductaddedtable) wsVar.getListAllerpproductaddedtable();  
		return wsForm1; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproductaddedtable tbl1 = wsForm1.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs1 = tbl1.getErpproductaddedtableRecords(); 
		int tblrecs1_Count = tblrecs1.getErpproductaddedtableRec().size(); 
		System.out.println("Count Erpproductaddedtable Records = "+tblrecs1_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs1_Count > 0 ) { 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec1 = tblrecs1.getErpproductaddedtableRec().get(0); 
		ErpproductaddedtableFlds tblflds1 = tblrec1.getErpproductaddedtableFlds(); 
 		//Now Get ANY Fields/Columns as tblflds1.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		ListAllerpproductaddedtable wsForm1 = new ListAllerpproductaddedtable(); 
		Erpproductaddedtable tbl1 = new Erpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs1 = new ErpproductaddedtableRecords(); 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec1 = new ErpproductaddedtableRecords.ErpproductaddedtableRec(); 
		ErpproductaddedtableFlds tblflds1 = new ErpproductaddedtableFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getProductid();  
		//tblflds1.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds1.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductname();  
		//tblflds1.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds1.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductcategory();  
		//tblflds1.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds1.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getPrimarysupplier();  
		//tblflds1.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds1.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductdesc();  
		//tblflds1.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds1.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds1.getProductpicture();  
		//tblflds1.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds1.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductaddedcolumn();  
		//tblflds1.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds1.getProductaddedcolumn() ); 
 
		} // if (tblrecs1_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec1.setErpproductaddedtableFlds(tblflds1); 
		tblrecs1.getErpproductaddedtableRec().add(tblrec1); 
		tbl1.setErpproductaddedtableRecords(tblrecs1); 
		wsForm1.setErpproductaddedtable(tbl1); 
		return wsForm1; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
		//**** Spring REST Wrapper : FILE / STREAM : GET / PUT FUNCTIONS  
			  
	@GetMapping("ListallErpProductAddedTableDisplayAllgetstreamproductpicturerest") 
	public ResponseEntity<Resource> ListallErpProductAddedTableDisplayAllgetstreamproductpicturerest(@RequestParam String p_recno)  
	throws Exception 
	{ 
		//default resource if FILE null 
		byte[] arr1 = "0".getBytes(); 
		Resource resource = new ByteArrayResource(arr1, "No File"); 
		 
		p_recno= p_recno.replaceAll("\"",""); 
		System.out.println("-----------------------------------------------------"); 
		System.out.println("p_recno = "+p_recno); 
		FileObj fd = new FileObj(); 
		 
		fd = ListallErpProductAddedTableDisplayAllgetstreamproductpicture(p_recno); 
		 
		String p_filename = fd.getFileName();   
		String isFileorWebUrl = fd.getContentLink();  
		int fSize = fd.getContentSize();  
		String webURL = fd.getPath();  
		if (isFileorWebUrl == null ) { isFileorWebUrl = ""; } 
		isFileorWebUrl = isFileorWebUrl.trim(); 
		 
		String contentType = fd.getContentType(); 
		//default content type if no type 
		if((contentType == null)||(contentType.trim().length() < 1)) { 
			contentType = "application/octet-stream"; 
		} 
		 
		System.out.println("isFileorWebUrl = "+isFileorWebUrl); 
		System.out.println("p_filename = "+p_filename); 
		System.out.println("webURL = "+webURL); 
		System.out.println("contentType = "+contentType); 
		System.out.println("fSize = "+fSize); 
		System.out.println("-----------------------------------------------------"); 
		 
		String dn_filename = ""; 
		// Load file as Resource 
		if (isFileorWebUrl.equals("C")) { 
			dn_filename = webURL; 
			//byte[] arr2 = webURL.getBytes(); 
			//resource = new ByteArrayResource(arr2, "Web URL File"); 
			resource = new UrlResource(webURL); 
		} else { //not C 
			if (fSize > 0) { 
			dn_filename = p_filename; 
			resource = new ByteArrayResource(fd.getFileData()); 
			} else { 
			dn_filename = "File_Not_Found.txt"; 
			} 
		} 
		return ResponseEntity.ok() 
		    .contentType(MediaType.parseMediaType(contentType)) 
		    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + dn_filename + "\"") 
		    .body(resource); 
	} 
	 
	 
	//Note: PUT FILE of type Web URL Linking- not supported via web services 
	//		Following function supports uploading of FILE 
	 
	@PostMapping("ListallErpProductAddedTableDisplayAllputstreamproductpicturerest") 
	public String ListallErpProductAddedTableDisplayAllputstreamproductpicturerest( 
				@RequestParam String p_recno, 
				@RequestParam MultipartFile file)  
	throws Exception 
	{ 
		int p_size = Integer.valueOf(""+file.getSize()).intValue(); 
		String p_filename = file.getOriginalFilename(); 
		 
		p_recno= p_recno.replaceAll("\"",""); 
		 
		System.out.println("-----------------------------------------------------"); 
		System.out.println("p_recno = "+p_recno); 
		System.out.println("p_filename = "+p_filename); 
		System.out.println("p_size = "+p_size); 
		System.out.println("-----------------------------------------------------"); 
		 
		FileObj fd = new FileObj();   
		fd.setFileName(p_filename);   
		//fd.setPath(finfo[1]);  
		fd.setContentType(file.getContentType());  
		fd.setContentSize(p_size);  
		fd.setNameSize(p_filename +" "+p_size+" Bytes");  
		fd.setContentLink("");  
		fd.setFileData(file.getBytes());  
		 
		return ListallErpProductAddedTableDisplayAllputstreamproductpicture(p_recno, fd); 
	} 
	 
		//**** FILE / STREAM : GET / PUT FUNCTIONS  
			  
		  
		public FileObj ListallErpProductAddedTableDisplayAllgetstreamproductpicture(String p_recno)    
		throws Exception   
		{    
			  
			FileObj fd = new FileObj();  
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007108,0,0,"ListAllerpproductaddedtable","Erpproductaddedtable"); 
			wpr.setDisRecNo(p_recno);   
			String[] tbl_ln_arr = { "S","","erp_product_added_table","product_picture","" }; 
			byte[] fdata = wpr.procWpReqGetFile(5003838,5010959,tbl_ln_arr);   
			String[] finfo = wpr.getFileInfo();  
			fd.setFileName(finfo[0]);  
			fd.setPath(finfo[1]); 
			fd.setContentType(finfo[2]); 
			if(finfo[3].trim().length() > 0) { 
			fd.setContentSize(Integer.valueOf(finfo[3]).intValue()); 
			} 
			fd.setNameSize(finfo[4]); 
			fd.setContentLink(finfo[5]); 
			fd.setFileData(fdata); 
			//System.out.println(finfo); 
			return fd; 
		} 
	 
		  
		public String ListallErpProductAddedTableDisplayAllputstreamproductpicture(String p_recno, FileObj fo )   
		throws Exception  
		{   
	 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007108,0,0,"ListAllerpproductaddedtable","Erpproductaddedtable"); 
			wpr.setDisRecNo(p_recno);  
			String[] tbl_ln_arr = { "S","","erp_product_added_table","product_picture","" }; 
			String put_stat = wpr.procWpReqPutFile(5003838,5010959,tbl_ln_arr,  
						fo.getFileData(), 
						fo.getContentSize(), 
						fo.getFileName(), 
						fo.getContentType(), 
						fo.getPath()); 
			return put_stat; 
	      } 
	 
 
	//EM Name + Mode + Qry Opt : QueryErpProductAddedTableDisplayInputQuery 
 
@PostMapping("QueryErpProductAddedTableDisplayInputQuery")  
	public @ResponseBody Queryerpproductaddedtable QueryErpProductAddedTableDisplayInputQuery(@RequestBody EmQueryParam emq)  
	throws Exception 
	{  
 
String[][] p_qryln = emq.getQueryLine(); String[] p_qryarr = emq.getQueryArray(); 
 
// Add Debug block to see what was passed 
/* 
System.out.println("------------"); 
for(int i=0;i<p_qryln[0].length;i++){ 
System.out.println(i+") "+p_qryln[0][i]); 
} 
for(int i=0;i<p_qryln[1].length;i++){ 
System.out.println(i+") "+p_qryln[1][i]); 
} 
System.out.println("------------"); 
for(int i=0;i<p_qryarr.length;i++){ 
System.out.println(i+") "+p_qryarr[i]); 
} 
*/ 
 
		Queryerpproductaddedtable wsForm2 = new Queryerpproductaddedtable(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007109,0,0,"Queryerpproductaddedtable","Erpproductaddedtable"); 
		wpr.setInputQry(p_qryln, p_qryarr); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpproductaddedtable wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm2 = (Queryerpproductaddedtable) wsVar.getQueryerpproductaddedtable();  
		return wsForm2; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproductaddedtable tbl2 = wsForm2.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs2 = tbl2.getErpproductaddedtableRecords(); 
		int tblrecs2_Count = tblrecs2.getErpproductaddedtableRec().size(); 
		System.out.println("Count Erpproductaddedtable Records = "+tblrecs2_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs2_Count > 0 ) { 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec2 = tblrecs2.getErpproductaddedtableRec().get(0); 
		ErpproductaddedtableFlds tblflds2 = tblrec2.getErpproductaddedtableFlds(); 
 		//Now Get ANY Fields/Columns as tblflds2.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		Queryerpproductaddedtable wsForm2 = new Queryerpproductaddedtable(); 
		Erpproductaddedtable tbl2 = new Erpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs2 = new ErpproductaddedtableRecords(); 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec2 = new ErpproductaddedtableRecords.ErpproductaddedtableRec(); 
		ErpproductaddedtableFlds tblflds2 = new ErpproductaddedtableFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getProductid();  
		//tblflds2.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds2.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductname();  
		//tblflds2.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds2.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductcategory();  
		//tblflds2.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds2.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getPrimarysupplier();  
		//tblflds2.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds2.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductdesc();  
		//tblflds2.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds2.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds2.getProductpicture();  
		//tblflds2.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds2.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductaddedcolumn();  
		//tblflds2.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds2.getProductaddedcolumn() ); 
 
		} // if (tblrecs2_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec2.setErpproductaddedtableFlds(tblflds2); 
		tblrecs2.getErpproductaddedtableRec().add(tblrec2); 
		tbl2.setErpproductaddedtableRecords(tblrecs2); 
		wsForm2.setErpproductaddedtable(tbl2); 
		return wsForm2; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
		//**** Spring REST Wrapper : FILE / STREAM : GET / PUT FUNCTIONS  
			  
	@GetMapping("QueryErpProductAddedTableDisplayInputQuerygetstreamproductpicturerest") 
	public ResponseEntity<Resource> QueryErpProductAddedTableDisplayInputQuerygetstreamproductpicturerest(@RequestParam String p_recno)  
	throws Exception 
	{ 
		//default resource if FILE null 
		byte[] arr1 = "0".getBytes(); 
		Resource resource = new ByteArrayResource(arr1, "No File"); 
		 
		p_recno= p_recno.replaceAll("\"",""); 
		System.out.println("-----------------------------------------------------"); 
		System.out.println("p_recno = "+p_recno); 
		FileObj fd = new FileObj(); 
		 
		fd = QueryErpProductAddedTableDisplayInputQuerygetstreamproductpicture(p_recno); 
		 
		String p_filename = fd.getFileName();   
		String isFileorWebUrl = fd.getContentLink();  
		int fSize = fd.getContentSize();  
		String webURL = fd.getPath();  
		if (isFileorWebUrl == null ) { isFileorWebUrl = ""; } 
		isFileorWebUrl = isFileorWebUrl.trim(); 
		 
		String contentType = fd.getContentType(); 
		//default content type if no type 
		if((contentType == null)||(contentType.trim().length() < 1)) { 
			contentType = "application/octet-stream"; 
		} 
		 
		System.out.println("isFileorWebUrl = "+isFileorWebUrl); 
		System.out.println("p_filename = "+p_filename); 
		System.out.println("webURL = "+webURL); 
		System.out.println("contentType = "+contentType); 
		System.out.println("fSize = "+fSize); 
		System.out.println("-----------------------------------------------------"); 
		 
		String dn_filename = ""; 
		// Load file as Resource 
		if (isFileorWebUrl.equals("C")) { 
			dn_filename = webURL; 
			//byte[] arr2 = webURL.getBytes(); 
			//resource = new ByteArrayResource(arr2, "Web URL File"); 
			resource = new UrlResource(webURL); 
		} else { //not C 
			if (fSize > 0) { 
			dn_filename = p_filename; 
			resource = new ByteArrayResource(fd.getFileData()); 
			} else { 
			dn_filename = "File_Not_Found.txt"; 
			} 
		} 
		return ResponseEntity.ok() 
		    .contentType(MediaType.parseMediaType(contentType)) 
		    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + dn_filename + "\"") 
		    .body(resource); 
	} 
	 
	 
	//Note: PUT FILE of type Web URL Linking- not supported via web services 
	//		Following function supports uploading of FILE 
	 
	@PostMapping("QueryErpProductAddedTableDisplayInputQueryputstreamproductpicturerest") 
	public String QueryErpProductAddedTableDisplayInputQueryputstreamproductpicturerest( 
				@RequestParam String p_recno, 
				@RequestParam MultipartFile file)  
	throws Exception 
	{ 
		int p_size = Integer.valueOf(""+file.getSize()).intValue(); 
		String p_filename = file.getOriginalFilename(); 
		 
		p_recno= p_recno.replaceAll("\"",""); 
		 
		System.out.println("-----------------------------------------------------"); 
		System.out.println("p_recno = "+p_recno); 
		System.out.println("p_filename = "+p_filename); 
		System.out.println("p_size = "+p_size); 
		System.out.println("-----------------------------------------------------"); 
		 
		FileObj fd = new FileObj();   
		fd.setFileName(p_filename);   
		//fd.setPath(finfo[1]);  
		fd.setContentType(file.getContentType());  
		fd.setContentSize(p_size);  
		fd.setNameSize(p_filename +" "+p_size+" Bytes");  
		fd.setContentLink("");  
		fd.setFileData(file.getBytes());  
		 
		return QueryErpProductAddedTableDisplayInputQueryputstreamproductpicture(p_recno, fd); 
	} 
	 
		//**** FILE / STREAM : GET / PUT FUNCTIONS  
			  
		  
		public FileObj QueryErpProductAddedTableDisplayInputQuerygetstreamproductpicture(String p_recno)    
		throws Exception   
		{    
			  
			FileObj fd = new FileObj();  
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007109,0,0,"Queryerpproductaddedtable","Erpproductaddedtable"); 
			wpr.setDisRecNo(p_recno);   
			String[] tbl_ln_arr = { "S","","erp_product_added_table","product_picture","" }; 
			byte[] fdata = wpr.procWpReqGetFile(5003838,5010959,tbl_ln_arr);   
			String[] finfo = wpr.getFileInfo();  
			fd.setFileName(finfo[0]);  
			fd.setPath(finfo[1]); 
			fd.setContentType(finfo[2]); 
			if(finfo[3].trim().length() > 0) { 
			fd.setContentSize(Integer.valueOf(finfo[3]).intValue()); 
			} 
			fd.setNameSize(finfo[4]); 
			fd.setContentLink(finfo[5]); 
			fd.setFileData(fdata); 
			//System.out.println(finfo); 
			return fd; 
		} 
	 
		  
		public String QueryErpProductAddedTableDisplayInputQueryputstreamproductpicture(String p_recno, FileObj fo )   
		throws Exception  
		{   
	 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007109,0,0,"Queryerpproductaddedtable","Erpproductaddedtable"); 
			wpr.setDisRecNo(p_recno);  
			String[] tbl_ln_arr = { "S","","erp_product_added_table","product_picture","" }; 
			String put_stat = wpr.procWpReqPutFile(5003838,5010959,tbl_ln_arr,  
						fo.getFileData(), 
						fo.getContentSize(), 
						fo.getFileName(), 
						fo.getContentType(), 
						fo.getPath()); 
			return put_stat; 
	      } 
	 
 
	//EM Name + Mode + Qry Opt : AddToErpProductAddedTableInput 
 
@PostMapping("AddToErpProductAddedTableInput")  
public @ResponseBody WpInfo AddToErpProductAddedTableInput(@RequestBody String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_AddToErpProductAddedTableInput(p_fldvalarr); 
	} 
 
public WpInfo sub_AddToErpProductAddedTableInput(String[][] p_fldvalarr)  
	throws Exception 
	{  
		AddToerpproductaddedtable wsForm3 = new AddToerpproductaddedtable(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007110,0,0,"AddToerpproductaddedtable","Erpproductaddedtable"); 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp3 = new WpInfo(); 
		wp3.setWpStatus(1); 
		wp3.setWpMessage(wpr.wpex_xml_str); 
		return wp3; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproductaddedtable tbl3 = wsForm3.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs3 = tbl3.getErpproductaddedtableRecords(); 
		int tblrecs3_Count = tblrecs3.getErpproductaddedtableRec().size(); 
		System.out.println("Count Erpproductaddedtable Records = "+tblrecs3_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs3_Count > 0 ) { 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec3 = tblrecs3.getErpproductaddedtableRec().get(0); 
		ErpproductaddedtableFlds tblflds3 = tblrec3.getErpproductaddedtableFlds(); 
 		//Now Get ANY Fields/Columns as tblflds3.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		AddToerpproductaddedtable wsForm3 = new AddToerpproductaddedtable(); 
		Erpproductaddedtable tbl3 = new Erpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs3 = new ErpproductaddedtableRecords(); 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec3 = new ErpproductaddedtableRecords.ErpproductaddedtableRec(); 
		ErpproductaddedtableFlds tblflds3 = new ErpproductaddedtableFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds3.getProductid();  
		//tblflds3.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds3.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductname();  
		//tblflds3.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds3.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductcategory();  
		//tblflds3.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds3.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getPrimarysupplier();  
		//tblflds3.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds3.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductdesc();  
		//tblflds3.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds3.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds3.getProductpicture();  
		//tblflds3.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds3.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductaddedcolumn();  
		//tblflds3.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds3.getProductaddedcolumn() ); 
 
		} // if (tblrecs3_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec3.setErpproductaddedtableFlds(tblflds3); 
		tblrecs3.getErpproductaddedtableRec().add(tblrec3); 
		tbl3.setErpproductaddedtableRecords(tblrecs3); 
		wsForm3.setErpproductaddedtable(tbl3); 
		return wsForm3; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
	//EM Name + Mode + Qry Opt : EditRecordErpProductAddedTableEditRecordNo 
 
@PutMapping("EditRecordErpProductAddedTableEditRecordNo")  
public @ResponseBody WpInfo EditRecordErpProductAddedTableEditRecordNo(@RequestBody String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_EditRecordErpProductAddedTableEditRecordNo(p_fldvalarr); 
	} 
 
public WpInfo sub_EditRecordErpProductAddedTableEditRecordNo(String[][] p_fldvalarr)  
	throws Exception 
	{  
		EditRecorderpproductaddedtable wsForm4 = new EditRecorderpproductaddedtable(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001865,5007111,0,0,"EditRecorderpproductaddedtable","Erpproductaddedtable"); 
 
		//Check if {"EDITRECNO","10109"} element present then set it 
		if ((p_fldvalarr[0][0] != null) && (p_fldvalarr[0][0].equals("EDITRECNO"))) { 
			String v_recno = "" + p_fldvalarr[0][1]; 
			wpr.setEdtRecNo(v_recno); //If set invalid, Says Rec Added/Updated, but actually nothing happens 
		} 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp4 = new WpInfo(); 
		wp4.setWpStatus(1); 
		wp4.setWpMessage(wpr.wpex_xml_str); 
		return wp4; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproductaddedtable tbl4 = wsForm4.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs4 = tbl4.getErpproductaddedtableRecords(); 
		int tblrecs4_Count = tblrecs4.getErpproductaddedtableRec().size(); 
		System.out.println("Count Erpproductaddedtable Records = "+tblrecs4_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs4_Count > 0 ) { 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec4 = tblrecs4.getErpproductaddedtableRec().get(0); 
		ErpproductaddedtableFlds tblflds4 = tblrec4.getErpproductaddedtableFlds(); 
 		//Now Get ANY Fields/Columns as tblflds4.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		EditRecorderpproductaddedtable wsForm4 = new EditRecorderpproductaddedtable(); 
		Erpproductaddedtable tbl4 = new Erpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs4 = new ErpproductaddedtableRecords(); 
		ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec4 = new ErpproductaddedtableRecords.ErpproductaddedtableRec(); 
		ErpproductaddedtableFlds tblflds4 = new ErpproductaddedtableFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds4.getProductid();  
		//tblflds4.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds4.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductname();  
		//tblflds4.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds4.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductcategory();  
		//tblflds4.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds4.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getPrimarysupplier();  
		//tblflds4.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds4.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductdesc();  
		//tblflds4.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds4.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds4.getProductpicture();  
		//tblflds4.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds4.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductaddedcolumn();  
		//tblflds4.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds4.getProductaddedcolumn() ); 
 
		} // if (tblrecs4_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec4.setErpproductaddedtableFlds(tblflds4); 
		tblrecs4.getErpproductaddedtableRec().add(tblrec4); 
		tbl4.setErpproductaddedtableRecords(tblrecs4); 
		wsForm4.setErpproductaddedtable(tbl4); 
		return wsForm4; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
 
      private WPForerpproductaddedtable createJavaObjFromXmlStr(String p_xml_str) { 
	  WPForerpproductaddedtable wsVar = new WPForerpproductaddedtable();  
        try {  
            JAXBContext jc = JAXBContext.newInstance( "WPForerpproductaddedtable.jaxb" );  
            Unmarshaller u = jc.createUnmarshaller();  
            JAXBElement<?> wsElement = (JAXBElement<?>)u.unmarshal( new  
					StringReader( p_xml_str ) );  
 		//System.out.println("JAXBElement Name / Declared Type : "+ wsElement.getName() +" / "+ wsElement.getDeclaredType() );   
		wsVar = (WPForerpproductaddedtable) wsElement.getValue();  
  
        } catch( JAXBException je ) {  
            je.printStackTrace();  
        }  
	  return wsVar; 
     }  
 
      private String addRootXml(String p_str) {      
		String add_xml_str =  
		"<?xml version=\"1.0\" ?> "+"\n"+   
		"<ws1:WPForerpproductaddedtable xmlns:ws1=\"http://emws50.WPForerpproductaddedtable/jaxb/WPForerpproductaddedtable\" >   "+"\n"+ 
		p_str + 
		"</ws1:WPForerpproductaddedtable>   "+"\n"; 
 		return add_xml_str; 
      } 
 
 
 
} 
