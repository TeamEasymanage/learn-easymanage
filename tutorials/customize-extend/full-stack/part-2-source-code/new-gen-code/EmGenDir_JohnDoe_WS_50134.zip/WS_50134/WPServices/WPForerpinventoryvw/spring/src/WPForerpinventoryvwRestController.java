package emrest.spring;  
  
import java.lang.*; 
import java.util.*; 
import java.text.*; 
import java.math.*; 
import java.io.*; 
import org.springframework.stereotype.Controller; 
import org.springframework.web.bind.annotation.*; 
import javax.xml.bind.*; 
import javax.xml.bind.annotation.XmlType; 
import javax.xml.datatype.*; 
import org.springframework.core.io.Resource; 
import org.springframework.core.io.ByteArrayResource; 
import org.springframework.core.io.UrlResource; 
import org.springframework.http.*; 
import org.springframework.web.multipart.MultipartFile; 
import org.springframework.beans.factory.annotation.Value; 
 
import WPForerpinventoryvw.jaxb.*; 
 
import em.*; 
import emb.*; 
import emapi.*; 
 
@CrossOrigin  
@RestController 
@RequestMapping("/emrest/JohnDoe/WPForerpinventoryvw") 
public class WPForerpinventoryvwRestController {  
	private String message = new String("WPForerpinventoryvw (Spring): "); 
 
// ------------------------------------------------------------------------------ 
// ---------- Begin: Declarations and lib function for XML Date to java date to fldval string conversion 
// --- Note: Please set values for below as per EM User Profile : Date , Time Input Formats (but in java SimpleDateFormat format) ----  
@Value( "${emDateFmt:MM/d/yyyy}" ) 
private String emDateFmt; 
@Value( "${emTimeFmt:hh:mm:ss aa}" ) 
private String emTimeFmt; 
 
private String emConvXmlCalendarToStr(Calendar dateTime, String dttyp) { 
	String retDate = ""; 
	String dtfmt = emDateFmt; //default is DATE 
	if (dttyp.equals("DATETIME")) { 
		dtfmt = emDateFmt+" "+emTimeFmt; 
	} else if (dttyp.equals("TIME")) { 
		dtfmt = emTimeFmt; 
	} 
 
    try { 
	SimpleDateFormat toEmStrFmt = new SimpleDateFormat(dtfmt); 
	toEmStrFmt.setCalendar(dateTime); 
	retDate = toEmStrFmt.format(dateTime.getTime()); 
	} catch (Exception e) { 
      //e.printStackTrace(); 
   } 
	//System.out.println("Out Str = "+retDate); 
	return retDate; 
} 
//-------- Used by Spring Input Edit methods with json param 
private String[][]	emAddEditRecNoTo_fldvalarr(String RecNo, String[][] p_fldvalarr) { 
Vector<String[]> vec1 = new Vector<String[]>(); 
	vec1.add(new String[] { "EDITRECNO", RecNo } ); 
for (int i=0;i<p_fldvalarr.length;i++) { 
	vec1.add(p_fldvalarr[i]); 
} 
 
return vec1.toArray(new String[vec1.size()][2]); 
} 
private String toEmStr(String inputStr) { 
if (inputStr == null) { return ""; } 
return inputStr; 
} 
private String toEmStrInt(BigInteger inputVal) {  
if (inputVal == null) { return ""; }  
return inputVal.toString();  
}  
private String toEmStrFlt(Float inputVal) {  
if (inputVal == null) { return ""; }  
return Float.toString(inputVal); 
} 
 
// ---------- End: Declarations and lib function for XML Date to java date to fldval string conversion 
// ------------------------------------------------------------------------------ 
 
 
  
	// This is ADD-ON REST CALL available for Delete Record along with : EditRecordNo WebProject Mode 
  
@DeleteMapping("EditRecordErpInventoryVwDelRecNo")  
public @ResponseBody WpInfo EditRecordErpInventoryVwDelRecNo(@RequestParam String RecNo)  
	throws Exception 
	{  
		EditRecorderpinventoryvw wsForm4 = new EditRecorderpinventoryvw(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001868,5007123,0,0,"EditRecorderpinventoryvw","Erpinventoryvw"); 
 
		wpr.setDelRecNo(RecNo); //Setting this bypasses EditRecNo but process DeleteRecordNo in WsEmWpExec 
		wpr.procWpReq(); 
		WpInfo wp4 = new WpInfo(); 
		wp4.setWpStatus(1); 
		wp4.setWpMessage(wpr.wpex_xml_str); 
		return wp4; 
	}  
	  
 
private String[][] convErpinventoryvwFldsJsonToArr4(ErpinventoryvwFlds inpRec) { 
	//ErpinventoryvwFlds tblflds3 = new ErpinventoryvwFlds(); 
	Vector<String[]> flds1 = new Vector<String[]>();  
		flds1.add (new String[] { "F5010970" , toEmStrInt(inpRec.getInvid()) }) ;  //Invid  [NUMBER]Value 
		flds1.add (new String[] { "F5010971" , toEmStrInt(inpRec.getProductid()) }) ;  //Productid  [NUMBER]Value 
		flds1.add (new String[] { "F5010972" , toEmStr(inpRec.getProductname()) }) ;  //Productname  [CHAR]Value 
		flds1.add (new String[] { "F5010973" , toEmStr(emConvXmlCalendarToStr(inpRec.getInvdate(),"DATE" )) }) ;  //Invdate  [DATE]Value 
		flds1.add (new String[] { "F5010974" , toEmStrInt(inpRec.getInvqty()) }) ;  //Invqty  [NUMBER]Value 
		flds1.add (new String[] { "F5010975" , toEmStrInt(inpRec.getInvminqty()) }) ;  //Invminqty  [NUMBER]Value 
		flds1.add (new String[] { "F5010976" , toEmStrFlt(inpRec.getInvcost()) }) ;  //Invcost  [FLOAT]Value 
		flds1.add (new String[] { "F5010977" , toEmStr(inpRec.getInvlocation()) }) ;  //Invlocation  [CHAR]Value 

 
	return flds1.toArray(new String[flds1.size()][2]); 
		 
} 
  
 
  
@PostMapping("EditRecordErpInventoryVwEditRecordNo_json")  
public @ResponseBody WpInfo EditRecordErpInventoryVwEditRecordNo_json(@RequestParam String RecNo, @RequestBody ErpinventoryvwFlds inpRec)   
	throws Exception 
	{   
 
	String[][] p_fldvalarr = convErpinventoryvwFldsJsonToArr4(inpRec); 
	p_fldvalarr = emAddEditRecNoTo_fldvalarr(RecNo, p_fldvalarr);   
	return sub_EditRecordErpInventoryVwEditRecordNo(p_fldvalarr); 
 
} 
 
 
 
private String[][] convErpinventoryvwFldsJsonToArr3(ErpinventoryvwFlds inpRec) { 
	//ErpinventoryvwFlds tblflds3 = new ErpinventoryvwFlds(); 
	Vector<String[]> flds1 = new Vector<String[]>();  
		flds1.add (new String[] { "F5010970" , toEmStrInt(inpRec.getInvid()) }) ;  //Invid  [NUMBER]Value 
		flds1.add (new String[] { "F5010971" , toEmStrInt(inpRec.getProductid()) }) ;  //Productid  [NUMBER]Value 
		flds1.add (new String[] { "F5010972" , toEmStr(inpRec.getProductname()) }) ;  //Productname  [CHAR]Value 
		flds1.add (new String[] { "F5010973" , toEmStr(emConvXmlCalendarToStr(inpRec.getInvdate(),"DATE" )) }) ;  //Invdate  [DATE]Value 
		flds1.add (new String[] { "F5010974" , toEmStrInt(inpRec.getInvqty()) }) ;  //Invqty  [NUMBER]Value 
		flds1.add (new String[] { "F5010975" , toEmStrInt(inpRec.getInvminqty()) }) ;  //Invminqty  [NUMBER]Value 
		flds1.add (new String[] { "F5010976" , toEmStrFlt(inpRec.getInvcost()) }) ;  //Invcost  [FLOAT]Value 
		flds1.add (new String[] { "F5010977" , toEmStr(inpRec.getInvlocation()) }) ;  //Invlocation  [CHAR]Value 

 
	return flds1.toArray(new String[flds1.size()][2]); 
		 
} 
  
 
  
@PostMapping("AddToErpInventoryVwInput_json")  
public @ResponseBody WpInfo AddToErpInventoryVwInput_json(@RequestBody ErpinventoryvwFlds inpRec)   
	throws Exception 
	{   
 
	String[][] p_fldvalarr = convErpinventoryvwFldsJsonToArr3(inpRec); 
	return sub_AddToErpInventoryVwInput(p_fldvalarr); 
 
} 
 
 
 
 
 
 
 
 
 
	//EM Name + Mode + Qry Opt : ListallErpInventoryVwDisplayAll 
 
@GetMapping("ListallErpInventoryVwDisplayAll")  
	public @ResponseBody ListAllerpinventoryvw ListallErpInventoryVwDisplayAll()  
	throws Exception 
	{  
		ListAllerpinventoryvw wsForm1 = new ListAllerpinventoryvw(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001868,5007120,0,0,"ListAllerpinventoryvw","Erpinventoryvw"); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpinventoryvw wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm1 = (ListAllerpinventoryvw) wsVar.getListAllerpinventoryvw();  
		return wsForm1; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpinventoryvw tbl1 = wsForm1.getErpinventoryvw(); 
		ErpinventoryvwRecords tblrecs1 = tbl1.getErpinventoryvwRecords(); 
		int tblrecs1_Count = tblrecs1.getErpinventoryvwRec().size(); 
		System.out.println("Count Erpinventoryvw Records = "+tblrecs1_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs1_Count > 0 ) { 
		ErpinventoryvwRecords.ErpinventoryvwRec tblrec1 = tblrecs1.getErpinventoryvwRec().get(0); 
		ErpinventoryvwFlds tblflds1 = tblrec1.getErpinventoryvwFlds(); 
 		//Now Get ANY Fields/Columns as tblflds1.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		ListAllerpinventoryvw wsForm1 = new ListAllerpinventoryvw(); 
		Erpinventoryvw tbl1 = new Erpinventoryvw(); 
		ErpinventoryvwRecords tblrecs1 = new ErpinventoryvwRecords(); 
		ErpinventoryvwRecords.ErpinventoryvwRec tblrec1 = new ErpinventoryvwRecords.ErpinventoryvwRec(); 
		ErpinventoryvwFlds tblflds1 = new ErpinventoryvwFlds(); 
 
		//Invid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getInvid();  
		//tblflds1.setInvid(); //1234 
		System.out.println("	Invid : " + tblflds1.getInvid() ); 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getProductid();  
		//tblflds1.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds1.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductname();  
		//tblflds1.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds1.getProductname() ); 
		//Invdate : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds1.getInvdate();  
		//tblflds1.setInvdate(); //2006-06-01-05:30 
		System.out.println("	Invdate : " + tblflds1.getInvdate() ); 
		//Invqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getInvqty();  
		//tblflds1.setInvqty(); //1234 
		System.out.println("	Invqty : " + tblflds1.getInvqty() ); 
		//Invminqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getInvminqty();  
		//tblflds1.setInvminqty(); //1234 
		System.out.println("	Invminqty : " + tblflds1.getInvminqty() ); 
		//Invcost : Java Data Type [float], XML Schema Type [float]  
		//tblflds1.getInvcost();  
		//tblflds1.setInvcost(); //1234.56 
		System.out.println("	Invcost : " + tblflds1.getInvcost() ); 
		//Invlocation : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getInvlocation();  
		//tblflds1.setInvlocation(); //ABCD_string 
		System.out.println("	Invlocation : " + tblflds1.getInvlocation() ); 
 
		} // if (tblrecs1_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec1.setErpinventoryvwFlds(tblflds1); 
		tblrecs1.getErpinventoryvwRec().add(tblrec1); 
		tbl1.setErpinventoryvwRecords(tblrecs1); 
		wsForm1.setErpinventoryvw(tbl1); 
		return wsForm1; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
	//EM Name + Mode + Qry Opt : QueryErpInventoryVwDisplayInputQuery 
 
@PostMapping("QueryErpInventoryVwDisplayInputQuery")  
	public @ResponseBody Queryerpinventoryvw QueryErpInventoryVwDisplayInputQuery(@RequestBody EmQueryParam emq)  
	throws Exception 
	{  
 
String[][] p_qryln = emq.getQueryLine(); String[] p_qryarr = emq.getQueryArray(); 
 
// Add Debug block to see what was passed 
/* 
System.out.println("------------"); 
for(int i=0;i<p_qryln[0].length;i++){ 
System.out.println(i+") "+p_qryln[0][i]); 
} 
for(int i=0;i<p_qryln[1].length;i++){ 
System.out.println(i+") "+p_qryln[1][i]); 
} 
System.out.println("------------"); 
for(int i=0;i<p_qryarr.length;i++){ 
System.out.println(i+") "+p_qryarr[i]); 
} 
*/ 
 
		Queryerpinventoryvw wsForm2 = new Queryerpinventoryvw(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001868,5007121,0,0,"Queryerpinventoryvw","Erpinventoryvw"); 
		wpr.setInputQry(p_qryln, p_qryarr); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpinventoryvw wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm2 = (Queryerpinventoryvw) wsVar.getQueryerpinventoryvw();  
		return wsForm2; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpinventoryvw tbl2 = wsForm2.getErpinventoryvw(); 
		ErpinventoryvwRecords tblrecs2 = tbl2.getErpinventoryvwRecords(); 
		int tblrecs2_Count = tblrecs2.getErpinventoryvwRec().size(); 
		System.out.println("Count Erpinventoryvw Records = "+tblrecs2_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs2_Count > 0 ) { 
		ErpinventoryvwRecords.ErpinventoryvwRec tblrec2 = tblrecs2.getErpinventoryvwRec().get(0); 
		ErpinventoryvwFlds tblflds2 = tblrec2.getErpinventoryvwFlds(); 
 		//Now Get ANY Fields/Columns as tblflds2.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		Queryerpinventoryvw wsForm2 = new Queryerpinventoryvw(); 
		Erpinventoryvw tbl2 = new Erpinventoryvw(); 
		ErpinventoryvwRecords tblrecs2 = new ErpinventoryvwRecords(); 
		ErpinventoryvwRecords.ErpinventoryvwRec tblrec2 = new ErpinventoryvwRecords.ErpinventoryvwRec(); 
		ErpinventoryvwFlds tblflds2 = new ErpinventoryvwFlds(); 
 
		//Invid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getInvid();  
		//tblflds2.setInvid(); //1234 
		System.out.println("	Invid : " + tblflds2.getInvid() ); 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getProductid();  
		//tblflds2.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds2.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductname();  
		//tblflds2.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds2.getProductname() ); 
		//Invdate : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds2.getInvdate();  
		//tblflds2.setInvdate(); //2006-06-01-05:30 
		System.out.println("	Invdate : " + tblflds2.getInvdate() ); 
		//Invqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getInvqty();  
		//tblflds2.setInvqty(); //1234 
		System.out.println("	Invqty : " + tblflds2.getInvqty() ); 
		//Invminqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getInvminqty();  
		//tblflds2.setInvminqty(); //1234 
		System.out.println("	Invminqty : " + tblflds2.getInvminqty() ); 
		//Invcost : Java Data Type [float], XML Schema Type [float]  
		//tblflds2.getInvcost();  
		//tblflds2.setInvcost(); //1234.56 
		System.out.println("	Invcost : " + tblflds2.getInvcost() ); 
		//Invlocation : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getInvlocation();  
		//tblflds2.setInvlocation(); //ABCD_string 
		System.out.println("	Invlocation : " + tblflds2.getInvlocation() ); 
 
		} // if (tblrecs2_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec2.setErpinventoryvwFlds(tblflds2); 
		tblrecs2.getErpinventoryvwRec().add(tblrec2); 
		tbl2.setErpinventoryvwRecords(tblrecs2); 
		wsForm2.setErpinventoryvw(tbl2); 
		return wsForm2; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
	//EM Name + Mode + Qry Opt : AddToErpInventoryVwInput 
 
@PostMapping("AddToErpInventoryVwInput")  
public @ResponseBody WpInfo AddToErpInventoryVwInput(@RequestBody String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_AddToErpInventoryVwInput(p_fldvalarr); 
	} 
 
public WpInfo sub_AddToErpInventoryVwInput(String[][] p_fldvalarr)  
	throws Exception 
	{  
		AddToerpinventoryvw wsForm3 = new AddToerpinventoryvw(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001868,5007122,0,0,"AddToerpinventoryvw","Erpinventoryvw"); 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp3 = new WpInfo(); 
		wp3.setWpStatus(1); 
		wp3.setWpMessage(wpr.wpex_xml_str); 
		return wp3; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpinventoryvw tbl3 = wsForm3.getErpinventoryvw(); 
		ErpinventoryvwRecords tblrecs3 = tbl3.getErpinventoryvwRecords(); 
		int tblrecs3_Count = tblrecs3.getErpinventoryvwRec().size(); 
		System.out.println("Count Erpinventoryvw Records = "+tblrecs3_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs3_Count > 0 ) { 
		ErpinventoryvwRecords.ErpinventoryvwRec tblrec3 = tblrecs3.getErpinventoryvwRec().get(0); 
		ErpinventoryvwFlds tblflds3 = tblrec3.getErpinventoryvwFlds(); 
 		//Now Get ANY Fields/Columns as tblflds3.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		AddToerpinventoryvw wsForm3 = new AddToerpinventoryvw(); 
		Erpinventoryvw tbl3 = new Erpinventoryvw(); 
		ErpinventoryvwRecords tblrecs3 = new ErpinventoryvwRecords(); 
		ErpinventoryvwRecords.ErpinventoryvwRec tblrec3 = new ErpinventoryvwRecords.ErpinventoryvwRec(); 
		ErpinventoryvwFlds tblflds3 = new ErpinventoryvwFlds(); 
 
		//Invid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds3.getInvid();  
		//tblflds3.setInvid(); //1234 
		System.out.println("	Invid : " + tblflds3.getInvid() ); 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds3.getProductid();  
		//tblflds3.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds3.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductname();  
		//tblflds3.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds3.getProductname() ); 
		//Invdate : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds3.getInvdate();  
		//tblflds3.setInvdate(); //2006-06-01-05:30 
		System.out.println("	Invdate : " + tblflds3.getInvdate() ); 
		//Invqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds3.getInvqty();  
		//tblflds3.setInvqty(); //1234 
		System.out.println("	Invqty : " + tblflds3.getInvqty() ); 
		//Invminqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds3.getInvminqty();  
		//tblflds3.setInvminqty(); //1234 
		System.out.println("	Invminqty : " + tblflds3.getInvminqty() ); 
		//Invcost : Java Data Type [float], XML Schema Type [float]  
		//tblflds3.getInvcost();  
		//tblflds3.setInvcost(); //1234.56 
		System.out.println("	Invcost : " + tblflds3.getInvcost() ); 
		//Invlocation : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getInvlocation();  
		//tblflds3.setInvlocation(); //ABCD_string 
		System.out.println("	Invlocation : " + tblflds3.getInvlocation() ); 
 
		} // if (tblrecs3_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec3.setErpinventoryvwFlds(tblflds3); 
		tblrecs3.getErpinventoryvwRec().add(tblrec3); 
		tbl3.setErpinventoryvwRecords(tblrecs3); 
		wsForm3.setErpinventoryvw(tbl3); 
		return wsForm3; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
	//EM Name + Mode + Qry Opt : EditRecordErpInventoryVwEditRecordNo 
 
@PutMapping("EditRecordErpInventoryVwEditRecordNo")  
public @ResponseBody WpInfo EditRecordErpInventoryVwEditRecordNo(@RequestBody String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_EditRecordErpInventoryVwEditRecordNo(p_fldvalarr); 
	} 
 
public WpInfo sub_EditRecordErpInventoryVwEditRecordNo(String[][] p_fldvalarr)  
	throws Exception 
	{  
		EditRecorderpinventoryvw wsForm4 = new EditRecorderpinventoryvw(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001868,5007123,0,0,"EditRecorderpinventoryvw","Erpinventoryvw"); 
 
		//Check if {"EDITRECNO","10109"} element present then set it 
		if ((p_fldvalarr[0][0] != null) && (p_fldvalarr[0][0].equals("EDITRECNO"))) { 
			String v_recno = "" + p_fldvalarr[0][1]; 
			wpr.setEdtRecNo(v_recno); //If set invalid, Says Rec Added/Updated, but actually nothing happens 
		} 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp4 = new WpInfo(); 
		wp4.setWpStatus(1); 
		wp4.setWpMessage(wpr.wpex_xml_str); 
		return wp4; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpinventoryvw tbl4 = wsForm4.getErpinventoryvw(); 
		ErpinventoryvwRecords tblrecs4 = tbl4.getErpinventoryvwRecords(); 
		int tblrecs4_Count = tblrecs4.getErpinventoryvwRec().size(); 
		System.out.println("Count Erpinventoryvw Records = "+tblrecs4_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs4_Count > 0 ) { 
		ErpinventoryvwRecords.ErpinventoryvwRec tblrec4 = tblrecs4.getErpinventoryvwRec().get(0); 
		ErpinventoryvwFlds tblflds4 = tblrec4.getErpinventoryvwFlds(); 
 		//Now Get ANY Fields/Columns as tblflds4.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		EditRecorderpinventoryvw wsForm4 = new EditRecorderpinventoryvw(); 
		Erpinventoryvw tbl4 = new Erpinventoryvw(); 
		ErpinventoryvwRecords tblrecs4 = new ErpinventoryvwRecords(); 
		ErpinventoryvwRecords.ErpinventoryvwRec tblrec4 = new ErpinventoryvwRecords.ErpinventoryvwRec(); 
		ErpinventoryvwFlds tblflds4 = new ErpinventoryvwFlds(); 
 
		//Invid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds4.getInvid();  
		//tblflds4.setInvid(); //1234 
		System.out.println("	Invid : " + tblflds4.getInvid() ); 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds4.getProductid();  
		//tblflds4.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds4.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductname();  
		//tblflds4.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds4.getProductname() ); 
		//Invdate : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds4.getInvdate();  
		//tblflds4.setInvdate(); //2006-06-01-05:30 
		System.out.println("	Invdate : " + tblflds4.getInvdate() ); 
		//Invqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds4.getInvqty();  
		//tblflds4.setInvqty(); //1234 
		System.out.println("	Invqty : " + tblflds4.getInvqty() ); 
		//Invminqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds4.getInvminqty();  
		//tblflds4.setInvminqty(); //1234 
		System.out.println("	Invminqty : " + tblflds4.getInvminqty() ); 
		//Invcost : Java Data Type [float], XML Schema Type [float]  
		//tblflds4.getInvcost();  
		//tblflds4.setInvcost(); //1234.56 
		System.out.println("	Invcost : " + tblflds4.getInvcost() ); 
		//Invlocation : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getInvlocation();  
		//tblflds4.setInvlocation(); //ABCD_string 
		System.out.println("	Invlocation : " + tblflds4.getInvlocation() ); 
 
		} // if (tblrecs4_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec4.setErpinventoryvwFlds(tblflds4); 
		tblrecs4.getErpinventoryvwRec().add(tblrec4); 
		tbl4.setErpinventoryvwRecords(tblrecs4); 
		wsForm4.setErpinventoryvw(tbl4); 
		return wsForm4; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
 
      private WPForerpinventoryvw createJavaObjFromXmlStr(String p_xml_str) { 
	  WPForerpinventoryvw wsVar = new WPForerpinventoryvw();  
        try {  
            JAXBContext jc = JAXBContext.newInstance( "WPForerpinventoryvw.jaxb" );  
            Unmarshaller u = jc.createUnmarshaller();  
            JAXBElement<?> wsElement = (JAXBElement<?>)u.unmarshal( new  
					StringReader( p_xml_str ) );  
 		//System.out.println("JAXBElement Name / Declared Type : "+ wsElement.getName() +" / "+ wsElement.getDeclaredType() );   
		wsVar = (WPForerpinventoryvw) wsElement.getValue();  
  
        } catch( JAXBException je ) {  
            je.printStackTrace();  
        }  
	  return wsVar; 
     }  
 
      private String addRootXml(String p_str) {      
		String add_xml_str =  
		"<?xml version=\"1.0\" ?> "+"\n"+   
		"<ws1:WPForerpinventoryvw xmlns:ws1=\"http://emws50.WPForerpinventoryvw/jaxb/WPForerpinventoryvw\" >   "+"\n"+ 
		p_str + 
		"</ws1:WPForerpinventoryvw>   "+"\n"; 
 		return add_xml_str; 
      } 
 
 
 
} 
