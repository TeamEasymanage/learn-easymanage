package WPForerpcustomer.service;  
  
import java.lang.*; 
import java.util.*; 
import java.io.*; 
import javax.jws.WebMethod; 
import javax.jws.WebService; 
import javax.xml.bind.*; 
import javax.xml.bind.annotation.XmlType; 
import javax.xml.datatype.*; 
 
import WPForerpcustomer.jaxb.*; 
 
import em.*; 
import emb.*; 
import emapi.*; 
 
@WebService(name="WPForerpcustomerSvc",serviceName="WPForerpcustomerService",portName="WPForerpcustomerPort",targetNamespace="http://emws50.WPForerpcustomer/jaxws") 
public class WPForerpcustomerWebService { 
	private String message = new String("WPForerpcustomer (jaxws): "); 
 
 
	//EM Name + Mode + Qry Opt : ListallErpCustomerDisplayAll 
 
	@WebMethod() 
	public  ListAllerpcustomer ListallErpCustomerDisplayAll()  
	throws Exception 
	{  
		ListAllerpcustomer wsForm1 = new ListAllerpcustomer(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001862,5007096,0,0,"ListAllerpcustomer","Erpcustomer"); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpcustomer wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm1 = (ListAllerpcustomer) wsVar.getListAllerpcustomer();  
		return wsForm1; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpcustomer tbl1 = wsForm1.getErpcustomer(); 
		ErpcustomerRecords tblrecs1 = tbl1.getErpcustomerRecords(); 
		int tblrecs1_Count = tblrecs1.getErpcustomerRec().size(); 
		System.out.println("Count Erpcustomer Records = "+tblrecs1_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs1_Count > 0 ) { 
		ErpcustomerRecords.ErpcustomerRec tblrec1 = tblrecs1.getErpcustomerRec().get(0); 
		ErpcustomerFlds tblflds1 = tblrec1.getErpcustomerFlds(); 
 		//Now Get ANY Fields/Columns as tblflds1.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		ListAllerpcustomer wsForm1 = new ListAllerpcustomer(); 
		Erpcustomer tbl1 = new Erpcustomer(); 
		ErpcustomerRecords tblrecs1 = new ErpcustomerRecords(); 
		ErpcustomerRecords.ErpcustomerRec tblrec1 = new ErpcustomerRecords.ErpcustomerRec(); 
		ErpcustomerFlds tblflds1 = new ErpcustomerFlds(); 
 
		//CustomerId : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getCustomerId();  
		//tblflds1.setCustomerId(); //ABCD_string 
		System.out.println("	CustomerId : " + tblflds1.getCustomerId() ); 
		//Name : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getName();  
		//tblflds1.setName(); //ABCD_string 
		System.out.println("	Name : " + tblflds1.getName() ); 
		//Phone : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getPhone();  
		//tblflds1.setPhone(); //ABCD_string 
		System.out.println("	Phone : " + tblflds1.getPhone() ); 
		//MobilePhone : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getMobilePhone();  
		//tblflds1.setMobilePhone(); //ABCD_string 
		System.out.println("	MobilePhone : " + tblflds1.getMobilePhone() ); 
		//Pict : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds1.getPict();  
		//tblflds1.setPict(); //base64Binary_DATA 
		System.out.println("	Pict : " + tblflds1.getPict() ); 
		//Email : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getEmail();  
		//tblflds1.setEmail(); //ABCD_string 
		System.out.println("	Email : " + tblflds1.getEmail() ); 
		//WebSite : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getWebSite();  
		//tblflds1.setWebSite(); //ABCD_string 
		System.out.println("	WebSite : " + tblflds1.getWebSite() ); 
		//Address : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getAddress();  
		//tblflds1.setAddress(); //ABCD_string 
		System.out.println("	Address : " + tblflds1.getAddress() ); 
		//DateOfInquiry : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds1.getDateOfInquiry();  
		//tblflds1.setDateOfInquiry(); //2006-06-01-05:30 
		System.out.println("	DateOfInquiry : " + tblflds1.getDateOfInquiry() ); 
		//RequestedQty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getRequestedQty();  
		//tblflds1.setRequestedQty(); //1234 
		System.out.println("	RequestedQty : " + tblflds1.getRequestedQty() ); 
		//ReqQuoteAmt : Java Data Type [float], XML Schema Type [float]  
		//tblflds1.getReqQuoteAmt();  
		//tblflds1.setReqQuoteAmt(); //1234.56 
		System.out.println("	ReqQuoteAmt : " + tblflds1.getReqQuoteAmt() ); 
		//MeetingPrefTime : Java Data Type [Calendar], XML Schema Type [time]  
		//tblflds1.getMeetingPrefTime();  
		//tblflds1.setMeetingPrefTime(); //14:10:00-05:30 
		System.out.println("	MeetingPrefTime : " + tblflds1.getMeetingPrefTime() ); 
		//Created : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds1.getCreated();  
		//tblflds1.setCreated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Created : " + tblflds1.getCreated() ); 
		//Updated : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds1.getUpdated();  
		//tblflds1.setUpdated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Updated : " + tblflds1.getUpdated() ); 
 
		} // if (tblrecs1_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec1.setErpcustomerFlds(tblflds1); 
		tblrecs1.getErpcustomerRec().add(tblrec1); 
		tbl1.setErpcustomerRecords(tblrecs1); 
		wsForm1.setErpcustomer(tbl1); 
		return wsForm1; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
		//**** FILE / STREAM : GET / PUT FUNCTIONS  
			  
		@WebMethod()  
		public FileObj ListallErpCustomerDisplayAllgetstreampict(String p_recno)    
		throws Exception   
		{    
			  
			FileObj fd = new FileObj();  
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001862,5007096,0,0,"ListAllerpcustomer","Erpcustomer"); 
			wpr.setDisRecNo(p_recno);   
			String[] tbl_ln_arr = { "S","","erp_customer","Pict","" }; 
			byte[] fdata = wpr.procWpReqGetFile(5003832,5010930,tbl_ln_arr);   
			String[] finfo = wpr.getFileInfo();  
			fd.setFileName(finfo[0]);  
			fd.setPath(finfo[1]); 
			fd.setContentType(finfo[2]); 
			if(finfo[3].trim().length() > 0) { 
			fd.setContentSize(Integer.valueOf(finfo[3]).intValue()); 
			} 
			fd.setNameSize(finfo[4]); 
			fd.setContentLink(finfo[5]); 
			fd.setFileData(fdata); 
			//System.out.println(finfo); 
			return fd; 
		} 
	 
		@WebMethod()  
		public String ListallErpCustomerDisplayAllputstreampict(String p_recno, FileObj fo )   
		throws Exception  
		{   
	 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001862,5007096,0,0,"ListAllerpcustomer","Erpcustomer"); 
			wpr.setDisRecNo(p_recno);  
			String[] tbl_ln_arr = { "S","","erp_customer","Pict","" }; 
			String put_stat = wpr.procWpReqPutFile(5003832,5010930,tbl_ln_arr,  
						fo.getFileData(), 
						fo.getContentSize(), 
						fo.getFileName(), 
						fo.getContentType(), 
						fo.getPath()); 
			return put_stat; 
	      } 
	 
 
	//EM Name + Mode + Qry Opt : QueryErpCustomerDisplayInputQuery 
 
	@WebMethod() 
	public  Queryerpcustomer QueryErpCustomerDisplayInputQuery( String[][] p_qryln, String[] p_qryarr)  
	throws Exception 
	{  
 
 
 
// Add Debug block to see what was passed 
/* 
System.out.println("------------"); 
for(int i=0;i<p_qryln[0].length;i++){ 
System.out.println(i+") "+p_qryln[0][i]); 
} 
for(int i=0;i<p_qryln[1].length;i++){ 
System.out.println(i+") "+p_qryln[1][i]); 
} 
System.out.println("------------"); 
for(int i=0;i<p_qryarr.length;i++){ 
System.out.println(i+") "+p_qryarr[i]); 
} 
*/ 
 
		Queryerpcustomer wsForm2 = new Queryerpcustomer(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001862,5007097,0,0,"Queryerpcustomer","Erpcustomer"); 
		wpr.setInputQry(p_qryln, p_qryarr); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpcustomer wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm2 = (Queryerpcustomer) wsVar.getQueryerpcustomer();  
		return wsForm2; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpcustomer tbl2 = wsForm2.getErpcustomer(); 
		ErpcustomerRecords tblrecs2 = tbl2.getErpcustomerRecords(); 
		int tblrecs2_Count = tblrecs2.getErpcustomerRec().size(); 
		System.out.println("Count Erpcustomer Records = "+tblrecs2_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs2_Count > 0 ) { 
		ErpcustomerRecords.ErpcustomerRec tblrec2 = tblrecs2.getErpcustomerRec().get(0); 
		ErpcustomerFlds tblflds2 = tblrec2.getErpcustomerFlds(); 
 		//Now Get ANY Fields/Columns as tblflds2.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		Queryerpcustomer wsForm2 = new Queryerpcustomer(); 
		Erpcustomer tbl2 = new Erpcustomer(); 
		ErpcustomerRecords tblrecs2 = new ErpcustomerRecords(); 
		ErpcustomerRecords.ErpcustomerRec tblrec2 = new ErpcustomerRecords.ErpcustomerRec(); 
		ErpcustomerFlds tblflds2 = new ErpcustomerFlds(); 
 
		//CustomerId : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getCustomerId();  
		//tblflds2.setCustomerId(); //ABCD_string 
		System.out.println("	CustomerId : " + tblflds2.getCustomerId() ); 
		//Name : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getName();  
		//tblflds2.setName(); //ABCD_string 
		System.out.println("	Name : " + tblflds2.getName() ); 
		//Phone : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getPhone();  
		//tblflds2.setPhone(); //ABCD_string 
		System.out.println("	Phone : " + tblflds2.getPhone() ); 
		//MobilePhone : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getMobilePhone();  
		//tblflds2.setMobilePhone(); //ABCD_string 
		System.out.println("	MobilePhone : " + tblflds2.getMobilePhone() ); 
		//Pict : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds2.getPict();  
		//tblflds2.setPict(); //base64Binary_DATA 
		System.out.println("	Pict : " + tblflds2.getPict() ); 
		//Email : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getEmail();  
		//tblflds2.setEmail(); //ABCD_string 
		System.out.println("	Email : " + tblflds2.getEmail() ); 
		//WebSite : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getWebSite();  
		//tblflds2.setWebSite(); //ABCD_string 
		System.out.println("	WebSite : " + tblflds2.getWebSite() ); 
		//Address : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getAddress();  
		//tblflds2.setAddress(); //ABCD_string 
		System.out.println("	Address : " + tblflds2.getAddress() ); 
		//DateOfInquiry : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds2.getDateOfInquiry();  
		//tblflds2.setDateOfInquiry(); //2006-06-01-05:30 
		System.out.println("	DateOfInquiry : " + tblflds2.getDateOfInquiry() ); 
		//RequestedQty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getRequestedQty();  
		//tblflds2.setRequestedQty(); //1234 
		System.out.println("	RequestedQty : " + tblflds2.getRequestedQty() ); 
		//ReqQuoteAmt : Java Data Type [float], XML Schema Type [float]  
		//tblflds2.getReqQuoteAmt();  
		//tblflds2.setReqQuoteAmt(); //1234.56 
		System.out.println("	ReqQuoteAmt : " + tblflds2.getReqQuoteAmt() ); 
		//MeetingPrefTime : Java Data Type [Calendar], XML Schema Type [time]  
		//tblflds2.getMeetingPrefTime();  
		//tblflds2.setMeetingPrefTime(); //14:10:00-05:30 
		System.out.println("	MeetingPrefTime : " + tblflds2.getMeetingPrefTime() ); 
		//Created : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds2.getCreated();  
		//tblflds2.setCreated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Created : " + tblflds2.getCreated() ); 
		//Updated : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds2.getUpdated();  
		//tblflds2.setUpdated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Updated : " + tblflds2.getUpdated() ); 
 
		} // if (tblrecs2_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec2.setErpcustomerFlds(tblflds2); 
		tblrecs2.getErpcustomerRec().add(tblrec2); 
		tbl2.setErpcustomerRecords(tblrecs2); 
		wsForm2.setErpcustomer(tbl2); 
		return wsForm2; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
		//**** FILE / STREAM : GET / PUT FUNCTIONS  
			  
		@WebMethod()  
		public FileObj QueryErpCustomerDisplayInputQuerygetstreampict(String p_recno)    
		throws Exception   
		{    
			  
			FileObj fd = new FileObj();  
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001862,5007097,0,0,"Queryerpcustomer","Erpcustomer"); 
			wpr.setDisRecNo(p_recno);   
			String[] tbl_ln_arr = { "S","","erp_customer","Pict","" }; 
			byte[] fdata = wpr.procWpReqGetFile(5003832,5010930,tbl_ln_arr);   
			String[] finfo = wpr.getFileInfo();  
			fd.setFileName(finfo[0]);  
			fd.setPath(finfo[1]); 
			fd.setContentType(finfo[2]); 
			if(finfo[3].trim().length() > 0) { 
			fd.setContentSize(Integer.valueOf(finfo[3]).intValue()); 
			} 
			fd.setNameSize(finfo[4]); 
			fd.setContentLink(finfo[5]); 
			fd.setFileData(fdata); 
			//System.out.println(finfo); 
			return fd; 
		} 
	 
		@WebMethod()  
		public String QueryErpCustomerDisplayInputQueryputstreampict(String p_recno, FileObj fo )   
		throws Exception  
		{   
	 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001862,5007097,0,0,"Queryerpcustomer","Erpcustomer"); 
			wpr.setDisRecNo(p_recno);  
			String[] tbl_ln_arr = { "S","","erp_customer","Pict","" }; 
			String put_stat = wpr.procWpReqPutFile(5003832,5010930,tbl_ln_arr,  
						fo.getFileData(), 
						fo.getContentSize(), 
						fo.getFileName(), 
						fo.getContentType(), 
						fo.getPath()); 
			return put_stat; 
	      } 
	 
 
	//EM Name + Mode + Qry Opt : AddToErpCustomerInput 
 
	@WebMethod() 
public  WpInfo AddToErpCustomerInput( String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_AddToErpCustomerInput(p_fldvalarr); 
	} 
 
public WpInfo sub_AddToErpCustomerInput(String[][] p_fldvalarr)  
	throws Exception 
	{  
		AddToerpcustomer wsForm3 = new AddToerpcustomer(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001862,5007098,0,0,"AddToerpcustomer","Erpcustomer"); 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp3 = new WpInfo(); 
		wp3.setWpStatus(1); 
		wp3.setWpMessage(wpr.wpex_xml_str); 
		return wp3; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpcustomer tbl3 = wsForm3.getErpcustomer(); 
		ErpcustomerRecords tblrecs3 = tbl3.getErpcustomerRecords(); 
		int tblrecs3_Count = tblrecs3.getErpcustomerRec().size(); 
		System.out.println("Count Erpcustomer Records = "+tblrecs3_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs3_Count > 0 ) { 
		ErpcustomerRecords.ErpcustomerRec tblrec3 = tblrecs3.getErpcustomerRec().get(0); 
		ErpcustomerFlds tblflds3 = tblrec3.getErpcustomerFlds(); 
 		//Now Get ANY Fields/Columns as tblflds3.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		AddToerpcustomer wsForm3 = new AddToerpcustomer(); 
		Erpcustomer tbl3 = new Erpcustomer(); 
		ErpcustomerRecords tblrecs3 = new ErpcustomerRecords(); 
		ErpcustomerRecords.ErpcustomerRec tblrec3 = new ErpcustomerRecords.ErpcustomerRec(); 
		ErpcustomerFlds tblflds3 = new ErpcustomerFlds(); 
 
		//CustomerId : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getCustomerId();  
		//tblflds3.setCustomerId(); //ABCD_string 
		System.out.println("	CustomerId : " + tblflds3.getCustomerId() ); 
		//Name : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getName();  
		//tblflds3.setName(); //ABCD_string 
		System.out.println("	Name : " + tblflds3.getName() ); 
		//Phone : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getPhone();  
		//tblflds3.setPhone(); //ABCD_string 
		System.out.println("	Phone : " + tblflds3.getPhone() ); 
		//MobilePhone : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getMobilePhone();  
		//tblflds3.setMobilePhone(); //ABCD_string 
		System.out.println("	MobilePhone : " + tblflds3.getMobilePhone() ); 
		//Pict : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds3.getPict();  
		//tblflds3.setPict(); //base64Binary_DATA 
		System.out.println("	Pict : " + tblflds3.getPict() ); 
		//Email : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getEmail();  
		//tblflds3.setEmail(); //ABCD_string 
		System.out.println("	Email : " + tblflds3.getEmail() ); 
		//WebSite : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getWebSite();  
		//tblflds3.setWebSite(); //ABCD_string 
		System.out.println("	WebSite : " + tblflds3.getWebSite() ); 
		//Address : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getAddress();  
		//tblflds3.setAddress(); //ABCD_string 
		System.out.println("	Address : " + tblflds3.getAddress() ); 
		//DateOfInquiry : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds3.getDateOfInquiry();  
		//tblflds3.setDateOfInquiry(); //2006-06-01-05:30 
		System.out.println("	DateOfInquiry : " + tblflds3.getDateOfInquiry() ); 
		//RequestedQty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds3.getRequestedQty();  
		//tblflds3.setRequestedQty(); //1234 
		System.out.println("	RequestedQty : " + tblflds3.getRequestedQty() ); 
		//ReqQuoteAmt : Java Data Type [float], XML Schema Type [float]  
		//tblflds3.getReqQuoteAmt();  
		//tblflds3.setReqQuoteAmt(); //1234.56 
		System.out.println("	ReqQuoteAmt : " + tblflds3.getReqQuoteAmt() ); 
		//MeetingPrefTime : Java Data Type [Calendar], XML Schema Type [time]  
		//tblflds3.getMeetingPrefTime();  
		//tblflds3.setMeetingPrefTime(); //14:10:00-05:30 
		System.out.println("	MeetingPrefTime : " + tblflds3.getMeetingPrefTime() ); 
		//Created : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds3.getCreated();  
		//tblflds3.setCreated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Created : " + tblflds3.getCreated() ); 
		//Updated : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds3.getUpdated();  
		//tblflds3.setUpdated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Updated : " + tblflds3.getUpdated() ); 
 
		} // if (tblrecs3_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec3.setErpcustomerFlds(tblflds3); 
		tblrecs3.getErpcustomerRec().add(tblrec3); 
		tbl3.setErpcustomerRecords(tblrecs3); 
		wsForm3.setErpcustomer(tbl3); 
		return wsForm3; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
	//EM Name + Mode + Qry Opt : EditRecordErpCustomerEditRecordNo 
 
	@WebMethod() 
public  WpInfo EditRecordErpCustomerEditRecordNo( String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_EditRecordErpCustomerEditRecordNo(p_fldvalarr); 
	} 
 
public WpInfo sub_EditRecordErpCustomerEditRecordNo(String[][] p_fldvalarr)  
	throws Exception 
	{  
		EditRecorderpcustomer wsForm4 = new EditRecorderpcustomer(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001862,5007099,0,0,"EditRecorderpcustomer","Erpcustomer"); 
 
		//Check if {"EDITRECNO","10109"} element present then set it 
		if ((p_fldvalarr[0][0] != null) && (p_fldvalarr[0][0].equals("EDITRECNO"))) { 
			String v_recno = "" + p_fldvalarr[0][1]; 
			wpr.setEdtRecNo(v_recno); //If set invalid, Says Rec Added/Updated, but actually nothing happens 
		} 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp4 = new WpInfo(); 
		wp4.setWpStatus(1); 
		wp4.setWpMessage(wpr.wpex_xml_str); 
		return wp4; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpcustomer tbl4 = wsForm4.getErpcustomer(); 
		ErpcustomerRecords tblrecs4 = tbl4.getErpcustomerRecords(); 
		int tblrecs4_Count = tblrecs4.getErpcustomerRec().size(); 
		System.out.println("Count Erpcustomer Records = "+tblrecs4_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs4_Count > 0 ) { 
		ErpcustomerRecords.ErpcustomerRec tblrec4 = tblrecs4.getErpcustomerRec().get(0); 
		ErpcustomerFlds tblflds4 = tblrec4.getErpcustomerFlds(); 
 		//Now Get ANY Fields/Columns as tblflds4.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		EditRecorderpcustomer wsForm4 = new EditRecorderpcustomer(); 
		Erpcustomer tbl4 = new Erpcustomer(); 
		ErpcustomerRecords tblrecs4 = new ErpcustomerRecords(); 
		ErpcustomerRecords.ErpcustomerRec tblrec4 = new ErpcustomerRecords.ErpcustomerRec(); 
		ErpcustomerFlds tblflds4 = new ErpcustomerFlds(); 
 
		//CustomerId : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getCustomerId();  
		//tblflds4.setCustomerId(); //ABCD_string 
		System.out.println("	CustomerId : " + tblflds4.getCustomerId() ); 
		//Name : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getName();  
		//tblflds4.setName(); //ABCD_string 
		System.out.println("	Name : " + tblflds4.getName() ); 
		//Phone : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getPhone();  
		//tblflds4.setPhone(); //ABCD_string 
		System.out.println("	Phone : " + tblflds4.getPhone() ); 
		//MobilePhone : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getMobilePhone();  
		//tblflds4.setMobilePhone(); //ABCD_string 
		System.out.println("	MobilePhone : " + tblflds4.getMobilePhone() ); 
		//Pict : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds4.getPict();  
		//tblflds4.setPict(); //base64Binary_DATA 
		System.out.println("	Pict : " + tblflds4.getPict() ); 
		//Email : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getEmail();  
		//tblflds4.setEmail(); //ABCD_string 
		System.out.println("	Email : " + tblflds4.getEmail() ); 
		//WebSite : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getWebSite();  
		//tblflds4.setWebSite(); //ABCD_string 
		System.out.println("	WebSite : " + tblflds4.getWebSite() ); 
		//Address : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getAddress();  
		//tblflds4.setAddress(); //ABCD_string 
		System.out.println("	Address : " + tblflds4.getAddress() ); 
		//DateOfInquiry : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds4.getDateOfInquiry();  
		//tblflds4.setDateOfInquiry(); //2006-06-01-05:30 
		System.out.println("	DateOfInquiry : " + tblflds4.getDateOfInquiry() ); 
		//RequestedQty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds4.getRequestedQty();  
		//tblflds4.setRequestedQty(); //1234 
		System.out.println("	RequestedQty : " + tblflds4.getRequestedQty() ); 
		//ReqQuoteAmt : Java Data Type [float], XML Schema Type [float]  
		//tblflds4.getReqQuoteAmt();  
		//tblflds4.setReqQuoteAmt(); //1234.56 
		System.out.println("	ReqQuoteAmt : " + tblflds4.getReqQuoteAmt() ); 
		//MeetingPrefTime : Java Data Type [Calendar], XML Schema Type [time]  
		//tblflds4.getMeetingPrefTime();  
		//tblflds4.setMeetingPrefTime(); //14:10:00-05:30 
		System.out.println("	MeetingPrefTime : " + tblflds4.getMeetingPrefTime() ); 
		//Created : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds4.getCreated();  
		//tblflds4.setCreated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Created : " + tblflds4.getCreated() ); 
		//Updated : Java Data Type [Calendar], XML Schema Type [dateTime]  
		//tblflds4.getUpdated();  
		//tblflds4.setUpdated(); //2006-06-01T14:10:00-05:30 
		System.out.println("	Updated : " + tblflds4.getUpdated() ); 
 
		} // if (tblrecs4_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec4.setErpcustomerFlds(tblflds4); 
		tblrecs4.getErpcustomerRec().add(tblrec4); 
		tbl4.setErpcustomerRecords(tblrecs4); 
		wsForm4.setErpcustomer(tbl4); 
		return wsForm4; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
 
      private WPForerpcustomer createJavaObjFromXmlStr(String p_xml_str) { 
	  WPForerpcustomer wsVar = new WPForerpcustomer();  
        try {  
            JAXBContext jc = JAXBContext.newInstance( "WPForerpcustomer.jaxb" );  
            Unmarshaller u = jc.createUnmarshaller();  
            JAXBElement<?> wsElement = (JAXBElement<?>)u.unmarshal( new  
					StringReader( p_xml_str ) );  
 		//System.out.println("JAXBElement Name / Declared Type : "+ wsElement.getName() +" / "+ wsElement.getDeclaredType() );   
		wsVar = (WPForerpcustomer) wsElement.getValue();  
  
        } catch( JAXBException je ) {  
            je.printStackTrace();  
        }  
	  return wsVar; 
     }  
 
      private String addRootXml(String p_str) {      
		String add_xml_str =  
		"<?xml version=\"1.0\" ?> "+"\n"+   
		"<ws1:WPForerpcustomer xmlns:ws1=\"http://emws50.WPForerpcustomer/jaxb/WPForerpcustomer\" >   "+"\n"+ 
		p_str + 
		"</ws1:WPForerpcustomer>   "+"\n"; 
 		return add_xml_str; 
      } 
 
 
 
} 
