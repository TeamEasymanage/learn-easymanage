package WPForerpproduct.service;  
  
import java.lang.*; 
import java.util.*; 
import java.io.*; 
import javax.jws.WebMethod; 
import javax.jws.WebService; 
import javax.xml.bind.*; 
import javax.xml.bind.annotation.XmlType; 
import javax.xml.datatype.*; 
 
import WPForerpproduct.jaxb.*; 
 
import em.*; 
import emb.*; 
import emapi.*; 
 
@WebService(name="WPForerpproductSvc",serviceName="WPForerpproductService",portName="WPForerpproductPort",targetNamespace="http://emws50.WPForerpproduct/jaxws") 
public class WPForerpproductWebService { 
	private String message = new String("WPForerpproduct (jaxws): "); 
 
 
	//EM Name + Mode + Qry Opt : ListallErpProductDisplayAll 
 
	@WebMethod() 
	public  ListAllerpproduct ListallErpProductDisplayAll()  
	throws Exception 
	{  
		ListAllerpproduct wsForm1 = new ListAllerpproduct(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007104,0,0,"ListAllerpproduct","Erpproduct"); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpproduct wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm1 = (ListAllerpproduct) wsVar.getListAllerpproduct();  
		return wsForm1; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproduct tbl1 = wsForm1.getErpproduct(); 
		ErpproductRecords tblrecs1 = tbl1.getErpproductRecords(); 
		int tblrecs1_Count = tblrecs1.getErpproductRec().size(); 
		System.out.println("Count Erpproduct Records = "+tblrecs1_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs1_Count > 0 ) { 
		ErpproductRecords.ErpproductRec tblrec1 = tblrecs1.getErpproductRec().get(0); 
		ErpproductFlds tblflds1 = tblrec1.getErpproductFlds(); 
 		//Now Get ANY Fields/Columns as tblflds1.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		ListAllerpproduct wsForm1 = new ListAllerpproduct(); 
		Erpproduct tbl1 = new Erpproduct(); 
		ErpproductRecords tblrecs1 = new ErpproductRecords(); 
		ErpproductRecords.ErpproductRec tblrec1 = new ErpproductRecords.ErpproductRec(); 
		ErpproductFlds tblflds1 = new ErpproductFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getProductid();  
		//tblflds1.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds1.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductname();  
		//tblflds1.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds1.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductcategory();  
		//tblflds1.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds1.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getPrimarysupplier();  
		//tblflds1.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds1.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductdesc();  
		//tblflds1.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds1.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds1.getProductpicture();  
		//tblflds1.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds1.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductaddedcolumn();  
		//tblflds1.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds1.getProductaddedcolumn() ); 
 
		} // if (tblrecs1_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec1.setErpproductFlds(tblflds1); 
		tblrecs1.getErpproductRec().add(tblrec1); 
		tbl1.setErpproductRecords(tblrecs1); 
		wsForm1.setErpproduct(tbl1); 
		return wsForm1; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
		//**** FILE / STREAM : GET / PUT FUNCTIONS  
			  
		@WebMethod()  
		public FileObj ListallErpProductDisplayAllgetstreamproductpicture(String p_recno)    
		throws Exception   
		{    
			  
			FileObj fd = new FileObj();  
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007104,0,0,"ListAllerpproduct","Erpproduct"); 
			wpr.setDisRecNo(p_recno);   
			String[] tbl_ln_arr = { "S","","erp_product","product_picture","" }; 
			byte[] fdata = wpr.procWpReqGetFile(5003836,5010952,tbl_ln_arr);   
			String[] finfo = wpr.getFileInfo();  
			fd.setFileName(finfo[0]);  
			fd.setPath(finfo[1]); 
			fd.setContentType(finfo[2]); 
			if(finfo[3].trim().length() > 0) { 
			fd.setContentSize(Integer.valueOf(finfo[3]).intValue()); 
			} 
			fd.setNameSize(finfo[4]); 
			fd.setContentLink(finfo[5]); 
			fd.setFileData(fdata); 
			//System.out.println(finfo); 
			return fd; 
		} 
	 
		@WebMethod()  
		public String ListallErpProductDisplayAllputstreamproductpicture(String p_recno, FileObj fo )   
		throws Exception  
		{   
	 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007104,0,0,"ListAllerpproduct","Erpproduct"); 
			wpr.setDisRecNo(p_recno);  
			String[] tbl_ln_arr = { "S","","erp_product","product_picture","" }; 
			String put_stat = wpr.procWpReqPutFile(5003836,5010952,tbl_ln_arr,  
						fo.getFileData(), 
						fo.getContentSize(), 
						fo.getFileName(), 
						fo.getContentType(), 
						fo.getPath()); 
			return put_stat; 
	      } 
	 
 
	//EM Name + Mode + Qry Opt : QueryErpProductDisplayInputQuery 
 
	@WebMethod() 
	public  Queryerpproduct QueryErpProductDisplayInputQuery( String[][] p_qryln, String[] p_qryarr)  
	throws Exception 
	{  
 
 
 
// Add Debug block to see what was passed 
/* 
System.out.println("------------"); 
for(int i=0;i<p_qryln[0].length;i++){ 
System.out.println(i+") "+p_qryln[0][i]); 
} 
for(int i=0;i<p_qryln[1].length;i++){ 
System.out.println(i+") "+p_qryln[1][i]); 
} 
System.out.println("------------"); 
for(int i=0;i<p_qryarr.length;i++){ 
System.out.println(i+") "+p_qryarr[i]); 
} 
*/ 
 
		Queryerpproduct wsForm2 = new Queryerpproduct(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007105,0,0,"Queryerpproduct","Erpproduct"); 
		wpr.setInputQry(p_qryln, p_qryarr); 
		wpr.procWpReq(); 
		String add_xml_str = addRootXml(wpr.wpex_xml_str); 
		//System.out.println("EM Return Xml: \n"+ add_xml_str); 
		WPForerpproduct wsVar = createJavaObjFromXmlStr(add_xml_str); 
		wsForm2 = (Queryerpproduct) wsVar.getQueryerpproduct();  
		return wsForm2; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproduct tbl2 = wsForm2.getErpproduct(); 
		ErpproductRecords tblrecs2 = tbl2.getErpproductRecords(); 
		int tblrecs2_Count = tblrecs2.getErpproductRec().size(); 
		System.out.println("Count Erpproduct Records = "+tblrecs2_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs2_Count > 0 ) { 
		ErpproductRecords.ErpproductRec tblrec2 = tblrecs2.getErpproductRec().get(0); 
		ErpproductFlds tblflds2 = tblrec2.getErpproductFlds(); 
 		//Now Get ANY Fields/Columns as tblflds2.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		Queryerpproduct wsForm2 = new Queryerpproduct(); 
		Erpproduct tbl2 = new Erpproduct(); 
		ErpproductRecords tblrecs2 = new ErpproductRecords(); 
		ErpproductRecords.ErpproductRec tblrec2 = new ErpproductRecords.ErpproductRec(); 
		ErpproductFlds tblflds2 = new ErpproductFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getProductid();  
		//tblflds2.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds2.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductname();  
		//tblflds2.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds2.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductcategory();  
		//tblflds2.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds2.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getPrimarysupplier();  
		//tblflds2.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds2.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductdesc();  
		//tblflds2.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds2.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds2.getProductpicture();  
		//tblflds2.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds2.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductaddedcolumn();  
		//tblflds2.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds2.getProductaddedcolumn() ); 
 
		} // if (tblrecs2_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec2.setErpproductFlds(tblflds2); 
		tblrecs2.getErpproductRec().add(tblrec2); 
		tbl2.setErpproductRecords(tblrecs2); 
		wsForm2.setErpproduct(tbl2); 
		return wsForm2; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
		//**** FILE / STREAM : GET / PUT FUNCTIONS  
			  
		@WebMethod()  
		public FileObj QueryErpProductDisplayInputQuerygetstreamproductpicture(String p_recno)    
		throws Exception   
		{    
			  
			FileObj fd = new FileObj();  
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007105,0,0,"Queryerpproduct","Erpproduct"); 
			wpr.setDisRecNo(p_recno);   
			String[] tbl_ln_arr = { "S","","erp_product","product_picture","" }; 
			byte[] fdata = wpr.procWpReqGetFile(5003836,5010952,tbl_ln_arr);   
			String[] finfo = wpr.getFileInfo();  
			fd.setFileName(finfo[0]);  
			fd.setPath(finfo[1]); 
			fd.setContentType(finfo[2]); 
			if(finfo[3].trim().length() > 0) { 
			fd.setContentSize(Integer.valueOf(finfo[3]).intValue()); 
			} 
			fd.setNameSize(finfo[4]); 
			fd.setContentLink(finfo[5]); 
			fd.setFileData(fdata); 
			//System.out.println(finfo); 
			return fd; 
		} 
	 
		@WebMethod()  
		public String QueryErpProductDisplayInputQueryputstreamproductpicture(String p_recno, FileObj fo )   
		throws Exception  
		{   
	 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007105,0,0,"Queryerpproduct","Erpproduct"); 
			wpr.setDisRecNo(p_recno);  
			String[] tbl_ln_arr = { "S","","erp_product","product_picture","" }; 
			String put_stat = wpr.procWpReqPutFile(5003836,5010952,tbl_ln_arr,  
						fo.getFileData(), 
						fo.getContentSize(), 
						fo.getFileName(), 
						fo.getContentType(), 
						fo.getPath()); 
			return put_stat; 
	      } 
	 
 
	//EM Name + Mode + Qry Opt : AddToErpProductInput 
 
	@WebMethod() 
public  WpInfo AddToErpProductInput( String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_AddToErpProductInput(p_fldvalarr); 
	} 
 
public WpInfo sub_AddToErpProductInput(String[][] p_fldvalarr)  
	throws Exception 
	{  
		AddToerpproduct wsForm3 = new AddToerpproduct(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007106,0,0,"AddToerpproduct","Erpproduct"); 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp3 = new WpInfo(); 
		wp3.setWpStatus(1); 
		wp3.setWpMessage(wpr.wpex_xml_str); 
		return wp3; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproduct tbl3 = wsForm3.getErpproduct(); 
		ErpproductRecords tblrecs3 = tbl3.getErpproductRecords(); 
		int tblrecs3_Count = tblrecs3.getErpproductRec().size(); 
		System.out.println("Count Erpproduct Records = "+tblrecs3_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs3_Count > 0 ) { 
		ErpproductRecords.ErpproductRec tblrec3 = tblrecs3.getErpproductRec().get(0); 
		ErpproductFlds tblflds3 = tblrec3.getErpproductFlds(); 
 		//Now Get ANY Fields/Columns as tblflds3.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		AddToerpproduct wsForm3 = new AddToerpproduct(); 
		Erpproduct tbl3 = new Erpproduct(); 
		ErpproductRecords tblrecs3 = new ErpproductRecords(); 
		ErpproductRecords.ErpproductRec tblrec3 = new ErpproductRecords.ErpproductRec(); 
		ErpproductFlds tblflds3 = new ErpproductFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds3.getProductid();  
		//tblflds3.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds3.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductname();  
		//tblflds3.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds3.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductcategory();  
		//tblflds3.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds3.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getPrimarysupplier();  
		//tblflds3.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds3.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductdesc();  
		//tblflds3.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds3.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds3.getProductpicture();  
		//tblflds3.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds3.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds3.getProductaddedcolumn();  
		//tblflds3.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds3.getProductaddedcolumn() ); 
 
		} // if (tblrecs3_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec3.setErpproductFlds(tblflds3); 
		tblrecs3.getErpproductRec().add(tblrec3); 
		tbl3.setErpproductRecords(tblrecs3); 
		wsForm3.setErpproduct(tbl3); 
		return wsForm3; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
	//EM Name + Mode + Qry Opt : EditRecordErpProductEditRecordNo 
 
	@WebMethod() 
public  WpInfo EditRecordErpProductEditRecordNo( String[][] p_fldvalarr)  
	throws Exception 
	{   
	return sub_EditRecordErpProductEditRecordNo(p_fldvalarr); 
	} 
 
public WpInfo sub_EditRecordErpProductEditRecordNo(String[][] p_fldvalarr)  
	throws Exception 
	{  
		EditRecorderpproduct wsForm4 = new EditRecorderpproduct(); 
 
		WsEmWpExec wpr = new WsEmWpExec("JohnDoe",0,5001864,5007107,0,0,"EditRecorderpproduct","Erpproduct"); 
 
		//Check if {"EDITRECNO","10109"} element present then set it 
		if ((p_fldvalarr[0][0] != null) && (p_fldvalarr[0][0].equals("EDITRECNO"))) { 
			String v_recno = "" + p_fldvalarr[0][1]; 
			wpr.setEdtRecNo(v_recno); //If set invalid, Says Rec Added/Updated, but actually nothing happens 
		} 
 
		wpr.setInpEdtRec(p_fldvalarr); 
		wpr.procWpReq(); 
		WpInfo wp4 = new WpInfo(); 
		wp4.setWpStatus(1); 
		wp4.setWpMessage(wpr.wpex_xml_str); 
		return wp4; 
 
		/******* TO DEFINE YOUR OWN Method, Use Following *** 
		// TO GET Records from wsForm above *** 
		Erpproduct tbl4 = wsForm4.getErpproduct(); 
		ErpproductRecords tblrecs4 = tbl4.getErpproductRecords(); 
		int tblrecs4_Count = tblrecs4.getErpproductRec().size(); 
		System.out.println("Count Erpproduct Records = "+tblrecs4_Count); 
		
		// --------------------------------------------------------------- 
		if (tblrecs4_Count > 0 ) { 
		ErpproductRecords.ErpproductRec tblrec4 = tblrecs4.getErpproductRec().get(0); 
		ErpproductFlds tblflds4 = tblrec4.getErpproductFlds(); 
 		//Now Get ANY Fields/Columns as tblflds4.getFieldName(); 
  
		// TO Construct and SET Record in new wsForm *** 
		EditRecorderpproduct wsForm4 = new EditRecorderpproduct(); 
		Erpproduct tbl4 = new Erpproduct(); 
		ErpproductRecords tblrecs4 = new ErpproductRecords(); 
		ErpproductRecords.ErpproductRec tblrec4 = new ErpproductRecords.ErpproductRec(); 
		ErpproductFlds tblflds4 = new ErpproductFlds(); 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds4.getProductid();  
		//tblflds4.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds4.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductname();  
		//tblflds4.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds4.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductcategory();  
		//tblflds4.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds4.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getPrimarysupplier();  
		//tblflds4.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds4.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductdesc();  
		//tblflds4.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds4.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds4.getProductpicture();  
		//tblflds4.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds4.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds4.getProductaddedcolumn();  
		//tblflds4.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds4.getProductaddedcolumn() ); 
 
		} // if (tblrecs4_Count > 0 ) 
		// --------------------------------------------------------------- 
 
 
		tblrec4.setErpproductFlds(tblflds4); 
		tblrecs4.getErpproductRec().add(tblrec4); 
		tbl4.setErpproductRecords(tblrecs4); 
		wsForm4.setErpproduct(tbl4); 
		return wsForm4; 
		******* TO DEFINE YOUR OWN Method, Use Above ***/ 
 
	} 
 
 
 
      private WPForerpproduct createJavaObjFromXmlStr(String p_xml_str) { 
	  WPForerpproduct wsVar = new WPForerpproduct();  
        try {  
            JAXBContext jc = JAXBContext.newInstance( "WPForerpproduct.jaxb" );  
            Unmarshaller u = jc.createUnmarshaller();  
            JAXBElement<?> wsElement = (JAXBElement<?>)u.unmarshal( new  
					StringReader( p_xml_str ) );  
 		//System.out.println("JAXBElement Name / Declared Type : "+ wsElement.getName() +" / "+ wsElement.getDeclaredType() );   
		wsVar = (WPForerpproduct) wsElement.getValue();  
  
        } catch( JAXBException je ) {  
            je.printStackTrace();  
        }  
	  return wsVar; 
     }  
 
      private String addRootXml(String p_str) {      
		String add_xml_str =  
		"<?xml version=\"1.0\" ?> "+"\n"+   
		"<ws1:WPForerpproduct xmlns:ws1=\"http://emws50.WPForerpproduct/jaxb/WPForerpproduct\" >   "+"\n"+ 
		p_str + 
		"</ws1:WPForerpproduct>   "+"\n"; 
 		return add_xml_str; 
      } 
 
 
 
} 
