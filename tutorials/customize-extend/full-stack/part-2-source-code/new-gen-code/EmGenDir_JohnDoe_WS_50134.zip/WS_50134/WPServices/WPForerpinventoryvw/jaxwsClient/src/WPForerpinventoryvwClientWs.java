package WPForerpinventoryvwClient;  
  
import java.lang.*; 
import java.util.*; 
import javax.xml.datatype.*; 
import javax.xml.ws.WebServiceRef; 
 
import WPForerpinventoryvw.service.*; 
 
public class WPForerpinventoryvwClientWs { 
	@WebServiceRef (wsdlLocation="http://localhost:8080/WPForerpinventoryvwService/WPForerpinventoryvwService?wsdl")  
	static WPForerpinventoryvwService service; 
 
	public static void main(String[] args) { 
		try { 
			WPForerpinventoryvwClientWs client = new WPForerpinventoryvwClientWs(); 
			client.doTest(args); 
		     } catch(java.lang.Exception e) { 
				e.printStackTrace(); 
		    } 
	} 
     
	public void doTest(String[] args) { 
		try { 
		System.out.println("Retrieving the port from the following service: WPForerpinventoryvw ");  
		WPForerpinventoryvwSvc port = service.getWPForerpinventoryvwPort(); 
		System.out.println("Invoking the methods on the port."); 
		 
		//Process args 
		//if (args.length > 0) { 
		//    var1 = args[0]; 
		//} else { 
		//    var1 = ""; 
		//} 
 
		ObjectFactory ob1 = new ObjectFactory(); 
 
 
		System.out.println("Calling ListallErpInventoryVwDisplayAll(): [i.e. ListallErpInventoryVwDisplayAll] "); 
		ListAllerpinventoryvw wsForm1 = port.ListallErpInventoryVwDisplayAll(); 
		Erpinventoryvw tbl1 = wsForm1.getErpinventoryvw(); 
		ErpinventoryvwRecords tblrecs1 = tbl1.getErpinventoryvwRecords(); 
		List<ErpinventoryvwRecords.ErpinventoryvwRec> tblreclist1 = tblrecs1.getErpinventoryvwRec(); 
		ListIterator iter1 = tblreclist1.listIterator(); 
		System.out.println("ListAllerpinventoryvw : Erpinventoryvw : Records : "); 
		String StoreRecNo = ""; 
		while( iter1.hasNext()) { 
			ErpinventoryvwRecords.ErpinventoryvwRec tblrec1 = (ErpinventoryvwRecords.ErpinventoryvwRec) iter1.next(); 
			ErpinventoryvwFlds tblflds1 = (ErpinventoryvwFlds) tblrec1.getErpinventoryvwFlds(); 
 
 
		/******* TO Use Following, Uncomment this *** 
 
		//Invid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getInvid();  
		//tblflds1.setInvid(); //1234 
		System.out.println("	Invid : " + tblflds1.getInvid() ); 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getProductid();  
		//tblflds1.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds1.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductname();  
		//tblflds1.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds1.getProductname() ); 
		//Invdate : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds1.getInvdate();  
		//tblflds1.setInvdate(); //2006-06-01-05:30 
		System.out.println("	Invdate : " + tblflds1.getInvdate() ); 
		//Invqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getInvqty();  
		//tblflds1.setInvqty(); //1234 
		System.out.println("	Invqty : " + tblflds1.getInvqty() ); 
		//Invminqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getInvminqty();  
		//tblflds1.setInvminqty(); //1234 
		System.out.println("	Invminqty : " + tblflds1.getInvminqty() ); 
		//Invcost : Java Data Type [float], XML Schema Type [float]  
		//tblflds1.getInvcost();  
		//tblflds1.setInvcost(); //1234.56 
		System.out.println("	Invcost : " + tblflds1.getInvcost() ); 
		//Invlocation : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getInvlocation();  
		//tblflds1.setInvlocation(); //ABCD_string 
		System.out.println("	Invlocation : " + tblflds1.getInvlocation() ); 
 
		******* TO Use Above, Uncomment this ***/ 
 
		RecInfo ri1 = tblrec1.getRecInfo(); 
		System.out.println("RecInfo : "+ri1.getSrlNo()+" , "+ri1.getRecNo()); 
 
 		//Note down 1st record no in StoreRecNo 
		if (ri1.getSrlNo() == 1 ) { StoreRecNo = ""+ri1.getRecNo(); } 
 
		} //while 
 
		WpInfo wi1 = wsForm1.getWpInfo(); 
		System.out.println("WpInfo : "+wi1.getWpStatus()+" , "+wi1.getWpRecords()); 
 
 
		//Begin - Define Query Param Array for WP Scr No.: 2 
		String[][] qry2_ln = {   
		{ "Yes","","5010970:NUMBER:inv_id","Like","","%" }  
		//Remove Comments, Use query lines below, up to max query lines allowed...	 
		//,{ "Yes","AND","5010971:NUMBER:product_id","Like","","%" }  
		//,{ "Yes","AND","5010972:CHAR:product_name","Like","","%" }  
		//,{ "Yes","AND","5010973:DATE:inv_date","Like","","%" }  
		//,{ "Yes","AND","5010974:NUMBER:inv_qty","Like","","%" }  
		//,{ "Yes","AND","5010975:NUMBER:inv_min_qty","Like","","%" }  
		//,{ "Yes","AND","5010976:FLOAT:inv_cost","Like","","%" }  
		//,{ "Yes","AND","5010977:CHAR:inv_location","Like","","%" }  
				};  
		 
		List<StringArray> p_qryln2 = new ArrayList<StringArray>(); 
		for (int j=0;j<qry2_ln.length;j++) {  
			StringArray qry2_aln = new StringArray(); 
		  for (int i=0;i<qry2_ln[j].length;i++) {  
			qry2_aln.getItem().add(qry2_ln[j][i]); 
		  } 
			p_qryln2.add(qry2_aln); 
		} 
		 
		List<String> p_qryatt2 = new ArrayList<String>(); 
		String[] qry2_att1 =    
		{ "","","","0","", "0","","","","","","" }   
		//{ "5010970:NUMBER:inv_id","desc","200","0","%", "0","","","Yes","500","4","desc" }   
				;   
		for (int i=0;i<qry2_att1.length;i++) {  
			p_qryatt2.add(qry2_att1[i]);  
		} 
 
		System.out.println("Calling QueryErpInventoryVwDisplayInputQuery(): [i.e. QueryErpInventoryVwDisplayInputQuery] "); 
 
		Queryerpinventoryvw wsForm2 = port.QueryErpInventoryVwDisplayInputQuery(p_qryln2, p_qryatt2); 
		Erpinventoryvw tbl2 = wsForm2.getErpinventoryvw(); 
		ErpinventoryvwRecords tblrecs2 = tbl2.getErpinventoryvwRecords(); 
		List<ErpinventoryvwRecords.ErpinventoryvwRec> tblreclist2 = tblrecs2.getErpinventoryvwRec(); 
		ListIterator iter2 = tblreclist2.listIterator(); 
		System.out.println("Queryerpinventoryvw : Erpinventoryvw : Records : "); 
		String StoreRecNo = ""; 
		while( iter2.hasNext()) { 
			ErpinventoryvwRecords.ErpinventoryvwRec tblrec2 = (ErpinventoryvwRecords.ErpinventoryvwRec) iter2.next(); 
			ErpinventoryvwFlds tblflds2 = (ErpinventoryvwFlds) tblrec2.getErpinventoryvwFlds(); 
 
 
		/******* TO Use Following, Uncomment this *** 
 
		//Invid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getInvid();  
		//tblflds2.setInvid(); //1234 
		System.out.println("	Invid : " + tblflds2.getInvid() ); 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getProductid();  
		//tblflds2.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds2.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductname();  
		//tblflds2.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds2.getProductname() ); 
		//Invdate : Java Data Type [Calendar], XML Schema Type [date]  
		//tblflds2.getInvdate();  
		//tblflds2.setInvdate(); //2006-06-01-05:30 
		System.out.println("	Invdate : " + tblflds2.getInvdate() ); 
		//Invqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getInvqty();  
		//tblflds2.setInvqty(); //1234 
		System.out.println("	Invqty : " + tblflds2.getInvqty() ); 
		//Invminqty : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getInvminqty();  
		//tblflds2.setInvminqty(); //1234 
		System.out.println("	Invminqty : " + tblflds2.getInvminqty() ); 
		//Invcost : Java Data Type [float], XML Schema Type [float]  
		//tblflds2.getInvcost();  
		//tblflds2.setInvcost(); //1234.56 
		System.out.println("	Invcost : " + tblflds2.getInvcost() ); 
		//Invlocation : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getInvlocation();  
		//tblflds2.setInvlocation(); //ABCD_string 
		System.out.println("	Invlocation : " + tblflds2.getInvlocation() ); 
 
		******* TO Use Above, Uncomment this ***/ 
 
		RecInfo ri2 = tblrec2.getRecInfo(); 
		System.out.println("RecInfo : "+ri2.getSrlNo()+" , "+ri2.getRecNo()); 
 
 		//Note down 1st record no in StoreRecNo 
		if (ri2.getSrlNo() == 1 ) { StoreRecNo = ""+ri2.getRecNo(); } 
 
		} //while 
 
		WpInfo wi2 = wsForm2.getWpInfo(); 
		System.out.println("WpInfo : "+wi2.getWpStatus()+" , "+wi2.getWpRecords()); 
 
 
		//Begin - Define Input Edit Record Array for WP Scr No.: 3 
 
		Date dt3 = new Date(); 
		String ctr3 = dt3.toString(); 
 
		//If using Edit Record No and wish to supply the record no then: 
		//	it should be the first pair in recarr, e.g. {"EDITRECNO","10109"} 
		//	Or the record no entered on WP Screen will be used. 
 
		String[][] p_fldvalarr3 = {  
						//{"EDITRECNO","10114"}, 
		{"F5010970","1234" }  //[NUMBER]Value 
		,{"F5010971","1234" }  //[NUMBER]Value 
		,{"F5010972","ABCD_string" }  //[CHAR]Value 
		,{"F5010973","today" }  //[DATE]Value 
		,{"F5010974","1234" }  //[NUMBER]Value 
		,{"F5010975","1234" }  //[NUMBER]Value 
		,{"F5010976","1234.56" }  //[FLOAT]Value 
		,{"F5010977","ABCD_string" }  //[CHAR]Value 
					}; 
 
		List<StringArray> p_inprec3 = new ArrayList<StringArray>(); 
 
		for (int i=0;i<p_fldvalarr3.length;i++) { 
			StringArray t_arr3 = new StringArray(); 
			t_arr3.getItem().add(p_fldvalarr3[i][0]); 
			t_arr3.getItem().add(p_fldvalarr3[i][1]); 
			p_inprec3.add(t_arr3); 
		} 
 
 
		System.out.println("Calling AddToErpInventoryVwInput(): [i.e. AddToErpInventoryVwInput] "); 
 
		WpInfo wp3 = port.AddToErpInventoryVwInput(p_inprec3); 
 
		/******* TO Use Following, Uncomment this *** 
 
 
		******* TO Use Above, Uncomment this ***/ 
 
		System.out.println("WpInfo : Status : "+wp3.getWpStatus()); 
		System.out.println("WpInfo : Message : "+wp3.getWpMessage()+" , Error : "+wp3.getWpError()); 
 
 
		//Begin - Define Input Edit Record Array for WP Scr No.: 4 
 
		Date dt4 = new Date(); 
		String ctr4 = dt4.toString(); 
 
		//If using Edit Record No and wish to supply the record no then: 
		//	it should be the first pair in recarr, e.g. {"EDITRECNO","10109"} 
		//	Or the record no entered on WP Screen will be used. 
 
		String[][] p_fldvalarr4 = {  
						//{"EDITRECNO","10114"}, 
		{"F5010970","1234" }  //[NUMBER]Value 
		,{"F5010971","1234" }  //[NUMBER]Value 
		,{"F5010972","ABCD_string" }  //[CHAR]Value 
		,{"F5010973","today" }  //[DATE]Value 
		,{"F5010974","1234" }  //[NUMBER]Value 
		,{"F5010975","1234" }  //[NUMBER]Value 
		,{"F5010976","1234.56" }  //[FLOAT]Value 
		,{"F5010977","ABCD_string" }  //[CHAR]Value 
					}; 
 
		List<StringArray> p_inprec4 = new ArrayList<StringArray>(); 
 
		for (int i=0;i<p_fldvalarr4.length;i++) { 
			StringArray t_arr4 = new StringArray(); 
			t_arr4.getItem().add(p_fldvalarr4[i][0]); 
			t_arr4.getItem().add(p_fldvalarr4[i][1]); 
			p_inprec4.add(t_arr4); 
		} 
 
 
		System.out.println("Calling EditRecordErpInventoryVwEditRecordNo(): [i.e. EditRecordErpInventoryVwEditRecordNo] "); 
 
		WpInfo wp4 = port.EditRecordErpInventoryVwEditRecordNo(p_inprec4); 
 
		/******* TO Use Following, Uncomment this *** 
 
 
		******* TO Use Above, Uncomment this ***/ 
 
		System.out.println("WpInfo : Status : "+wp4.getWpStatus()); 
		System.out.println("WpInfo : Message : "+wp4.getWpMessage()+" , Error : "+wp4.getWpError()); 
 
 
 
		} catch(java.lang.Exception e) { 
			e.printStackTrace(); 
		} 
	} 
} 
