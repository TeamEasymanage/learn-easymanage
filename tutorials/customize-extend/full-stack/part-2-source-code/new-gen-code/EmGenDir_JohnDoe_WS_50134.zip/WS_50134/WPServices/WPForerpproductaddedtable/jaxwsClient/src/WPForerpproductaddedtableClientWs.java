package WPForerpproductaddedtableClient;  
  
import java.lang.*; 
import java.util.*; 
import javax.xml.datatype.*; 
import javax.xml.ws.WebServiceRef; 
 
import WPForerpproductaddedtable.service.*; 
 
public class WPForerpproductaddedtableClientWs { 
	@WebServiceRef (wsdlLocation="http://localhost:8080/WPForerpproductaddedtableService/WPForerpproductaddedtableService?wsdl")  
	static WPForerpproductaddedtableService service; 
 
	public static void main(String[] args) { 
		try { 
			WPForerpproductaddedtableClientWs client = new WPForerpproductaddedtableClientWs(); 
			client.doTest(args); 
		     } catch(java.lang.Exception e) { 
				e.printStackTrace(); 
		    } 
	} 
     
	public void doTest(String[] args) { 
		try { 
		System.out.println("Retrieving the port from the following service: WPForerpproductaddedtable ");  
		WPForerpproductaddedtableSvc port = service.getWPForerpproductaddedtablePort(); 
		System.out.println("Invoking the methods on the port."); 
		 
		//Process args 
		//if (args.length > 0) { 
		//    var1 = args[0]; 
		//} else { 
		//    var1 = ""; 
		//} 
 
		ObjectFactory ob1 = new ObjectFactory(); 
 
 
		System.out.println("Calling ListallErpProductAddedTableDisplayAll(): [i.e. ListallErpProductAddedTableDisplayAll] "); 
		ListAllerpproductaddedtable wsForm1 = port.ListallErpProductAddedTableDisplayAll(); 
		Erpproductaddedtable tbl1 = wsForm1.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs1 = tbl1.getErpproductaddedtableRecords(); 
		List<ErpproductaddedtableRecords.ErpproductaddedtableRec> tblreclist1 = tblrecs1.getErpproductaddedtableRec(); 
		ListIterator iter1 = tblreclist1.listIterator(); 
		System.out.println("ListAllerpproductaddedtable : Erpproductaddedtable : Records : "); 
		String StoreRecNo = ""; 
		while( iter1.hasNext()) { 
			ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec1 = (ErpproductaddedtableRecords.ErpproductaddedtableRec) iter1.next(); 
			ErpproductaddedtableFlds tblflds1 = (ErpproductaddedtableFlds) tblrec1.getErpproductaddedtableFlds(); 
 
 
		/******* TO Use Following, Uncomment this *** 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds1.getProductid();  
		//tblflds1.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds1.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductname();  
		//tblflds1.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds1.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductcategory();  
		//tblflds1.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds1.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getPrimarysupplier();  
		//tblflds1.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds1.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductdesc();  
		//tblflds1.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds1.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds1.getProductpicture();  
		//tblflds1.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds1.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds1.getProductaddedcolumn();  
		//tblflds1.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds1.getProductaddedcolumn() ); 
 
		******* TO Use Above, Uncomment this ***/ 
 
		RecInfo ri1 = tblrec1.getRecInfo(); 
		System.out.println("RecInfo : "+ri1.getSrlNo()+" , "+ri1.getRecNo()); 
 
 		//Note down 1st record no in StoreRecNo 
		if (ri1.getSrlNo() == 1 ) { StoreRecNo = ""+ri1.getRecNo(); } 
 
		} //while 
 
		WpInfo wi1 = wsForm1.getWpInfo(); 
		System.out.println("WpInfo : "+wi1.getWpStatus()+" , "+wi1.getWpRecords()); 
 
		System.out.println("Calling ListallErpProductAddedTableDisplayAllgetstreamproductpicture():  ");  
 		if (StoreRecNo != null && StoreRecNo.trim().length() > 0 ) { 
		FileObj fo1_6 = port.ListallErpProductAddedTableDisplayAllgetstreamproductpicture(StoreRecNo); //Record No  
 
		System.out.println("File Info: \n " +  					
		"FileName    : " + fo1_6.getFileName() + "\n" + 		
		"Path        : " + fo1_6.getPath() + "\n" +		
		"ContentType : " + fo1_6.getContentType() + "\n" +	 
		"ContentSize : " + fo1_6.getContentSize() + "\n" 	 
				); 									 
		System.out.println("File Content: "); 
		byte[] fdata1_6 = fo1_6.getFileData(); 
		if (fdata1_6.length > 0) {  
			System.out.println("Size: " + fdata1_6.length); 
		} else { 
			System.out.println("Received No File Content!"); 
		} 
 
		System.out.println("Calling ListallErpProductAddedTableDisplayAllputstreamproductpicture():  "); 
 
		byte[] filedata1_6 = fdata1_6; 
		FileObj fs1_6 = ob1.createFileObj();  
		fs1_6.setFileName(fo1_6.getFileName()); //name.txt 
		fs1_6.setPath(fo1_6.getPath()); 
		fs1_6.setContentType(fo1_6.getContentType()); //text/html 
		fs1_6.setContentSize(filedata1_6.length); 
		fs1_6.setFileData(filedata1_6); 
 
		System.out.println(" //Provide correct Record No (in place of 10002) to put file obj and uncomment below line in code "); 
		System.out.println("String fput_stat1_6 = port.ListallErpProductAddedTableDisplayAllputstreamproductpicture(\"10002\", fs1_6);  "); 
		//String fput_stat1_6 = port.ListallErpProductAddedTableDisplayAllputstreamproductpicture("10002", fs1_6); //Record No, FileObj 
  
		//System.out.println("Put File: " + fput_stat1_6 ); 
		} else { 
			System.out.println("No Record Found to fetch File!"); 
		} 
 
 
		//Begin - Define Query Param Array for WP Scr No.: 2 
		String[][] qry2_ln = {   
		{ "Yes","","5010954:NUMBER:product_id","Like","","%" }  
		//Remove Comments, Use query lines below, up to max query lines allowed...	 
		//,{ "Yes","AND","5010955:CHAR:product_name","Like","","%" }  
		//,{ "Yes","AND","5010956:CHAR:product_category","Like","","%" }  
		//,{ "Yes","AND","5010957:CHAR:primary_supplier","Like","","%" }  
		//,{ "Yes","AND","5010958:TEXT:product_desc","Like","","%" }  
		//,{ "Yes","AND","5010959:STREAM:product_picture","Like","","%" }  
		//,{ "Yes","AND","5010960:CHAR:product_added_column","Like","","%" }  
				};  
		 
		List<StringArray> p_qryln2 = new ArrayList<StringArray>(); 
		for (int j=0;j<qry2_ln.length;j++) {  
			StringArray qry2_aln = new StringArray(); 
		  for (int i=0;i<qry2_ln[j].length;i++) {  
			qry2_aln.getItem().add(qry2_ln[j][i]); 
		  } 
			p_qryln2.add(qry2_aln); 
		} 
		 
		List<String> p_qryatt2 = new ArrayList<String>(); 
		String[] qry2_att1 =    
		{ "","","","0","", "0","","","","","","" }   
		//{ "5010954:NUMBER:product_id","desc","200","0","%", "0","","","Yes","500","4","desc" }   
				;   
		for (int i=0;i<qry2_att1.length;i++) {  
			p_qryatt2.add(qry2_att1[i]);  
		} 
 
		System.out.println("Calling QueryErpProductAddedTableDisplayInputQuery(): [i.e. QueryErpProductAddedTableDisplayInputQuery] "); 
 
		Queryerpproductaddedtable wsForm2 = port.QueryErpProductAddedTableDisplayInputQuery(p_qryln2, p_qryatt2); 
		Erpproductaddedtable tbl2 = wsForm2.getErpproductaddedtable(); 
		ErpproductaddedtableRecords tblrecs2 = tbl2.getErpproductaddedtableRecords(); 
		List<ErpproductaddedtableRecords.ErpproductaddedtableRec> tblreclist2 = tblrecs2.getErpproductaddedtableRec(); 
		ListIterator iter2 = tblreclist2.listIterator(); 
		System.out.println("Queryerpproductaddedtable : Erpproductaddedtable : Records : "); 
		String StoreRecNo = ""; 
		while( iter2.hasNext()) { 
			ErpproductaddedtableRecords.ErpproductaddedtableRec tblrec2 = (ErpproductaddedtableRecords.ErpproductaddedtableRec) iter2.next(); 
			ErpproductaddedtableFlds tblflds2 = (ErpproductaddedtableFlds) tblrec2.getErpproductaddedtableFlds(); 
 
 
		/******* TO Use Following, Uncomment this *** 
 
		//Productid : Java Data Type [long], XML Schema Type [integer]  
		//tblflds2.getProductid();  
		//tblflds2.setProductid(); //1234 
		System.out.println("	Productid : " + tblflds2.getProductid() ); 
		//Productname : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductname();  
		//tblflds2.setProductname(); //ABCD_string 
		System.out.println("	Productname : " + tblflds2.getProductname() ); 
		//Productcategory : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductcategory();  
		//tblflds2.setProductcategory(); //ABCD_string 
		System.out.println("	Productcategory : " + tblflds2.getProductcategory() ); 
		//Primarysupplier : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getPrimarysupplier();  
		//tblflds2.setPrimarysupplier(); //ABCD_string 
		System.out.println("	Primarysupplier : " + tblflds2.getPrimarysupplier() ); 
		//Productdesc : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductdesc();  
		//tblflds2.setProductdesc(); //ABCD_string 
		System.out.println("	Productdesc : " + tblflds2.getProductdesc() ); 
		//Productpicture : Java Data Type [byte[]], XML Schema Type [base64Binary]  
		//tblflds2.getProductpicture();  
		//tblflds2.setProductpicture(); //base64Binary_DATA 
		System.out.println("	Productpicture : " + tblflds2.getProductpicture() ); 
		//Productaddedcolumn : Java Data Type [String], XML Schema Type [string]  
		//tblflds2.getProductaddedcolumn();  
		//tblflds2.setProductaddedcolumn(); //ABCD_string 
		System.out.println("	Productaddedcolumn : " + tblflds2.getProductaddedcolumn() ); 
 
		******* TO Use Above, Uncomment this ***/ 
 
		RecInfo ri2 = tblrec2.getRecInfo(); 
		System.out.println("RecInfo : "+ri2.getSrlNo()+" , "+ri2.getRecNo()); 
 
 		//Note down 1st record no in StoreRecNo 
		if (ri2.getSrlNo() == 1 ) { StoreRecNo = ""+ri2.getRecNo(); } 
 
		} //while 
 
		WpInfo wi2 = wsForm2.getWpInfo(); 
		System.out.println("WpInfo : "+wi2.getWpStatus()+" , "+wi2.getWpRecords()); 
 
		System.out.println("Calling QueryErpProductAddedTableDisplayInputQuerygetstreamproductpicture():  ");  
 		if (StoreRecNo != null && StoreRecNo.trim().length() > 0 ) { 
		FileObj fo2_6 = port.QueryErpProductAddedTableDisplayInputQuerygetstreamproductpicture(StoreRecNo); //Record No  
 
		System.out.println("File Info: \n " +  					
		"FileName    : " + fo2_6.getFileName() + "\n" + 		
		"Path        : " + fo2_6.getPath() + "\n" +		
		"ContentType : " + fo2_6.getContentType() + "\n" +	 
		"ContentSize : " + fo2_6.getContentSize() + "\n" 	 
				); 									 
		System.out.println("File Content: "); 
		byte[] fdata2_6 = fo2_6.getFileData(); 
		if (fdata2_6.length > 0) {  
			System.out.println("Size: " + fdata2_6.length); 
		} else { 
			System.out.println("Received No File Content!"); 
		} 
 
		System.out.println("Calling QueryErpProductAddedTableDisplayInputQueryputstreamproductpicture():  "); 
 
		byte[] filedata2_6 = fdata2_6; 
		FileObj fs2_6 = ob1.createFileObj();  
		fs2_6.setFileName(fo2_6.getFileName()); //name.txt 
		fs2_6.setPath(fo2_6.getPath()); 
		fs2_6.setContentType(fo2_6.getContentType()); //text/html 
		fs2_6.setContentSize(filedata2_6.length); 
		fs2_6.setFileData(filedata2_6); 
 
		System.out.println(" //Provide correct Record No (in place of 10002) to put file obj and uncomment below line in code "); 
		System.out.println("String fput_stat2_6 = port.QueryErpProductAddedTableDisplayInputQueryputstreamproductpicture(\"10002\", fs2_6);  "); 
		//String fput_stat2_6 = port.QueryErpProductAddedTableDisplayInputQueryputstreamproductpicture("10002", fs2_6); //Record No, FileObj 
  
		//System.out.println("Put File: " + fput_stat2_6 ); 
		} else { 
			System.out.println("No Record Found to fetch File!"); 
		} 
 
 
		//Begin - Define Input Edit Record Array for WP Scr No.: 3 
 
		Date dt3 = new Date(); 
		String ctr3 = dt3.toString(); 
 
		//If using Edit Record No and wish to supply the record no then: 
		//	it should be the first pair in recarr, e.g. {"EDITRECNO","10109"} 
		//	Or the record no entered on WP Screen will be used. 
 
		String[][] p_fldvalarr3 = {  
						//{"EDITRECNO","10114"}, 
		{"F5010954","1234" }  //[NUMBER]Value 
		,{"F5010955","ABCD_string" }  //[CHAR]Value 
		,{"F5010956","ABCD_string" }  //[CHAR]Value 
		,{"F5010957","ABCD_string" }  //[CHAR]Value 
		,{"F5010958","ABCD_string" }  //[TEXT]Value 
		,{"F5010959","" }  //[STREAM]Value 
		,{"F5010960","ABCD_string" }  //[CHAR]Value 
					}; 
 
		List<StringArray> p_inprec3 = new ArrayList<StringArray>(); 
 
		for (int i=0;i<p_fldvalarr3.length;i++) { 
			StringArray t_arr3 = new StringArray(); 
			t_arr3.getItem().add(p_fldvalarr3[i][0]); 
			t_arr3.getItem().add(p_fldvalarr3[i][1]); 
			p_inprec3.add(t_arr3); 
		} 
 
 
		System.out.println("Calling AddToErpProductAddedTableInput(): [i.e. AddToErpProductAddedTableInput] "); 
 
		WpInfo wp3 = port.AddToErpProductAddedTableInput(p_inprec3); 
 
		/******* TO Use Following, Uncomment this *** 
 
 
		******* TO Use Above, Uncomment this ***/ 
 
		System.out.println("WpInfo : Status : "+wp3.getWpStatus()); 
		System.out.println("WpInfo : Message : "+wp3.getWpMessage()+" , Error : "+wp3.getWpError()); 
 
 
		//Begin - Define Input Edit Record Array for WP Scr No.: 4 
 
		Date dt4 = new Date(); 
		String ctr4 = dt4.toString(); 
 
		//If using Edit Record No and wish to supply the record no then: 
		//	it should be the first pair in recarr, e.g. {"EDITRECNO","10109"} 
		//	Or the record no entered on WP Screen will be used. 
 
		String[][] p_fldvalarr4 = {  
						//{"EDITRECNO","10114"}, 
		{"F5010954","1234" }  //[NUMBER]Value 
		,{"F5010955","ABCD_string" }  //[CHAR]Value 
		,{"F5010956","ABCD_string" }  //[CHAR]Value 
		,{"F5010957","ABCD_string" }  //[CHAR]Value 
		,{"F5010958","ABCD_string" }  //[TEXT]Value 
		,{"F5010959","" }  //[STREAM]Value 
		,{"F5010960","ABCD_string" }  //[CHAR]Value 
					}; 
 
		List<StringArray> p_inprec4 = new ArrayList<StringArray>(); 
 
		for (int i=0;i<p_fldvalarr4.length;i++) { 
			StringArray t_arr4 = new StringArray(); 
			t_arr4.getItem().add(p_fldvalarr4[i][0]); 
			t_arr4.getItem().add(p_fldvalarr4[i][1]); 
			p_inprec4.add(t_arr4); 
		} 
 
 
		System.out.println("Calling EditRecordErpProductAddedTableEditRecordNo(): [i.e. EditRecordErpProductAddedTableEditRecordNo] "); 
 
		WpInfo wp4 = port.EditRecordErpProductAddedTableEditRecordNo(p_inprec4); 
 
		/******* TO Use Following, Uncomment this *** 
 
 
		******* TO Use Above, Uncomment this ***/ 
 
		System.out.println("WpInfo : Status : "+wp4.getWpStatus()); 
		System.out.println("WpInfo : Message : "+wp4.getWpMessage()+" , Error : "+wp4.getWpError()); 
 
 
 
		} catch(java.lang.Exception e) { 
			e.printStackTrace(); 
		} 
	} 
} 
